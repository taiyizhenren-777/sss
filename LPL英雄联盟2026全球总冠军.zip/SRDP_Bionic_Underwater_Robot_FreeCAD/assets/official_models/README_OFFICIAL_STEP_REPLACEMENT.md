# 官方 STEP 模型替换目录 (Level-A Official CAD Slot)

当您从厂家官网下载或随货收到以下官方 STEP 文件后，直接将其放入本目录并保持文件名匹配：
- `PUR-SER-2010.step` (来自 Blue Trail Engineering `Servo STEP Files April 2025.zip`)
- `PUR-SER-0011.step` (来自 Blue Trail Engineering SER-0011 官方 CAD)
- `PUR-COBALT-3P.step` (来自 Blue Trail Engineering `Cobalt STEP Files Sept 2026.zip`)
- `PUR-BR-T200.step` (来自 Blue Robotics T200 官方 CAD)
- `PUR-WTE-4IN-220.step` (来自所购成品水密电子舱官方 STEP)

放入后重新运行 `scripts/一键生成完整机器人.bat` 或 `python src/main.py`，系统将自动把对应采购件的可信度从 B/C 级升级为 **A级 (官方真实 CAD)**，并在保持统一坐标系与整机拓扑不变的前提下更新所有工程图与装配体！
