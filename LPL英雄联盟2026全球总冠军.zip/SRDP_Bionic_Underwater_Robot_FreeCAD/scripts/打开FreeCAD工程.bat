@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
title SRDP 仿生水下机器人 V2.0 - 打开 FreeCAD 与 3D 数字样机
cd /d "%~dp0.."

if not exist "output\step\SRDP_Full_Robot_Assembly.step" (
    echo [INFO] 正在初始化生成完整机器人模型...
    python src\main.py --mode full
)

:: 总是先打开零依赖 3D 交互式机器人查看器，确保立刻看到机器人
if exist "打开3D交互式机器人数字样机.html" (
    echo [INFO] 已在浏览器中打开【SRDP 3D 交互式机器人数字样机】！
    start "" "%CD%\打开3D交互式机器人数字样机.html"
)

set "FC_GUI="
for %%D in (C D E) do (
    for %%V in ("FreeCAD 1.0" "FreeCAD 0.21" "FreeCAD 0.20" "FreeCAD") do (
        if exist "%%D:\Program Files\%%~V\bin\FreeCAD.exe" set "FC_GUI=%%D:\Program Files\%%~V\bin\FreeCAD.exe"
    )
)
if exist "%LOCALAPPDATA%\Programs\FreeCAD 1.0\bin\FreeCAD.exe" set "FC_GUI=%LOCALAPPDATA%\Programs\FreeCAD 1.0\bin\FreeCAD.exe"
if exist "%LOCALAPPDATA%\Programs\FreeCAD 0.21\bin\FreeCAD.exe" set "FC_GUI=%LOCALAPPDATA%\Programs\FreeCAD 0.21\bin\FreeCAD.exe"

if defined FC_GUI (
    echo [INFO] 检测到 FreeCAD: "%FC_GUI%"，正在打开整机三维模型...
    start "" "%FC_GUI%" "%CD%\output\step\SRDP_Full_Robot_Assembly.step" "%CD%\macros\Generate_Full_SRDP.FCMacro"
) else (
    echo [INFO] 已为您打开 3D 交互式机器人窗口与 output 模型文件夹。
    echo 如需在 FreeCAD 软件中打开，请直接将 output\step\SRDP_Full_Robot_Assembly.step 拖入 FreeCAD 窗口，或在 FreeCAD 中执行 macros\Generate_Full_SRDP.FCMacro。
    start "" "%CD%\output"
    pause
)
