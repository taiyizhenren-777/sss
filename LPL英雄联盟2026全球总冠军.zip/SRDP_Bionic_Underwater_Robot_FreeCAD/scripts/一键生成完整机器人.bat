@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
title SRDP 仿生水下机器人 V2.0 - 一键生成完整机器人
cd /d "%~dp0.."

echo ============================================================================
echo   SRDP 仿生水下机器人：FreeCAD 全自动机械结构设计与工程交付系统 V2.0
echo   正在检测 FreeCAD 与 Python 运行环境...
echo ============================================================================

:: 1. 自动搜索 FreeCAD.exe 与 FreeCADCmd.exe (支持 C/D/E 盘及 AppData)
set "FC_GUI="
set "FC_CMD="
for %%D in (C D E) do (
    for %%V in ("FreeCAD 1.0" "FreeCAD 0.21" "FreeCAD 0.20" "FreeCAD") do (
        if exist "%%D:\Program Files\%%~V\bin\FreeCAD.exe" set "FC_GUI=%%D:\Program Files\%%~V\bin\FreeCAD.exe"
        if exist "%%D:\Program Files\%%~V\bin\FreeCADCmd.exe" set "FC_CMD=%%D:\Program Files\%%~V\bin\FreeCADCmd.exe"
    )
)
if exist "%LOCALAPPDATA%\Programs\FreeCAD 1.0\bin\FreeCAD.exe" set "FC_GUI=%LOCALAPPDATA%\Programs\FreeCAD 1.0\bin\FreeCAD.exe"
if exist "%LOCALAPPDATA%\Programs\FreeCAD 1.0\bin\FreeCADCmd.exe" set "FC_CMD=%LOCALAPPDATA%\Programs\FreeCAD 1.0\bin\FreeCADCmd.exe"
if exist "%LOCALAPPDATA%\Programs\FreeCAD 0.21\bin\FreeCAD.exe" set "FC_GUI=%LOCALAPPDATA%\Programs\FreeCAD 0.21\bin\FreeCAD.exe"
if exist "%LOCALAPPDATA%\Programs\FreeCAD 0.21\bin\FreeCADCmd.exe" set "FC_CMD=%LOCALAPPDATA%\Programs\FreeCAD 0.21\bin\FreeCADCmd.exe"

:: 2. 选择 Python 解释器并确保基础科学库可用
set "PY_EXE=python"
if exist ".venv\Scripts\python.exe" set "PY_EXE=.venv\Scripts\python.exe"

"%PY_EXE%" -c "import numpy, matplotlib, openpyxl" >nul 2>&1
if errorlevel 1 (
    echo [INFO] 正在为您自动检查并补齐基础科学计算与绘图库 ^(numpy, matplotlib, openpyxl^)...
    "%PY_EXE%" -m pip install numpy matplotlib openpyxl -i https://pypi.tuna.tsinghua.edu.cn/simple --quiet
)

:: 3. 执行完整机器人数字样机生成流水线
if defined FC_CMD (
    echo [INFO] 检测到 FreeCAD 命令行内核: "%FC_CMD%"
    "%FC_CMD%" "%CD%\macros\Generate_Full_SRDP.FCMacro"
)
echo [INFO] 正在执行完整四鳍水下机器人参数化建模、碰撞检测、13张工程图与BOM生成...
"%PY_EXE%" src\main.py --mode full
if errorlevel 1 (
    echo [ERROR] 生成过程出现异常，请检查上方输出信息！
    pause
    exit /b 1
)

echo.
echo ============================================================================
echo   [SUCCESS] 完整四鳍仿生水下机器人已生成完毕！
echo   1. 正在为您自动打开【3D 交互式机器人数字样机】...
echo   2. 正在为您打开【13张完整机械工程图总册 PDF】与【output 交付目录】...
echo ============================================================================

if exist "打开3D交互式机器人数字样机.html" start "" "%CD%\打开3D交互式机器人数字样机.html"
if exist "output\drawings\SRDP_Complete_Engineering_Drawings_Book_V2.pdf" start "" "%CD%\output\drawings\SRDP_Complete_Engineering_Drawings_Book_V2.pdf"
if defined FC_GUI (
    echo [INFO] 正在启动 FreeCAD 3D 界面加载整机模型...
    start "" "%FC_GUI%" "%CD%\output\step\SRDP_Full_Robot_Assembly.step"
) else (
    start "" "%CD%\output"
)
pause
