@echo off
chcp 65001 >nul
title SRDP 仿生水下机器人 V2.0 - 一键导出工程文件
cd /d "%~dp0.."

echo ============================================================================
echo   正在重新生成并导出全部 FCStd / STEP / STL / DXF / PDF / CSV / XLSX 工程文件...
echo ============================================================================

if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" src\main.py --mode export
) else (
    python src\main.py --mode export
)

echo.
echo 全部工程文件已导出至 output\ 目录并完成重新打开校验！
pause
