@echo off
chcp 65001 >nul
title SRDP 仿生水下机器人 V2.0 - 一键检查模型与运行20项验收测试
cd /d "%~dp0.."

echo ============================================================================
echo   正在执行 SRDP 20项全自动机械验收测试 + 实施总册离线协议与力分配自检...
echo ============================================================================

if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" -m unittest discover -s tests -p "test_*.py" -v
) else (
    python -m unittest discover -s tests -p "test_*.py" -v
)

echo.
echo 碰撞报告: output\reports\Collision_and_Clearance_Report.md
echo 质量浮力报告: output\reports\Mass_and_Buoyancy_Report.md
echo 验收测试报告: output\reports\Validation_and_Acceptance_Test_Report.md
pause
