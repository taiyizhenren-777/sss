#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
统一参数数据库管理器 (Parameter Manager)
负责加载、校验、联动更新并保存 config/*.json 全部 9 类工程参数。
确保修改任意关键参数后，整机零件、框架尺寸、装配坐标、运动学及工程图自动联动更新。
"""
import json
import logging
from pathlib import Path
from typing import Dict, Any, List, Tuple

logger = logging.getLogger("SRDP.ParameterManager")


class ParameterManager:
    REQUIRED_CONFIG_FILES = [
        "robot_parameters.json",
        "servo_parameters.json",
        "thruster_parameters.json",
        "enclosure_parameters.json",
        "fin_parameters.json",
        "frame_parameters.json",
        "material_database.json",
        "motion_parameters.json",
        "uncertain_parameters.json",
    ]

    def __init__(self, project_root: Path = None):
        if project_root is None:
            project_root = Path(__file__).resolve().parent.parent
        self.project_root = Path(project_root)
        self.config_dir = self.project_root / "config"
        self.params: Dict[str, Dict[str, Any]] = {}
        self.derived: Dict[str, Any] = {}
        self.load_all()

    def load_all(self) -> None:
        """加载全部 JSON 参数文件并执行派生参数联动计算。"""
        for fname in self.REQUIRED_CONFIG_FILES:
            fpath = self.config_dir / fname
            if not fpath.exists():
                raise FileNotFoundError(f"关键参数配置文件缺失: {fpath}")
            with open(fpath, "r", encoding="utf-8") as f:
                key = fname.replace(".json", "")
                self.params[key] = json.load(f)
        self._compute_derived_parameters()
        logger.info("已成功加载全部 %d 个参数配置文件并完成参数联动推导。", len(self.params))

    def _compute_derived_parameters(self) -> None:
        """
        根据伺服、电子舱、推进器、鳍片尺寸自动推导框架与装配关联参数，
        禁止在业务模块中硬编码关键尺寸。
        """
        robot = self.params["robot_parameters"]
        servo = self.params["servo_parameters"]["servo_ser2010"]
        hub = self.params["servo_parameters"]["servo_hub_ser0011"]
        cobalt = self.params["servo_parameters"]["cobalt_connector"]
        t200 = self.params["thruster_parameters"]["t200_thruster"]
        enc = self.params["enclosure_parameters"]["watertight_enclosure"]
        fin_cfg = self.params["fin_parameters"]
        frame_cfg = self.params["frame_parameters"]["frame_structure"]

        # 1. 中央垂推通道半径 = T200 外径/2 + 净空余量
        t200_od = float(t200["known_dimensions_mm"]["nozzle_outer_diameter_mm"])
        tunnel_bore_dia = max(float(frame_cfg["central_t200_tunnel_bore_dia_mm"]), t200_od + 16.0)

        # 2. 双水密电子舱 Y 向中心距自动约束：不得遮挡 T200 通道且留出安装夹具空间
        enc_od = float(enc["dimensions_mm"]["outer_diameter_mm"])
        min_enc_y = (tunnel_bore_dia / 2.0) + (enc_od / 2.0) + 12.0
        actual_enc_y = max(abs(float(enc["layout_strategy"]["left_enclosure_pos_mm"][1])), min_enc_y)

        # 3. 四鳍模块安装基座径向坐标 (a, b) 自动约束：必须容纳水密舱开盖/拔线空间与 T200
        enc_total_len = float(enc["dimensions_mm"]["overall_length_with_endcaps_mm"])
        enc_open_clr = float(enc["dimensions_mm"]["endcap_open_clearance_mm"])
        min_lever_a = (enc_total_len / 2.0) + enc_open_clr + 25.0
        min_lever_b = actual_enc_y + (enc_od / 2.0) + 30.0

        lever_a = max(float(robot["fin_layout"]["lever_arm_a_mm"]), min_lever_a)
        lever_b = max(float(robot["fin_layout"]["lever_arm_b_mm"]), min_lever_b)

        # 4. 单鳍模块串联径向总长计算 (S轴中心 -> P轴中心 -> 毂端面 -> 鳍片尖端)
        s_to_p = float(fin_cfg["fin_module_mechanics"]["s_to_p_radial_offset_mm"])
        p_case_len = float(servo["reconstructed_placeholder_dimensions_mm"]["case_length_mm"])
        hub_thick = float(hub["reconstructed_placeholder_dimensions_mm"]["thickness_mm"])
        fin_fs_exposed = float(fin_cfg["variants"]["F-S"]["exposed_effective_length_mm"])
        fin_fl_exposed = float(fin_cfg["variants"]["F-L"]["exposed_effective_length_mm"])

        module_reach_fs = s_to_p + p_case_len + hub_thick + fin_fs_exposed
        module_reach_fl = s_to_p + p_case_len + hub_thick + fin_fl_exposed

        # 5. 底部脚架离地高度自动推导：确保大鳍竖直向下或 T200 最低点均留有 >= 45mm 安全净空
        t200_len = float(t200["known_dimensions_mm"]["overall_length_mm"])
        fin_half_width = float(fin_cfg["common_root_clamping"]["fin_width_mm"]) / 2.0
        lowest_active_z = max(t200_len / 2.0 + 15.0, fin_half_width + 45.0)
        skid_bottom_z = max(float(frame_cfg["landing_skid_bottom_z_mm"]), lowest_active_z + 45.0)

        self.derived = {
            "tunnel_bore_dia_mm": round(tunnel_bore_dia, 2),
            "enclosure_y_offset_mm": round(actual_enc_y, 2),
            "lever_arm_a_mm": round(lever_a, 2),
            "lever_arm_b_mm": round(lever_b, 2),
            "frame_core_length_x_mm": round(2.0 * lever_a, 2),
            "frame_core_width_y_mm": round(2.0 * lever_b, 2),
            "module_radial_reach_fs_mm": round(module_reach_fs, 2),
            "module_radial_reach_fl_mm": round(module_reach_fl, 2),
            "max_span_x_fs_mm": round(2.0 * (lever_a + module_reach_fs), 2),
            "max_span_y_fs_mm": round(2.0 * (lever_b + module_reach_fs), 2),
            "max_span_x_fl_mm": round(2.0 * (lever_a + module_reach_fl), 2),
            "max_span_y_fl_mm": round(2.0 * (lever_b + module_reach_fl), 2),
            "skid_bottom_z_mm": round(skid_bottom_z, 2),
            "cobalt_min_bend_radius_mm": float(cobalt["dimensions_mm"]["min_bend_radius_mm"]),
        }

    def validate_completeness_and_units(self) -> Tuple[bool, List[str]]:
        """校验参数完整性与单位一致性 (用于第 1、2 项自动测试)。"""
        messages = []
        ok = True
        for fname in self.REQUIRED_CONFIG_FILES:
            key = fname.replace(".json", "")
            if key not in self.params or not self.params[key]:
                ok = False
                messages.append(f"缺失配置模块: {key}")

        # 检查坐标系定义是否为右手系 X前 Y右 Z下
        coord = self.params["robot_parameters"]["coordinate_system"]
        if coord["X_axis"]["vector"] != [1.0, 0.0, 0.0] or coord["Y_axis"]["vector"] != [0.0, 1.0, 0.0] or coord["Z_axis"]["vector"] != [0.0, 0.0, 1.0]:
            ok = False
            messages.append("坐标系定义不符合 X前[1,0,0]、Y右[0,1,0]、Z下[0,0,1] 规定")

        # 检查单位一致性
        if self.params["robot_parameters"]["meta"]["unit_length"] != "mm":
            ok = False
            messages.append("长度单位未统一为 mm")

        # 检查三种鳍片规格是否齐全且标注为待确认试验起点
        variants = self.params["fin_parameters"]["variants"]
        for v_code, expected_len in [("F-S", 80.0), ("F-M", 110.0), ("F-L", 140.0)]:
            if v_code not in variants:
                ok = False
                messages.append(f"缺失鳍片规格: {v_code}")
            else:
                v = variants[v_code]
                if float(v["total_length_mm"]) != expected_len or float(v["width_mm"]) != 40.0 or float(v["thickness_mm"]) != 0.5:
                    ok = False
                    messages.append(f"鳍片 {v_code} 尺寸不符合 {expected_len}x40x0.5 mm")
                if "TRIAL" not in v.get("status", "") and "PENDING" not in self.params["fin_parameters"].get("verification_status", ""):
                    ok = False
                    messages.append(f"鳍片 {v_code} 未标记为待确认的设计起始参数")

        if ok:
            messages.append("全部 9 个 JSON 参数库完整性与单位一致性(mm/deg/g/N)校验通过。")
        return ok, messages

    def get(self, category: str) -> Dict[str, Any]:
        return self.params[category]

    def get_uncertain_list(self) -> List[Dict[str, Any]]:
        return self.params["uncertain_parameters"]["items"]
