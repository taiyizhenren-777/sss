#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
水密电子舱安装座与拆装/拔线维护空间包络生成器 (Enclosure Mount & Maintenance Clearance Generator)
遵循任务要求第五部分 5.1 与实施总册第 17、26 页：
- 生成 4 套半圆抱箍式水密电子舱安装夹具 (MFG-ENC-CRADLE x4)
- 明确预留并建模：前后端盖开启空间 (65mm)、电缆插拔与弯曲维护空间包络
"""
from typing import Dict, Any, List
import numpy as np
from .component_library import (
    SolidPart, HoleFeature, make_box_mesh, make_tube_mesh, combine_meshes, trans
)
from .purchased_components import build_watertight_enclosure_solid


def build_enclosure_system(enc_cfg: Dict[str, Any], derived: Dict[str, Any]) -> List[SolidPart]:
    parts: List[SolidPart] = []
    wte = enc_cfg["watertight_enclosure"]
    dims = wte["dimensions_mm"]
    od = float(dims["outer_diameter_mm"])          # 114.0 mm
    saddle_w = float(dims["clamp_saddle_width_mm"]) # 24.0 mm
    enc_y = float(derived["enclosure_y_offset_mm"]) # 110.0 mm
    enc_z = -5.0

    # 1. 左右两套成品水密电子舱 (左舱 WTE-L: 逻辑与传感舱; 右舱 WTE-R: 动力降压与K1安全配电舱)
    for code, suffix, y_pos in [
        ("WTE-LEFT", "左舷逻辑与传感干舱 (STM32+IMU+Bar02+RS485)", -enc_y),
        ("WTE-RIGHT", "右舷动力与安全接触器干舱 (K1+4×6V+12V DC/DC)", enc_y),
    ]:
        parts.append(build_watertight_enclosure_solid(
            wte, instance_id=code, name_suffix=suffix,
            transform_world=trans(0.0, y_pos, enc_z)
        ))

        # 每个水密舱配置前后 2 套可拆卸半圆抱箍安装座 (固定于 X = ±70 mm)
        for c_idx, x_pos in enumerate([70.0, -70.0], start=1):
            v_ring, f_ring, vol_r = make_tube_mesh(od / 2.0 + 8.0, od / 2.0, saddle_w, axis="X", center=(0.0, 0.0, 0.0), segments=28)
            v_foot, f_foot, vol_f = make_box_mesh(saddle_w, 136.0, 8.0, center=(0.0, 0.0, 10.0))
            vc, fc, volc = combine_meshes([(v_ring, f_ring, vol_r), (v_foot, f_foot, vol_f)])

            parts.append(SolidPart(
                part_id="MFG-ENC-CRADLE",
                instance_id=f"ENC-CRADLE-{code[-1]}-{c_idx}",
                name_cn=f"水密电子舱抱箍安装座 ({code}-{c_idx})",
                name_en=f"Watertight Enclosure Clamp Cradle ({code}-{c_idx})",
                category="MANUFACTURED_PRINT",
                subsystem="ENCLOSURE",
                material_code="PETG_3D_PRINTED",
                credibility_level="SELF_DESIGN",
                ver_version="2.0",
                vertices_local=vc,
                faces=fc,
                analytic_volume_mm3=volc * 0.72,
                plate_thickness_mm=saddle_w,
                holes_2d=[
                    HoleFeature(0.0, 0.0, od, "THROUGH", f"Ø{od:.1f} 水密舱外径抱紧孔 (配EPDM防滑胶垫)", saddle_w, True),
                    HoleFeature(0.0, -62.0, 4.2, "THROUGH", "Ø4.2 抱箍锁紧与框架安装孔 (M4)", saddle_w, False),
                    HoleFeature(0.0, 62.0, 4.2, "THROUGH", "Ø4.2 抱箍锁紧与框架安装孔 (M4)", saddle_w, False),
                ],
                outline_2d=[(-68.0, -65.0), (68.0, -65.0), (68.0, 65.0), (-68.0, 65.0)],
                dimensions_summary={"bore_dia_mm": od, "width_mm": saddle_w, "bolt_spacing_mm": 124.0},
                uncertain_flags=["UNC-004: 抱箍内径随最终所购成品水密舱外径公差微调"],
                source_reference="实施总册 P13, P17, P26",
                color_rgb=(0.22, 0.45, 0.65),
                transform_world=trans(x_pos, y_pos, enc_z),
                freecad_recipe={"type": "Enclosure_Cradle", "bore": od, "width": saddle_w}
            ))

    return parts
