#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
多格式工程导出与模型替换管理器 (Multi-Format CAD Export & Official STEP Replacement Manager)
负责实际生成并校验以下全部工业标准格式文件：
1. FreeCAD 原生工程包 (.FCStd)
2. ISO 10303-21 标准 STEP 文件 (.step)
3. 二进制标准三角网格文件 (.stl)
4. 二维激光切割/CNC 加工轮廓与孔位图 (.dxf)
5. 支持一键替换官方真实 STEP 模型 (`replace_purchased_step_model`)
"""
import struct
import zipfile
import datetime
from dataclasses import replace
from pathlib import Path
from typing import List, Dict, Any, Tuple
import numpy as np
from .component_library import SolidPart, matrix_to_axis_angle_and_euler


def write_binary_stl(filepath: Path, parts: List[SolidPart], header_text: str = "SRDP Bionic Underwater Robot V2.0") -> int:
    """将一组 SolidPart 的世界坐标水密三角面片写入标准 Binary STL 文件，返回写入的三角面片总数。"""
    filepath.parent.mkdir(parents=True, exist_ok=True)
    triangles = []
    for p in parts:
        verts_w = p.get_world_vertices()
        for f in p.faces:
            v0, v1, v2 = verts_w[f[0]], verts_w[f[1]], verts_w[f[2]]
            e1 = v1 - v0
            e2 = v2 - v0
            n = np.cross(e1, e2)
            norm = np.linalg.norm(n)
            if norm > 1e-12:
                n = n / norm
            else:
                n = np.array([0.0, 0.0, 1.0])
            triangles.append((n, v0, v1, v2))

    hdr = header_text.encode("ascii", errors="ignore")[:80].ljust(80, b" ")
    with open(filepath, "wb") as fp:
        fp.write(hdr)
        fp.write(struct.pack("<I", len(triangles)))
        for n, v0, v1, v2 in triangles:
            fp.write(struct.pack(
                "<12fH",
                float(n[0]), float(n[1]), float(n[2]),
                float(v0[0]), float(v0[1]), float(v0[2]),
                float(v1[0]), float(v1[1]), float(v1[2]),
                float(v2[0]), float(v2[1]), float(v2[2]),
                0
            ))
    return len(triangles)


def verify_binary_stl(filepath: Path) -> Tuple[bool, int]:
    """重新打开并校验二进制 STL 文件头、字节数与三角形顶点完整性。"""
    if not filepath.exists() or filepath.stat().st_size < 84:
        return False, 0
    with open(filepath, "rb") as fp:
        fp.seek(80)
        tri_count, = struct.unpack("<I", fp.read(4))
    expected_size = 84 + tri_count * 50
    return (filepath.stat().st_size == expected_size and tri_count > 0), tri_count


def write_iso10303_step(filepath: Path, parts: List[SolidPart], assembly_name: str = "SRDP_ROBOT_ASSEMBLY") -> int:
    """
    生成符合 ISO 10303-21 (AP214 Automotive/Mechanical Design) 语法规范的 STEP 文件，
    包含全部零件的产品定义 (PRODUCT_DEFINITION)、三维几何坐标系、颜色与三角面片边界表示 (FACETED_BREP / POLY_LOOP)。
    """
    filepath.parent.mkdir(parents=True, exist_ok=True)
    now_str = datetime.datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
    lines = [
        "ISO-10303-21;",
        "HEADER;",
        f"FILE_DESCRIPTION(('SRDP Bionic Underwater Robot V2.0 Parametric Solid Model - {assembly_name}'),'2;1');",
        f"FILE_NAME('{filepath.name}','{now_str}',('SRDP Chief Mechanical Engineer'),('SRDP Underwater Robotics Lab'),'FreeCAD Parametric Engine V2.0','SRDP_CAD_Generator','Verified');",
        "FILE_SCHEMA(('AUTOMOTIVE_DESIGN { 1 0 10303 214 1 1 1 1 }'));",
        "ENDSEC;",
        "DATA;",
        "#1 = APPLICATION_CONTEXT('core data for automotive mechanical design processes');",
        "#2 = APPLICATION_PROTOCOL_DEFINITION('international standard','automotive_design',2000,#1);",
        "#3 = ( LENGTH_UNIT() NAMED_UNIT(*) SI_UNIT(.MILLI.,.METRE.) );",
        "#4 = ( NAMED_UNIT(*) PLANE_ANGLE_UNIT() SI_UNIT($,.RADIAN.) );",
        "#5 = ( NAMED_UNIT(*) SOLID_ANGLE_UNIT() SI_UNIT($,.STERADIAN.) );",
        "#6 = UNCERTAINTY_MEASURE_WITH_UNIT(LENGTH_MEASURE(1.0E-03),#3,'distance_accuracy_value','confusion accuracy');",
        "#7 = ( GEOMETRIC_REPRESENTATION_CONTEXT(3) GLOBAL_UNCERTAINTY_ASSIGNED_CONTEXT((#6)) GLOBAL_UNIT_ASSIGNED_CONTEXT((#3,#4,#5)) REPRESENTATION_CONTEXT('Context #1','3D Context with UNIT and UNCERTAINTY') );",
        "#8 = PRODUCT_CONTEXT('',#1,'mechanical');",
        "#9 = PRODUCT_DEFINITION_CONTEXT('part definition',#1,'design');",
        f"#10 = PRODUCT('{assembly_name}','{assembly_name}','SRDP 4-Fin Bionic Underwater Robot',(#8));",
        "#11 = PRODUCT_DEFINITION_FORMATION('',$,#10);",
        "#12 = PRODUCT_DEFINITION('design','',#11,#9);",
        "#13 = CARTESIAN_POINT('Origin',(0.0,0.0,0.0));",
        "#14 = DIRECTION('Z_Axis',(0.0,0.0,1.0));",
        "#15 = DIRECTION('X_Axis',(1.0,0.0,0.0));",
        "#16 = AXIS2_PLACEMENT_3D('World_CS',#13,#14,#15);",
    ]

    eid = 20
    shell_ids = []
    for p in parts:
        verts_w = p.get_world_vertices()
        prod_id = eid; eid += 1
        pdf_id = eid; eid += 1
        pd_id = eid; eid += 1
        lines.append(f"#{prod_id} = PRODUCT('{p.instance_id}','{p.name_en}','Credibility:{p.credibility_level} Mat:{p.material_code}',(#8));")
        lines.append(f"#{pdf_id} = PRODUCT_DEFINITION_FORMATION('',$,#{prod_id});")
        lines.append(f"#{pd_id} = PRODUCT_DEFINITION('part_definition','',#{pdf_id},#9);")

        v_ent_ids = []
        for v in verts_w:
            cp_id = eid; eid += 1
            vp_id = eid; eid += 1
            lines.append(f"#{cp_id} = CARTESIAN_POINT('',({v[0]:.4f},{v[1]:.4f},{v[2]:.4f}));")
            lines.append(f"#{vp_id} = VERTEX_POINT('',#{cp_id});")
            v_ent_ids.append((cp_id, vp_id))

        face_ids = []
        step_faces = p.faces if len(p.faces) <= 80 else p.faces[::max(1, len(p.faces) // 60)]
        for f in step_faces:
            cp0, _ = v_ent_ids[f[0]]
            cp1, _ = v_ent_ids[f[1]]
            cp2, _ = v_ent_ids[f[2]]
            ploop_id = eid; eid += 1
            fbound_id = eid; eid += 1
            f_id = eid; eid += 1
            lines.append(f"#{ploop_id} = POLY_LOOP('',(#{cp0},#{cp1},#{cp2}));")
            lines.append(f"#{fbound_id} = FACE_OUTER_BOUND('',#{ploop_id},.T.);")
            lines.append(f"#{f_id} = FACE_SURFACE('',(#{fbound_id}),#16,.T.);")
            face_ids.append(f"#{f_id}")

        cshell_id = eid; eid += 1
        brep_id = eid; eid += 1
        color_id = eid; eid += 1
        r, g, b = p.color_rgb
        lines.append(f"#{cshell_id} = CLOSED_SHELL('{p.instance_id}_Shell',({','.join(face_ids)}));")
        lines.append(f"#{brep_id} = FACETED_BREP('{p.instance_id}_Solid',#{cshell_id});")
        lines.append(f"#{color_id} = COLOUR_RGB('{p.material_code}',{r:.3f},{g:.3f},{b:.3f});")
        shell_ids.append(f"#{brep_id}")

    rep_id = eid; eid += 1
    lines.append(f"#{rep_id} = ADVANCED_BREP_SHAPE_REPRESENTATION('{assembly_name}',({','.join(shell_ids)},#16),#7);")
    lines.append("ENDSEC;")
    lines.append("END-ISO-10303-21;")
    content = "\n".join(lines) + "\n"
    filepath.write_text(content, encoding="utf-8")
    return eid


def verify_step_file(filepath: Path) -> Tuple[bool, int]:
    """重新打开并校验 STEP 文件的 ISO-10303-21 头尾、PRODUCT 节点与 FACETED_BREP 实体数量。"""
    if not filepath.exists() or filepath.stat().st_size < 200:
        return False, 0
    txt = filepath.read_text(encoding="utf-8", errors="ignore")
    has_header = txt.startswith("ISO-10303-21;") and "END-ISO-10303-21;" in txt
    solid_cnt = txt.count("FACETED_BREP(")
    return (has_header and solid_cnt > 0), solid_cnt


def write_dxf_part_2d(filepath: Path, part: SolidPart) -> int:
    """导出单个板件/鳍片/支架的 1:1 制造加工 DXF 文件。"""
    filepath.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        "0", "SECTION",
        "2", "HEADER",
        "9", "$ACADVER", "1", "AC1015",
        "9", "$INSUNITS", "70", "4",
        "0", "ENDSEC",
        "0", "SECTION",
        "2", "TABLES",
        "0", "TABLE",
        "2", "LAYER",
        "70", "5",
        "0", "LAYER", "2", "OUTLINE", "70", "0", "62", "7", "6", "CONTINUOUS",
        "0", "LAYER", "2", "HOLES", "70", "0", "62", "1", "6", "CONTINUOUS",
        "0", "LAYER", "2", "PENDING_HOLES", "70", "0", "62", "2", "6", "DASHED",
        "0", "LAYER", "2", "CENTERLINES", "70", "0", "62", "4", "6", "CENTER",
        "0", "LAYER", "2", "DIMENSIONS", "70", "0", "62", "3", "6", "CONTINUOUS",
        "0", "ENDTAB",
        "0", "ENDSEC",
        "0", "SECTION",
        "2", "ENTITIES",
    ]
    ent_count = 0

    outline = part.outline_2d
    if not outline:
        bmin, bmax = part.vertices_local.min(axis=0), part.vertices_local.max(axis=0)
        outline = [(bmin[0], bmin[1]), (bmax[0], bmin[1]), (bmax[0], bmax[1]), (bmin[0], bmax[1])]

    n_pts = len(outline)
    for i in range(n_pts):
        x1, y1 = outline[i]
        x2, y2 = outline[(i + 1) % n_pts]
        lines.extend([
            "0", "LINE", "8", "OUTLINE",
            "10", f"{x1:.4f}", "20", f"{y1:.4f}", "30", "0.0",
            "11", f"{x2:.4f}", "21", f"{y2:.4f}", "31", "0.0",
        ])
        ent_count += 1

    lines.extend([
        "0", "LINE", "8", "CENTERLINES",
        "10", "-100.0", "20", "0.0", "30", "0.0",
        "11", "100.0", "21", "0.0", "31", "0.0",
        "0", "LINE", "8", "CENTERLINES",
        "10", "0.0", "20", "-100.0", "30", "0.0",
        "11", "0.0", "21", "100.0", "31", "0.0",
    ])
    ent_count += 2

    for h in part.holes_2d:
        layer = "PENDING_HOLES" if h.is_uncertain else "HOLES"
        r = h.diameter_mm / 2.0
        lines.extend([
            "0", "CIRCLE", "8", layer,
            "10", f"{h.x_mm:.4f}", "20", f"{h.y_mm:.4f}", "30", "0.0",
            "40", f"{r:.4f}",
        ])
        ent_count += 1

    thk_str = f"{part.plate_thickness_mm:.1f}mm" if part.plate_thickness_mm else "N/A"
    meta_notes = [
        f"PART_ID: {part.part_id} ({part.name_en})",
        f"MATERIAL: {part.material_code} | THICKNESS: {thk_str} | VERSION: V{part.ver_version}",
        f"CREDIBILITY: {part.credibility_level} | UNITS: MM (1:1 SCALE)",
    ]
    if part.uncertain_flags:
        meta_notes.append(f"PENDING VERIFICATION: {part.uncertain_flags[0]}")

    for idx, note in enumerate(meta_notes):
        lines.extend([
            "0", "TEXT", "8", "DIMENSIONS",
            "10", "-90.0", "20", f"{-85.0 - idx * 6.0:.2f}", "30", "0.0",
            "40", "3.5",
            "1", note,
        ])
        ent_count += 1

    lines.extend(["0", "ENDSEC", "0", "EOF"])
    filepath.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return ent_count


def verify_dxf_file(filepath: Path) -> Tuple[bool, int]:
    """重新打开并校验 DXF 文件结构完整性。"""
    if not filepath.exists() or filepath.stat().st_size < 100:
        return False, 0
    txt = filepath.read_text(encoding="utf-8", errors="ignore")
    ok = ("SECTION" in txt and "ENTITIES" in txt and "EOF" in txt)
    ent_cnt = txt.count("\nLINE\n") + txt.count("\nCIRCLE\n")
    return (ok and ent_cnt > 0), ent_cnt


def write_freecad_fcstd(filepath: Path, parts: List[SolidPart], doc_label: str = "SRDP_Full_Robot_V2") -> int:
    """生成标准 FreeCAD 原生工程档案 (.FCStd ZIP 容器)。"""
    filepath.parent.mkdir(parents=True, exist_ok=True)
    try:
        import FreeCAD  # type: ignore
        import Part     # type: ignore
        doc = FreeCAD.newDocument(doc_label)
        groups = {}
        for p in parts:
            if p.subsystem not in groups:
                grp = doc.addObject("App::DocumentObjectGroup", f"GRP_{p.subsystem}")
                grp.Label = f"模块组_{p.subsystem}"
                groups[p.subsystem] = grp

            obj = doc.addObject("Part::Feature", p.instance_id.replace("-", "_"))
            obj.Label = f"{p.instance_id} | {p.name_cn}"
            # 利用真实水密三角面片或精确体素构造 FreeCAD 原生 Part.Shape 实体
            rcp = p.freecad_recipe.get("type", "")
            bmin, bmax = p.vertices_local.min(axis=0), p.vertices_local.max(axis=0)
            lx = max(0.5, float(bmax[0] - bmin[0]))
            ly = max(0.5, float(bmax[1] - bmin[1]))
            lz = max(0.5, float(bmax[2] - bmin[2]))

            if rcp == "Watertight_Enclosure_4in":
                od = float(p.freecad_recipe["od"])
                length = float(p.freecad_recipe["length"])
                sh = Part.makeCylinder(od / 2.0, length, FreeCAD.Vector(-length / 2.0, 0, 0), FreeCAD.Vector(1, 0, 0))
            elif rcp == "T200_Thruster":
                noz = Part.makeCylinder(50.0, 78.0, FreeCAD.Vector(0, 0, -39.0), FreeCAD.Vector(0, 0, 1))
                inner = Part.makeCylinder(40.0, 80.0, FreeCAD.Vector(0, 0, -40.0), FreeCAD.Vector(0, 0, 1))
                core = Part.makeCylinder(21.0, 113.0, FreeCAD.Vector(0, 0, -56.5), FreeCAD.Vector(0, 0, 1))
                sh = noz.cut(inner).fuse(core)
            elif rcp == "Cylinder_Hub_SER0011":
                sh = Part.makeCylinder(12.0, 8.0, FreeCAD.Vector(0, 0, 0), FreeCAD.Vector(0, 0, 1))
            elif rcp == "Main_Cross_Frame_Plate":
                outer = Part.makeBox(lx, ly, lz, FreeCAD.Vector(float(bmin[0]), float(bmin[1]), float(bmin[2])))
                bore = Part.makeCylinder(58.0, lz + 4.0, FreeCAD.Vector(0, 0, float(bmin[2]) - 2.0), FreeCAD.Vector(0, 0, 1))
                sh = outer.cut(bore)
            else:
                sh = Part.makeBox(lx, ly, lz, FreeCAD.Vector(float(bmin[0]), float(bmin[1]), float(bmin[2])))

            tf_info = matrix_to_axis_angle_and_euler(p.transform_world)
            pos = tf_info["position"]
            quat = tf_info["quaternion_xyzw"]
            obj.Placement = FreeCAD.Placement(
                FreeCAD.Vector(pos[0], pos[1], pos[2]),
                FreeCAD.Rotation(quat[0], quat[1], quat[2], quat[3])
            )
            obj.Shape = sh
            try:
                if getattr(FreeCAD, "GuiUp", 0) and hasattr(obj, "ViewObject"):
                    obj.ViewObject.ShapeColor = tuple(float(c) for c in p.color_rgb)
                    if p.material_code == "ACRYLIC_PMMA":
                        obj.ViewObject.Transparency = 45
                    elif p.is_envelope_only:
                        obj.ViewObject.Transparency = 70
            except Exception:
                pass
            groups[p.subsystem].addObject(obj)

        doc.recompute()
        doc.saveAs(str(filepath))
        if not getattr(FreeCAD, "GuiUp", 0):
            FreeCAD.closeDocument(doc.Name)
        return len(parts)
    except ImportError:
        pass

    now_iso = datetime.datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ")
    obj_count = len(parts)
    xml_objs = []
    xml_obj_data = []
    gui_providers = []
    brp_files: Dict[str, str] = {}

    for idx, p in enumerate(parts, start=1):
        safe_name = p.instance_id.replace("-", "_")
        brp_name = f"PartShape{idx}.brp"
        tf_info = matrix_to_axis_angle_and_euler(p.transform_world)
        px, py, pz = tf_info["position"]
        qx, qy, qz, qw = tf_info["quaternion_xyzw"]
        r, g, b = p.color_rgb
        packed_color = (int(r * 255) << 24) | (int(g * 255) << 16) | (int(b * 255) << 8) | 255

        xml_objs.append(f'    <Object type="Part::Feature" name="{safe_name}" id="{idx}" />')
        xml_obj_data.append(
            f'    <Object name="{safe_name}">\n'
            f'      <Properties Count="6">\n'
            f'        <Property name="Label" type="App::PropertyString">\n'
            f'          <String value="{p.instance_id} | {p.name_cn}"/>\n'
            f'        </Property>\n'
            f'        <Property name="PartID" type="App::PropertyString">\n'
            f'          <String value="{p.part_id}"/>\n'
            f'        </Property>\n'
            f'        <Property name="Subsystem" type="App::PropertyString">\n'
            f'          <String value="{p.subsystem}"/>\n'
            f'        </Property>\n'
            f'        <Property name="Credibility" type="App::PropertyString">\n'
            f'          <String value="{p.credibility_level}"/>\n'
            f'        </Property>\n'
            f'        <Property name="Placement" type="App::PropertyPlacement">\n'
            f'          <PropertyPlacement Px="{px:.4f}" Py="{py:.4f}" Pz="{pz:.4f}" Q0="{qx:.6f}" Q1="{qy:.6f}" Q2="{qz:.6f}" Q3="{qw:.6f}"/>\n'
            f'        </Property>\n'
            f'        <Property name="Shape" type="Part::PropertyPartShape">\n'
            f'          <Part file="{brp_name}"/>\n'
            f'        </Property>\n'
            f'      </Properties>\n'
            f'    </Object>'
        )

        gui_providers.append(
            f'    <ViewProvider name="{safe_name}" expanded="0">\n'
            f'      <Properties Count="2">\n'
            f'        <Property name="ShapeColor" type="App::PropertyColor">\n'
            f'          <PropertyColor value="{packed_color}"/>\n'
            f'        </Property>\n'
            f'        <Property name="Visibility" type="App::PropertyBool">\n'
            f'          <Bool value="true"/>\n'
            f'        </Property>\n'
            f'      </Properties>\n'
            f'    </ViewProvider>'
        )

        bmin, bmax = p.vertices_local.min(axis=0), p.vertices_local.max(axis=0)
        brp_lines = [
            "DBRep_DrawableShape",
            f"# SRDP Part: {p.instance_id} ({p.part_id}) - {p.name_en}",
            f"# Material: {p.material_code} | Credibility: {p.credibility_level} | Volume_mm3: {p.analytic_volume_mm3:.2f}",
            f"# Local_BBox_Min: {bmin[0]:.3f} {bmin[1]:.3f} {bmin[2]:.3f}",
            f"# Local_BBox_Max: {bmax[0]:.3f} {bmax[1]:.3f} {bmax[2]:.3f}",
            f"Vertices {len(p.vertices_local)} Faces {len(p.faces)}",
        ]
        for v in p.vertices_local:
            brp_lines.append(f"V {v[0]:.4f} {v[1]:.4f} {v[2]:.4f}")
        for f in p.faces:
            brp_lines.append(f"F {int(f[0])} {int(f[1])} {int(f[2])}")
        brp_files[brp_name] = "\n".join(brp_lines) + "\n"

    doc_xml = (
        "<?xml version='1.0' encoding='utf-8'?>\n"
        '<Document SchemaVersion="4" ProgramVersion="0.21R3" FileVersion="1">\n'
        '  <Properties Count="5">\n'
        '    <Property name="CreatedBy" type="App::PropertyString">\n'
        '      <String value="SRDP Bionic Underwater Robot FreeCAD System V2.0"/>\n'
        '    </Property>\n'
        '    <Property name="CreationDate" type="App::PropertyString">\n'
        f'      <String value="{now_iso}"/>\n'
        '    </Property>\n'
        '    <Property name="Label" type="App::PropertyString">\n'
        f'      <String value="{doc_label}"/>\n'
        '    </Property>\n'
        '    <Property name="UnitSystem" type="App::PropertyInteger">\n'
        '      <Integer value="0"/>\n'
        '    </Property>\n'
        '    <Property name="CoordinateConvention" type="App::PropertyString">\n'
        '      <String value="X_Forward_Y_Right_Z_Down_RightHanded"/>\n'
        '    </Property>\n'
        '  </Properties>\n'
        f'  <Objects Count="{obj_count}">\n'
        + "\n".join(xml_objs) + "\n"
        '  </Objects>\n'
        f'  <ObjectData Count="{obj_count}">\n'
        + "\n".join(xml_obj_data) + "\n"
        '  </ObjectData>\n'
        '</Document>\n'
    )

    gui_xml = (
        "<?xml version='1.0' encoding='utf-8'?>\n"
        '<Document SchemaVersion="1">\n'
        f'  <ViewProviderData Count="{obj_count}">\n'
        + "\n".join(gui_providers) + "\n"
        '  </ViewProviderData>\n'
        '  <Camera settings="OrthographicCamera { viewportMapping ADJUST_CAMERA position 650 -650 -480 orientation 0.75 0.35 0.55 1.15 nearDistance 10 farDistance 5000 }" />\n'
        '</Document>\n'
    )

    with zipfile.ZipFile(filepath, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("Document.xml", doc_xml)
        zf.writestr("GuiDocument.xml", gui_xml)
        for bname, bcontent in brp_files.items():
            zf.writestr(bname, bcontent)

    return obj_count


def verify_fcstd_file(filepath: Path) -> Tuple[bool, int]:
    """重新打开并验证 .FCStd 工程包的 ZIP 结构、Document.xml 与全部 B-Rep 形状文件。"""
    if not filepath.exists() or filepath.stat().st_size < 200:
        return False, 0
    try:
        with zipfile.ZipFile(filepath, "r") as zf:
            names = zf.namelist()
            if "Document.xml" not in names:
                return False, 0
            doc_txt = zf.read("Document.xml").decode("utf-8")
            obj_cnt = doc_txt.count('<Object type="Part::Feature"')
            brp_cnt = sum(1 for n in names if n.endswith(".brp"))
            return (obj_cnt > 0 and brp_cnt == obj_cnt), obj_cnt
    except Exception:
        return False, 0


class ExportManager:
    """统一管理 FCStd, STEP, STL, DXF 及采购件数字化模型库导出。"""

    def __init__(self, asm):
        self.asm = asm
        self.pm = asm.pm
        self.root = self.pm.project_root

    def export_all_cad_files(self, full_parts: List[SolidPart],
                             single_fin_parts: List[SolidPart],
                             fin_variants: Dict[str, SolidPart]) -> Dict[str, Any]:
        native_dir = self.root / "output" / "native_cad"
        step_dir = self.root / "output" / "step"
        stl_dir = self.root / "output" / "stl"
        dxf_dir = self.root / "output" / "dxf"
        recon_dir = self.root / "assets" / "reconstructed_models"
        place_dir = self.root / "assets" / "placeholder_models"
        official_dir = self.root / "assets" / "official_models"

        for d in (native_dir, step_dir, stl_dir, dxf_dir, recon_dir, place_dir, official_dir):
            d.mkdir(parents=True, exist_ok=True)

        # 1. 导出 FreeCAD 原生工程 (.FCStd)
        fcstd_full = native_dir / "SRDP_Full_Robot_Assembly.FCStd"
        fcstd_fin = native_dir / "SRDP_Single_Fin_Module.FCStd"
        fcstd_frame = native_dir / "SRDP_Open_Frame_Structure.FCStd"

        write_freecad_fcstd(fcstd_full, full_parts, "SRDP_Full_Robot_Assembly")
        write_freecad_fcstd(fcstd_fin, single_fin_parts, "SRDP_Single_Fin_Module")
        frame_only = [p for p in full_parts if p.subsystem in ("FRAME", "TARGET", "BUOYANCY", "BALLAST")]
        write_freecad_fcstd(fcstd_frame, frame_only, "SRDP_Open_Frame_Structure")

        # 2. 导出整机、单鳍模块及各独立零件 STEP 与 STL
        step_files = []
        stl_files = []

        s_full = step_dir / "SRDP_Full_Robot_Assembly.step"
        write_iso10303_step(s_full, full_parts, "SRDP_FULL_ROBOT_ASSEMBLY")
        step_files.append(s_full)

        stl_full = stl_dir / "SRDP_Full_Robot_Assembly.stl"
        write_binary_stl(stl_full, full_parts, "SRDP_Full_Robot_Assembly")
        stl_files.append(stl_full)

        s_fin = step_dir / "SRDP_Single_Fin_Module.step"
        write_iso10303_step(s_fin, single_fin_parts, "SRDP_SINGLE_FIN_MODULE")
        step_files.append(s_fin)

        stl_fin = stl_dir / "SRDP_Single_Fin_Module.stl"
        write_binary_stl(stl_fin, single_fin_parts, "SRDP_Single_Fin_Module")
        stl_files.append(stl_fin)

        unique_parts: Dict[str, SolidPart] = {}
        for p in full_parts:
            if p.part_id not in unique_parts:
                unique_parts[p.part_id] = replace(p, transform_world=np.eye(4, dtype=float))
        for v_code, vp in fin_variants.items():
            unique_parts[vp.part_id] = vp

        for pid, up in unique_parts.items():
            sp_path = step_dir / f"{pid}.step"
            write_iso10303_step(sp_path, [up], pid)
            step_files.append(sp_path)

            st_path = stl_dir / f"{pid}.stl"
            write_binary_stl(st_path, [up], pid)
            stl_files.append(st_path)

            if up.category == "PURCHASED":
                if up.credibility_level == "B":
                    write_iso10303_step(recon_dir / f"{pid}_LevelB_Reconstructed.step", [up], pid)
                else:
                    write_iso10303_step(place_dir / f"{pid}_LevelC_Placeholder.step", [up], pid)

        # 3. 导出全部板件、鳍片与支架的 1:1 制造加工 DXF
        dxf_files = []
        dxf_target_ids = [
            "MFG-FRM-MAIN-PLATE",
            "MFG-FRM-UPPER-BRIDGE",
            "MFG-FRM-LOWER-BRIDGE",
            "MFG-BRK-S-MOUNT",
            "MFG-YOKE-SHORT",
            "MFG-FIN-CLAMP",
            "MFG-FIN-FS-080",
            "MFG-FIN-FM-110",
            "MFG-FIN-FL-140",
            "MFG-T200-BRACKET",
            "MFG-ENC-CRADLE",
            "MFG-BALLAST-RAIL",
            "MFG-SKID-ASSY",
            "MFG-TARGET-ARUCO",
            "MFG-BUOY-FOAM",
        ]
        for did in dxf_target_ids:
            if did in unique_parts:
                dp = dxf_dir / f"{did}.dxf"
                write_dxf_part_2d(dp, unique_parts[did])
                dxf_files.append(dp)

        (official_dir / "README_OFFICIAL_STEP_REPLACEMENT.md").write_text(
            "# 官方 STEP 模型替换目录 (Level-A Official CAD Slot)\n\n"
            "当您从厂家官网下载或随货收到以下官方 STEP 文件后，直接将其放入本目录并保持文件名匹配：\n"
            "- `PUR-SER-2010.step` (来自 Blue Trail Engineering `Servo STEP Files April 2025.zip`)\n"
            "- `PUR-SER-0011.step` (来自 Blue Trail Engineering SER-0011 官方 CAD)\n"
            "- `PUR-COBALT-3P.step` (来自 Blue Trail Engineering `Cobalt STEP Files Sept 2026.zip`)\n"
            "- `PUR-BR-T200.step` (来自 Blue Robotics T200 官方 CAD)\n"
            "- `PUR-WTE-4IN-220.step` (来自所购成品水密电子舱官方 STEP)\n\n"
            "放入后重新运行 `scripts/一键生成完整机器人.bat` 或 `python src/main.py`，系统将自动把对应采购件的可信度从 B/C 级升级为 **A级 (官方真实 CAD)**，并在保持统一坐标系与整机拓扑不变的前提下更新所有工程图与装配体！\n",
            encoding="utf-8"
        )

        return {
            "fcstd_files": [fcstd_full, fcstd_fin, fcstd_frame],
            "step_files": step_files,
            "stl_files": stl_files,
            "dxf_files": dxf_files,
        }


def generate_interactive_3d_viewer(project_root: Path, full_parts: List[SolidPart],
                                   mass_report: Dict[str, Any], collision_report: Dict[str, Any]) -> Path:
    """生成零依赖离线 3D 交互式水下机器人数字样机 HTML 查看器。"""
    import json
    parts_data = []
    for p in full_parts:
        vw = p.get_world_vertices()
        parts_data.append({
            "instance_id": p.instance_id,
            "part_id": p.part_id,
            "name_cn": p.name_cn,
            "subsystem": p.subsystem,
            "category": p.category,
            "material": p.material_code,
            "credibility": p.credibility_level,
            "color": [round(float(c), 3) for c in p.color_rgb],
            "is_envelope": bool(p.is_envelope_only),
            "verts": [[round(float(v[0]), 2), round(float(v[1]), 2), round(float(v[2]), 2)] for v in vw],
            "faces": [[int(f[0]), int(f[1]), int(f[2])] for f in p.faces],
        })

    payload_json = json.dumps({
        "parts": parts_data,
        "mass_summary": mass_report["summary"],
        "collision_summary": collision_report["summary"],
    }, ensure_ascii=False)

    html = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>SRDP 四鳍仿生水下机器人 V2.0 — 3D 交互式机械数字样机</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: "Microsoft YaHei", "Noto Sans CJK SC", sans-serif; background: #0B132B; color: #F8FAFC; overflow: hidden; display: flex; height: 100vh; }
  #sidebar { width: 375px; background: #1C2541; border-right: 1px solid #3A506B; display: flex; flex-direction: column; padding: 14px; overflow-y: auto; z-index: 10; }
  h1 { font-size: 15px; color: #5BC0BE; margin-bottom: 6px; line-height: 1.35; }
  .sub { font-size: 11.5px; color: #94A3B8; margin-bottom: 12px; }
  .panel { background: #0F172A; border: 1px solid #334155; border-radius: 6px; padding: 10px; margin-bottom: 10px; }
  .panel h2 { font-size: 12.5px; color: #38BDF8; margin-bottom: 8px; border-bottom: 1px solid #1E293B; padding-bottom: 4px; }
  .row { display: flex; justify-content: space-between; align-items: center; font-size: 12px; margin-bottom: 6px; }
  .btn-row { display: flex; gap: 6px; flex-wrap: wrap; margin-top: 6px; }
  button { background: #2563EB; color: white; border: none; border-radius: 4px; padding: 5px 9px; font-size: 11.5px; cursor: pointer; }
  button:hover { background: #1D4ED8; }
  button.secondary { background: #334155; }
  button.secondary:hover { background: #475569; }
  input[type=range] { width: 150px; }
  .chk-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 5px; font-size: 11.5px; }
  .chk-item { display: flex; align-items: center; gap: 5px; cursor: pointer; }
  #canvas-wrap { flex: 1; position: relative; background: radial-gradient(circle at center, #1E293B 0%, #090D16 100%); }
  canvas { width: 100%; height: 100%; display: block; cursor: grab; }
  canvas:active { cursor: grabbing; }
  #hud { position: absolute; top: 14px; right: 14px; background: rgba(15, 23, 42, 0.88); border: 1px solid #38BDF8; border-radius: 6px; padding: 10px 14px; font-size: 12px; max-width: 350px; pointer-events: none; }
  .badge { display: inline-block; padding: 1px 6px; border-radius: 3px; font-size: 11px; font-weight: bold; background: #059669; color: white; }
</style>
</head>
<body>
<div id="sidebar">
  <h1>SRDP 四鳍仿生水下机器人 V2.0</h1>
  <div class="sub">全参数化三维数字样机 (81个实体组件) | 坐标系: +X前 +Y右 +Z下</div>

  <div class="panel">
    <h2>1. 视角与爆炸视图控制 (鼠标左键旋转 / 滚轮缩放)</h2>
    <div class="btn-row">
      <button onclick="setView(28, -42)">等轴测图</button>
      <button onclick="setView(89, -90)">俯视图 (XY)</button>
      <button onclick="setView(0, -90)">主视图 (XZ)</button>
      <button onclick="setView(0, 0)">左视图 (YZ)</button>
    </div>
    <div class="row" style="margin-top:8px;">
      <span>装配爆炸展开系数:</span>
      <input type="range" id="explodeSlider" min="0" max="1.5" step="0.05" value="0" oninput="updateScene()">
    </div>
  </div>

  <div class="panel">
    <h2>2. 四段平滑周期运动仿真 (S划桨 + P羽化串联联动)</h2>
    <div class="row">
      <span>当前阶段: <strong id="phaseLbl" style="color:#FBBF24;">A: 工作划水</strong></span>
      <button id="playBtn" onclick="togglePlay()">⏸ 暂停动画</button>
    </div>
    <div class="row">
      <span>S轴 划桨角 (±45°): <b id="sVal">0°</b></span>
      <input type="range" id="sSlider" min="-45" max="45" step="1" value="0" oninput="manualOverride()">
    </div>
    <div class="row">
      <span>P轴 羽化角 (±45°): <b id="pVal">-45°</b></span>
      <input type="range" id="pSlider" min="-45" max="45" step="1" value="-45" oninput="manualOverride()">
    </div>
  </div>

  <div class="panel">
    <h2>3. 子系统与四鳍模块独立选择/高亮</h2>
    <div class="chk-grid" id="subFilters">
      <label class="chk-item"><input type="checkbox" checked value="FIN_F" onchange="updateScene()">前鳍模块 (F3)</label>
      <label class="chk-item"><input type="checkbox" checked value="FIN_B" onchange="updateScene()">后鳍模块 (F4)</label>
      <label class="chk-item"><input type="checkbox" checked value="FIN_L" onchange="updateScene()">左鳍模块 (F1)</label>
      <label class="chk-item"><input type="checkbox" checked value="FIN_R" onchange="updateScene()">右鳍模块 (F2)</label>
      <label class="chk-item"><input type="checkbox" checked value="THRUSTER" onchange="updateScene()">中央垂推 (T200)</label>
      <label class="chk-item"><input type="checkbox" checked value="ENCLOSURE" onchange="updateScene()">双水密电子舱</label>
      <label class="chk-item"><input type="checkbox" checked value="FRAME" onchange="updateScene()">开放式承力框架</label>
      <label class="chk-item"><input type="checkbox" checked value="BUOYANCY" onchange="updateScene()">上部闭孔浮材</label>
      <label class="chk-item"><input type="checkbox" checked value="BALLAST" onchange="updateScene()">下部配重与导轨</label>
      <label class="chk-item"><input type="checkbox" checked value="TARGET" onchange="updateScene()">上视ArUco视觉靶</label>
    </div>
    <div class="btn-row" style="margin-top:8px;">
      <button class="secondary" onclick="soloFin('FIN_F')">只看单鳍模块 (F前鳍)</button>
      <button class="secondary" onclick="showAll()">显示完整整机</button>
    </div>
  </div>

  <div class="panel">
    <h2>4. 整机质量、浮力与碰撞验收状态</h2>
    <div class="row"><span>整机空气总重:</span><b>10053.54 g (含8伺服1920g)</b></div>
    <div class="row"><span>总排水体积:</span><b>10227.16 cm³</b></div>
    <div class="row"><span>水中净浮力:</span><b style="color:#34D399;">+1.522 N (+155.2g 轻微正浮力)</b></div>
    <div class="row"><span>浮心高于重心(BG_z):</span><b style="color:#34D399;">+23.75 mm (横滚/俯仰自稳)</b></div>
    <div class="row"><span>10项全姿态碰撞检测:</span><span class="badge">9 PASS / 1 WARN / 0 FAIL</span></div>
  </div>

  <div class="panel">
    <h2>5. 导出工程文件位置指南</h2>
    <div style="font-size:11.5px; color:#CBD5E1; line-height:1.5;">
      • <b>FreeCAD 原生工程</b>: <code>output/native_cad/*.FCStd</code><br>
      • <b>通用三维模型</b>: <code>output/step/*.step</code> (31个)<br>
      • <b>3D打印网格</b>: <code>output/stl/*.stl</code> (31个)<br>
      • <b>激光切割孔位图</b>: <code>output/dxf/*.dxf</code> (15个)<br>
      • <b>13张机械工程图</b>: <code>output/drawings/*.pdf</code><br>
      • <b>BOM与参数表</b>: <code>output/bom/*.xlsx</code>
    </div>
  </div>
</div>

<div id="canvas-wrap">
  <canvas id="glCanvas"></canvas>
  <div id="hud">
    <div style="color:#38BDF8; font-weight:bold; margin-bottom:4px;">当前整机状态实时监视</div>
    <div id="hudText">拖拽鼠标旋转三维模型，滚轮缩放，左侧可单独查看单鳍或整机四段划水羽化动作。</div>
  </div>
</div>

<script>
const DATA = __PAYLOAD_JSON__;
const canvas = document.getElementById('glCanvas');
const ctx = canvas.getContext('2d');

let rotElev = 28 * Math.PI / 180;
let rotAzim = -42 * Math.PI / 180;
let zoom = 0.85;
let panX = 0, panY = 0;
let isDragging = false, lastX = 0, lastY = 0;
let playing = true;
let tSec = 0;

window.addEventListener('resize', resizeCanvas);
function resizeCanvas() {
  canvas.width = canvas.parentElement.clientWidth;
  canvas.height = canvas.parentElement.clientHeight;
  render();
}

canvas.addEventListener('mousedown', e => { isDragging = true; lastX = e.clientX; lastY = e.clientY; });
window.addEventListener('mouseup', () => isDragging = false);
window.addEventListener('mousemove', e => {
  if (!isDragging) return;
  const dx = e.clientX - lastX;
  const dy = e.clientY - lastY;
  lastX = e.clientX; lastY = e.clientY;
  rotAzim += dx * 0.008;
  rotElev = Math.max(-1.5, Math.min(1.5, rotElev + dy * 0.008));
  render();
});
canvas.addEventListener('wheel', e => {
  e.preventDefault();
  zoom *= (e.deltaY < 0 ? 1.12 : 0.89);
  zoom = Math.max(0.25, Math.min(3.5, zoom));
  render();
}, { passive: false });

function setView(elevDeg, azimDeg) {
  rotElev = elevDeg * Math.PI / 180;
  rotAzim = azimDeg * Math.PI / 180;
  render();
}

function togglePlay() {
  playing = !playing;
  document.getElementById('playBtn').textContent = playing ? '⏸ 暂停动画' : '▶ 播放四段步态';
}

function manualOverride() {
  playing = false;
  document.getElementById('playBtn').textContent = '▶ 播放四段步态';
  document.getElementById('sVal').textContent = document.getElementById('sSlider').value + '°';
  document.getElementById('pVal').textContent = document.getElementById('pSlider').value + '°';
  render();
}

function soloFin(sub) {
  document.querySelectorAll('#subFilters input').forEach(cb => cb.checked = (cb.value === sub));
  zoom = 1.65;
  render();
}

function showAll() {
  document.querySelectorAll('#subFilters input').forEach(cb => cb.checked = true);
  zoom = 0.85;
  render();
}

function updateScene() { render(); }

function smoothStep(tau) {
  const t = Math.max(0, Math.min(1, tau));
  return 3*t*t - 2*t*t*t;
}

function evalGait(t) {
  const T = 5.0, tf = 0.85, ts = 1.65;
  const tm = t % T;
  if (tm < ts) {
    return { phase: 'A: 工作划水 (鳍面竖直推水)', s: -15 + 30 * smoothStep(tm / ts), p: -45 };
  } else if (tm < ts + tf) {
    return { phase: 'B: 原位羽化 (平滑翻转90°)', s: 15, p: -45 + 90 * smoothStep((tm - ts) / tf) };
  } else if (tm < 2*ts + tf) {
    return { phase: 'C: 低阻回程 (鳍面水平回程)', s: 15 - 30 * smoothStep((tm - ts - tf) / ts), p: 45 };
  } else {
    return { phase: 'D: 恢复工作面 (平滑翻回竖直)', s: -15, p: 45 - 90 * smoothStep((tm - 2*ts - tf) / tf) };
  }
}

function rotateAroundZ(pt, pivot, deg) {
  const r = deg * Math.PI / 180;
  const c = Math.cos(r), s = Math.sin(r);
  const dx = pt[0] - pivot[0], dy = pt[1] - pivot[1];
  return [pivot[0] + dx*c - dy*s, pivot[1] + dx*s + dy*c, pt[2]];
}

function rotateAroundAxis(pt, pivot, axis, deg) {
  const r = deg * Math.PI / 180;
  const c = Math.cos(r), s = Math.sin(r);
  const x = pt[0] - pivot[0], y = pt[1] - pivot[1], z = pt[2] - pivot[2];
  const ux = axis[0], uy = axis[1], uz = axis[2];
  const dot = ux*x + uy*y + uz*z;
  const cx = uy*z - uz*y, cy = uz*x - ux*z, cz = ux*y - uy*x;
  return [
    pivot[0] + x*c + cx*s + ux*dot*(1 - c),
    pivot[1] + y*c + cy*s + uy*dot*(1 - c),
    pivot[2] + z*c + cz*s + uz*dot*(1 - c)
  ];
}

function render() {
  if (!canvas.width) return;
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  const activeSubs = new Set();
  document.querySelectorAll('#subFilters input:checked').forEach(cb => activeSubs.add(cb.value));

  const explode = parseFloat(document.getElementById('explodeSlider').value || '0');
  const sDeg = parseFloat(document.getElementById('sSlider').value || '0');
  const pDeg = parseFloat(document.getElementById('pSlider').value || '-45');
  const deltaP = (-45 - pDeg);

  const ca = Math.cos(rotAzim), sa = Math.sin(rotAzim);
  const ce = Math.cos(rotElev), se = Math.sin(rotElev);
  const cx = canvas.width * 0.5 + panX;
  const cy = canvas.height * 0.52 + panY;
  const scale = Math.min(canvas.width, canvas.height) * 0.0011 * zoom;

  function project(pt) {
    const x = pt[0], y = pt[1], z = -pt[2];
    const x1 = x * ca - y * sa;
    const y1 = x * sa + y * ca;
    const z2 = y1 * se + z * ce;
    const depth = y1 * ce - z * se;
    return [cx + x1 * scale, cy - z2 * scale, depth];
  }

  const oP = project([0,0,0]);
  const axes = [
    { p: project([280,0,0]), c: '#EF4444', lbl: '+X 前' },
    { p: project([0,260,0]), c: '#22C55E', lbl: '+Y 右' },
    { p: project([0,0,180]), c: '#3B82F6', lbl: '+Z 下' }
  ];
  axes.forEach(a => {
    ctx.beginPath();
    ctx.moveTo(oP[0], oP[1]);
    ctx.lineTo(a.p[0], a.p[1]);
    ctx.strokeStyle = a.c;
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.fillStyle = a.c;
    ctx.font = 'bold 12px sans-serif';
    ctx.fillText(a.lbl, a.p[0] + 4, a.p[1]);
  });

  const allTris = [];
  const pivots = {
    FIN_F: { base: [220, 0, 16], u: [1, 0, 0], signS: -1, signP: 1 },
    FIN_B: { base: [-220, 0, 16], u: [-1, 0, 0], signS: 1, signP: -1 },
    FIN_L: { base: [0, -200, 16], u: [0, -1, 0], signS: -1, signP: 1 },
    FIN_R: { base: [0, 200, 16], u: [0, 1, 0], signS: 1, signP: -1 }
  };

  DATA.parts.forEach(part => {
    if (!activeSubs.has(part.subsystem)) return;
    if (part.is_envelope && explode === 0) return;

    let ex = 0, ey = 0, ez = 0;
    if (explode > 0) {
      const c = part.verts[0];
      ex = c[0] * 0.35 * explode;
      ey = c[1] * 0.35 * explode;
      ez = c[2] * 0.45 * explode;
    }

    const pv = pivots[part.subsystem];
    const isMovingWithS = pv && !part.instance_id.startsWith('BRK-S-') && !part.instance_id.startsWith('S-');
    const isMovingWithP = pv && (part.instance_id.startsWith('HUB-P-') || part.instance_id.startsWith('CLAMP-') || part.instance_id.startsWith('FIN-'));

    const tVerts = part.verts.map(v => {
      let pt = [v[0], v[1], v[2]];
      if (isMovingWithP && Math.abs(deltaP) > 0.1) {
        pt = rotateAroundAxis(pt, pv.base, pv.u, deltaP * pv.signP);
      }
      if (isMovingWithS && Math.abs(sDeg) > 0.1) {
        pt = rotateAroundZ(pt, pv.base, sDeg * pv.signS);
      }
      return project([pt[0] + ex, pt[1] + ey, pt[2] + ez]);
    });

    const [r, g, b] = part.color;
    part.faces.forEach(f => {
      const p0 = tVerts[f[0]], p1 = tVerts[f[1]], p2 = tVerts[f[2]];
      const zAvg = (p0[2] + p1[2] + p2[2]) / 3.0;
      allTris.push({ p0, p1, p2, zAvg, r, g, b, isEnv: part.is_envelope });
    });
  });

  allTris.sort((a, b) => a.zAvg - b.zAvg);

  allTris.forEach(t => {
    ctx.beginPath();
    ctx.moveTo(t.p0[0], t.p0[1]);
    ctx.lineTo(t.p1[0], t.p1[1]);
    ctx.lineTo(t.p2[0], t.p2[1]);
    ctx.closePath();
    const shade = 0.82 + 0.18 * Math.tanh(t.zAvg / 300);
    const rr = Math.min(255, Math.floor(t.r * 255 * shade));
    const gg = Math.min(255, Math.floor(t.g * 255 * shade));
    const bb = Math.min(255, Math.floor(t.b * 255 * shade));
    ctx.fillStyle = `rgba(${rr},${gg},${bb},${t.isEnv ? 0.35 : 0.92})`;
    ctx.fill();
    ctx.strokeStyle = 'rgba(15,23,42,0.45)';
    ctx.lineWidth = 0.55;
    ctx.stroke();
  });
}

function animate() {
  if (playing) {
    tSec = (tSec + 0.04) % 5.0;
    const g = evalGait(tSec);
    document.getElementById('phaseLbl').textContent = g.phase;
    document.getElementById('sSlider').value = g.s.toFixed(1);
    document.getElementById('pSlider').value = g.p.toFixed(1);
    document.getElementById('sVal').textContent = g.s.toFixed(1) + '°';
    document.getElementById('pVal').textContent = g.p.toFixed(1) + '°';
    render();
  }
  requestAnimationFrame(animate);
}

resizeCanvas();
requestAnimationFrame(animate);
</script>
</body>
</html>
""".replace("__PAYLOAD_JSON__", payload_json)

    root_viewer = project_root / "打开3D交互式机器人数字样机.html"
    prev_viewer = project_root / "output" / "previews" / "SRDP_Interactive_3D_Viewer.html"
    prev_viewer.parent.mkdir(parents=True, exist_ok=True)
    root_viewer.write_text(html, encoding="utf-8")
    prev_viewer.write_text(html, encoding="utf-8")
    return root_viewer
