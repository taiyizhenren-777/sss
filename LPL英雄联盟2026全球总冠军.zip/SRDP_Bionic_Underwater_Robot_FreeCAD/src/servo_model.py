#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
水下伺服与附件数字化参数模型 (Servo Model: SER-2010, SER-0011 Hub, Cobalt 3-Pin Connector)
严格遵循实施总册第 9、12、13、21 页：
- SER-2010: Acetal 密封壳体 (宽 32mm，侧面 4×Ø3.2mm 通孔，顶部 4×16mm 盲孔，6mm 钛合金 D 轴)
- SER-0011: 钛合金双螺钉抱紧输出毂
- Cobalt 3-Pin: 水下连接器及根部保护套包络
所有未知精确尺寸均读取自 servo_parameters.json 并带待确认标记，支持一键替换为官方 STEP。
"""
from typing import Dict, Any, Tuple
import numpy as np
from .component_library import (
    SolidPart, HoleFeature, make_box_mesh, make_cylinder_mesh, combine_meshes
)


def build_ser2010_servo_solid(servo_cfg: Dict[str, Any], instance_id: str,
                              subsystem: str, transform_world: np.ndarray) -> SolidPart:
    """
    构建 Blue Trail Engineering SER-2010 水下伺服三维实体。
    局部坐标系约定：
    - 原点 (0,0,0) 位于输出轴根部与伺服顶面交点；
    - 输出轴沿局部 +Z 轴伸出 (长度 14 mm, Ø6 mm D轴)；
    - 机壳主体沿局部 -Z 延伸 (Z 从 -50 到 0 mm)，X 向长度 54 mm (X 从 -15 到 +39 mm)，Y 向宽度 32 mm (Y 从 -16 到 +16 mm)；
    - Cobalt 3针连接器位于机壳后端面 (+X = 39 mm, Z = -35 mm) 沿 +X 伸出。
    """
    known = servo_cfg["known_dimensions_mm"]
    recon = servo_cfg["reconstructed_placeholder_dimensions_mm"]

    w_y = float(known["case_width_mm"])          # 32.0 mm (官方已知)
    l_x = float(recon["case_length_mm"])         # 54.0 mm (重建参数)
    h_z = float(recon["case_height_mm"])         # 50.0 mm (重建参数)
    shaft_d = float(known["output_shaft_dia_mm"])  # 6.0 mm (官方已知)
    shaft_l = float(recon["shaft_exposed_length_mm"])  # 14.0 mm
    front_off = float(recon["shaft_offset_from_front_mm"])  # 15.0 mm

    # 1. Acetal 机壳主体: X in [-front_off, l_x - front_off], Y in [-w_y/2, w_y/2], Z in [-h_z, 0]
    case_center = (l_x / 2.0 - front_off, 0.0, -h_z / 2.0)
    v_case, f_case, vol_case = make_box_mesh(l_x, w_y, h_z, center=case_center)

    # 2. 顶部轴承密封凸台: Ø18 mm, 高 3 mm
    v_boss, f_boss, vol_boss = make_cylinder_mesh(9.0, 3.0, axis="Z", center=(0.0, 0.0, 1.5), segments=20)

    # 3. 6mm 钛合金 D 型输出轴: Ø6 mm, 伸出 Z in [0, shaft_l]
    v_shaft, f_shaft, vol_shaft = make_cylinder_mesh(shaft_d / 2.0, shaft_l, axis="Z", center=(0.0, 0.0, shaft_l / 2.0), segments=18)

    # 4. Cobalt 3针穿舱插座与插头包络: 位于后端 X = l_x - front_off, Z = -h_z + 14.0
    conn_x = (l_x - front_off) + 14.0
    v_conn, f_conn, vol_conn = make_cylinder_mesh(7.5, 28.0, axis="X", center=(conn_x, 0.0, -h_z + 14.0), segments=16)

    verts, faces, total_vol = combine_meshes([
        (v_case, f_case, vol_case),
        (v_boss, f_boss, vol_boss),
        (v_shaft, f_shaft, vol_shaft),
        (v_conn, f_conn, vol_conn),
    ])

    holes = [
        HoleFeature(-7.0, -11.0, 3.2, "THROUGH", "Ø3.2 侧面安装通孔 (官方已知孔径, 孔距待复核)", w_y, True),
        HoleFeature(31.0, -11.0, 3.2, "THROUGH", "Ø3.2 侧面安装通孔 (官方已知孔径, 孔距待复核)", w_y, True),
        HoleFeature(-7.0, -39.0, 3.2, "THROUGH", "Ø3.2 侧面安装通孔 (官方已知孔径, 孔距待复核)", w_y, True),
        HoleFeature(31.0, -39.0, 3.2, "THROUGH", "Ø3.2 侧面安装通孔 (官方已知孔径, 孔距待复核)", w_y, True),
    ]

    return SolidPart(
        part_id=servo_cfg["part_number"],
        instance_id=instance_id,
        name_cn=f"{servo_cfg['name']} ({instance_id})",
        name_en=f"SER-2010 Underwater Servo ({instance_id})",
        category="PURCHASED",
        subsystem=subsystem,
        material_code="POM_ACETAL",
        credibility_level=servo_cfg["credibility_level"],
        ver_version="2.0",
        vertices_local=verts,
        faces=faces,
        analytic_volume_mm3=total_vol,
        override_mass_g=float(known["mass_in_air_g"]),
        override_displaced_volume_cm3=float(known["displaced_volume_cm3"]),
        holes_2d=holes,
        dimensions_summary={
            "case_width_mm_known": w_y,
            "shaft_dia_mm_known": shaft_d,
            "side_hole_dia_mm_known": 3.2,
            "top_blind_hole_depth_mm_known": 16.0,
            "case_length_mm_placeholder": l_x,
            "case_height_mm_placeholder": h_z,
        },
        uncertain_flags=["UNC-001: 壳体精确长高及侧面4×M3孔距待官方STEP或到货卡尺实测"],
        source_reference=servo_cfg["source_urls"][0],
        color_rgb=(0.16, 0.18, 0.22),
        transform_world=transform_world,
        freecad_recipe={
            "type": "Compound_Servo_SER2010",
            "box": [l_x, w_y, h_z, case_center],
            "shaft": [shaft_d / 2.0, shaft_l],
            "connector": [7.5, 28.0, conn_x]
        }
    )


def build_ser0011_hub_solid(hub_cfg: Dict[str, Any], instance_id: str,
                            subsystem: str, transform_world: np.ndarray) -> SolidPart:
    """构建 SER-0011 钛合金双螺钉夹紧伺服输出毂。局部原点位于毂底面中心，+Z 为轴向向外。"""
    recon = hub_cfg["reconstructed_placeholder_dimensions_mm"]
    od = float(recon["outer_dia_mm"])
    thk = float(recon["thickness_mm"])
    pcd = float(recon["flange_bolt_circle_dia_mm"])

    v_hub, f_hub, vol_hub = make_cylinder_mesh(od / 2.0, thk, axis="Z", center=(0.0, 0.0, thk / 2.0), segments=24)
    # 侧面双螺钉抱紧耳块 (16 x 10 x thk)
    v_clamp, f_clamp, vol_clamp = make_box_mesh(16.0, 10.0, thk, center=(0.0, -od / 2.0 + 2.0, thk / 2.0))
    verts, faces, total_vol = combine_meshes([(v_hub, f_hub, vol_hub), (v_clamp, f_clamp, vol_clamp)])

    r_bcd = pcd / 2.0
    holes = [
        HoleFeature(0.0, 0.0, 6.0, "THROUGH", "Ø6.0 D型轴孔 (官方已知)", thk, False),
        HoleFeature(r_bcd, 0.0, 3.0, "BLIND_THREAD", "M3 输出法兰螺孔 (PCD待实测)", thk, True),
        HoleFeature(-r_bcd, 0.0, 3.0, "BLIND_THREAD", "M3 输出法兰螺孔 (PCD待实测)", thk, True),
        HoleFeature(0.0, r_bcd, 3.0, "BLIND_THREAD", "M3 输出法兰螺孔 (PCD待实测)", thk, True),
        HoleFeature(0.0, -r_bcd, 3.0, "BLIND_THREAD", "M3 输出法兰螺孔 (PCD待实测)", thk, True),
    ]

    return SolidPart(
        part_id=hub_cfg["part_number"],
        instance_id=instance_id,
        name_cn=f"{hub_cfg['name']} ({instance_id})",
        name_en=f"SER-0011 Titanium Servo Hub ({instance_id})",
        category="PURCHASED",
        subsystem=subsystem,
        material_code="TI_GRADE_5",
        credibility_level=hub_cfg["credibility_level"],
        ver_version="2.0",
        vertices_local=verts,
        faces=faces,
        analytic_volume_mm3=total_vol * 0.82,
        override_mass_g=float(recon["mass_in_air_g"]),
        override_displaced_volume_cm3=3.4,
        holes_2d=holes,
        dimensions_summary={"bore_dia_mm_known": 6.0, "outer_dia_mm_placeholder": od, "pcd_mm_placeholder": pcd},
        uncertain_flags=["UNC-002: SER-0011 毂外径及端面螺孔PCD待原厂图纸或实物卡尺复核"],
        source_reference=hub_cfg["source_urls"][0],
        color_rgb=(0.62, 0.60, 0.56),
        transform_world=transform_world,
        freecad_recipe={"type": "Cylinder_Hub_SER0011", "od": od, "thickness": thk, "bore": 6.0}
    )
