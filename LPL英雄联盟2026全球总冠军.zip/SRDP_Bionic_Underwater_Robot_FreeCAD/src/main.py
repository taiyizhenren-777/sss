#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SRDP 仿生水下机器人：FreeCAD 全自动机械结构设计与工程交付系统 V2.0 — 主控入口 (main.py)
支持三种运行模式：
1. 普通 Python 环境 (VS Code / PyCharm / 命令行直接运行 `python src/main.py`)
2. FreeCAD 无头命令行环境 (`FreeCADCmd.exe src/main.py`)
3. FreeCAD GUI 宏环境 (`macros/Generate_Full_SRDP.FCMacro`)

执行流程：
1. 加载并校验 `config/*.json` 全部 9 个统一参数配置文件
2. 构建四套正交双自由度串联仿生鳍模块、中央 T200 垂推、双水密电子舱、开放式承力框架、浮材、配重、脚架、回收点与视觉标靶
3. 运行运动学四段平滑插值周期轨迹生成与力分配核查 (含离线协议/分配自检)
4. 运行 10 项全角度与多相位碰撞及最小间隙检查，生成碰撞检测报告
5. 运行整机与各零件质量、排水体积、静浮力、重心(CG)、浮心(CB)与被动恢复趋势核算，生成质量与浮力报告
6. 生成全部 13 张工程图 PDF、合并版总图册与 3D 渲染预览图
7. 导出全部工程文件 (.FCStd, .step, .stl, .dxf, .csv, .xlsx) 并实际重新打开验证
8. 运行 20+1 项自动化验收测试，输出完整测试报告与日志
"""
import os
import sys
import json
import time
import logging
import argparse
from pathlib import Path
from typing import Dict, Any

# 确保项目根目录与 src 目录在 sys.path 中
CURRENT_FILE = Path(__file__).resolve()
SRC_DIR = CURRENT_FILE.parent
PROJECT_ROOT = SRC_DIR.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

from src.freecad_launcher import detect_runtime_mode, find_freecad_executable
from src.parameter_manager import ParameterManager
from src.assembly_manager import AssemblyManager
from src.collision_checker import CollisionChecker
from src.mass_properties import MassPropertiesCalculator
from src.bom_generator import BOMGenerator
from src.export_manager import ExportManager, generate_interactive_3d_viewer
from src.drawing_generator import DrawingGenerator
from src.validation_manager import ValidationManager


def setup_logging(project_root: Path) -> logging.Logger:
    log_dir = project_root / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / "srdp_cad_generation.log"

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        handlers=[
            logging.FileHandler(log_file, mode="w", encoding="utf-8"),
            logging.StreamHandler(sys.stdout),
        ]
    )
    return logging.getLogger("SRDP.Main")


def write_markdown_reports(project_root: Path, pm: ParameterManager,
                           collision_report: Dict[str, Any],
                           mass_report: Dict[str, Any],
                           validation_report: Dict[str, Any]) -> Dict[str, Path]:
    rep_dir = project_root / "output" / "reports"
    rep_dir.mkdir(parents=True, exist_ok=True)

    # 1. 碰撞检测与空间净空报告
    col_md = rep_dir / "Collision_and_Clearance_Report.md"
    c_sum = collision_report["summary"]
    col_lines = [
        "# SRDP 四鳍仿生水下机器人 V2.0 — 机械运动学与空间碰撞检测报告",
        "",
        f"- **总体结论**: `{c_sum['overall_status']}` (共 {c_sum['total_checks']} 项检查：{c_sum['pass_count']} 项 PASS，{c_sum['warning_count']} 项 WARNING，{c_sum['fail_count']} 项 FAIL)",
        f"- **统一坐标系**: 原点 O 位于中央垂推轴线与主安装板基准面交点，`+X` 机体向前，`+Y` 机体向右，`+Z` 机体向下",
        f"- **运动学插值**: 四段平滑周期 (A工作划水 → B原位羽化 → C低阻回程 → D恢复工作面)，采用 $s(\\tau)=3\\tau^2-2\\tau^3$，段首段尾角速度严格为零",
        "",
        "## 10项全姿态与多相位碰撞检查明细表",
        "",
        "| 检查编号 | 检查项目 | 检查零件 A | 检查零件 B | 最不利姿态 / 工况 | 最近点世界坐标 (mm) | 最小间隙 (mm) | 合格阈值 (mm) | 状态 | 工程修改与实施建议 |",
        "| :--- | :--- | :--- | :--- | :--- | :--- | :---: | :---: | :---: | :--- |",
    ]
    for chk in collision_report["checks"]:
        pt_str = f"({chk['closest_point_mm'][0]}, {chk['closest_point_mm'][1]}, {chk['closest_point_mm'][2]})"
        col_lines.append(
            f"| {chk['check_id']} | {chk['check_name']} | `{chk['part_a']}` | `{chk['part_b']}` | {chk['worst_pose']} | `{pt_str}` | **{chk['min_clearance_mm']:.2f}** | {chk['threshold_mm']:.1f} | **{chk['status']}** | {chk['recommendation']} |"
        )
    col_md.write_text("\n".join(col_lines) + "\n", encoding="utf-8")

    # 2. 质量、排水体积、静浮力与重心/浮心报告
    mass_md = rep_dir / "Mass_and_Buoyancy_Report.md"
    m_sum = mass_report["summary"]
    mass_lines = [
        "# SRDP 四鳍仿生水下机器人 V2.0 — 质量、浮力、重心与配平分析报告",
        "",
        f"- **核算属性声明**: `{m_sum['calculation_status']}`",
        f"- **八台 SER-2010 伺服空气总重**: `{m_sum['eight_servos_air_mass_g']:.1f} g` (水中表观总重 `{m_sum['eight_servos_water_apparent_mass_g']:.1f} g`，因此绝不可采用旧版 2.5 kg 整机假设)",
        f"- **整机理论空气总质量**: `{m_sum['total_mass_air_g']:.2f} g` (`{m_sum['total_mass_air_kg']:.3f} kg`)",
        f"- **整机总排水体积**: `{m_sum['total_displaced_volume_cm3']:.2f} cm³` (仅计入密封水密舱外包络、实心浸没零件与执行器官方排开水体积，不含任何打印件内部空腔)",
        f"- **整机总重力**: `{m_sum['total_weight_N']:.3f} N` | **整机总浮力**: `{m_sum['total_buoyancy_N']:.3f} N`",
        f"- **水中净向上浮力**: **`+{m_sum['net_buoyancy_N']:.3f} N` (`+{m_sum['net_buoyancy_g']:.2f} g`)** → `{m_sum['buoyancy_state']}`",
        f"- **整机重心坐标 (CG)**: `({m_sum['center_of_gravity_mm'][0]:.2f}, {m_sum['center_of_gravity_mm'][1]:.2f}, {m_sum['center_of_gravity_mm'][2]:.2f}) mm`",
        f"- **整机浮心坐标 (CB)**: `({m_sum['center_of_buoyancy_mm'][0]:.2f}, {m_sum['center_of_buoyancy_mm'][1]:.2f}, {m_sum['center_of_buoyancy_mm'][2]:.2f}) mm`",
        f"- **浮心—重心垂向稳心高 ($BG_z = Z_{{CG}} - Z_{{CB}}$)**: **`+{m_sum['BG_vertical_separation_mm']:.2f} mm`** (在 +Z 向下坐标系中浮心位于重心正上方)",
        f"- **横滚恢复趋势**: {m_sum['roll_restoring_trend']}",
        f"- **俯仰恢复趋势**: {m_sum['pitch_restoring_trend']}",
        "",
        "## 各子系统质量与浮力分布汇总表",
        "",
        "| 子系统代号 | 包含零件件数 | 空气质量 (g) | 排水体积 (cm³) | 净浮力贡献 (N) |",
        "| :--- | :---: | :---: | :---: | :---: |",
    ]
    for sk, sinfo in sorted(mass_report["subsystem_breakdown"].items()):
        mass_lines.append(
            f"| `{sk}` | {sinfo['part_count']} | {sinfo['mass_g']:.2f} | {sinfo['displaced_volume_cm3']:.2f} | {sinfo['net_buoyancy_N']:+.3f} |"
        )
    mass_md.write_text("\n".join(mass_lines) + "\n", encoding="utf-8")

    # 3. 自动化验收测试报告
    val_md = rep_dir / "Validation_and_Acceptance_Test_Report.md"
    v_sum = validation_report["summary"]
    val_lines = [
        "# SRDP 四鳍仿生水下机器人 V2.0 — 自动化验收测试报告 (20+1 项全检)",
        "",
        f"- **测试总项数**: `{v_sum['total_tests']}` 项",
        f"- **状态统计**: `PASS = {v_sum['pass_count']}` | `WARNING = {v_sum['warning_count']}` | `BLOCKED = {v_sum['blocked_count']}` | `FAIL = {v_sum['fail_count']}`",
        f"- **总体放行判定**: `{v_sum['overall_verdict']}`",
        "",
        "## 逐项测试验证结果表",
        "",
        "| 测试编号 | 测试项目 | 状态 | 实测验证数据与证据 | 工程说明与风险边界 |",
        "| :--- | :--- | :---: | :--- | :--- |",
    ]
    for t in validation_report["tests"]:
        val_lines.append(
            f"| `{t['test_id']}` | {t['name']} | **{t['status']}** | {t['evidence']} | {t['details']} |"
        )
    val_md.write_text("\n".join(val_lines) + "\n", encoding="utf-8")

    # 同时保存 JSON 格式报告供自动化脚本与 CI 读取
    (rep_dir / "collision_report.json").write_text(json.dumps(collision_report, ensure_ascii=False, indent=2), encoding="utf-8")
    (rep_dir / "mass_buoyancy_report.json").write_text(json.dumps(mass_report, ensure_ascii=False, indent=2), encoding="utf-8")
    (rep_dir / "validation_report.json").write_text(json.dumps(validation_report, ensure_ascii=False, indent=2), encoding="utf-8")

    return {
        "collision_md": col_md,
        "mass_md": mass_md,
        "validation_md": val_md,
    }


def run_pipeline(mode: str = "full") -> Dict[str, Any]:
    t0 = time.time()
    logger = setup_logging(PROJECT_ROOT)
    rt_info = detect_runtime_mode()
    logger.info("运行环境检测结果: mode=%s | Python=%s | 可用工作台=%s",
                rt_info["mode"], rt_info["python_version"], rt_info["available_workbenches"])

    # Step 1: 加载并校验参数数据库
    pm = ParameterManager(PROJECT_ROOT)
    ok_param, param_msgs = pm.validate_completeness_and_units()
    for m in param_msgs:
        logger.info("参数校验: %s", m)

    # Step 2: 构建单鳍模块、三种鳍片与整机三维总装
    asm = AssemblyManager(pm)
    single_fin_parts = asm.build_single_fin_module_parts(mod_code="F", cmd_s_deg=0.0, cmd_p_deg=-45.0, fin_variant="F-S", at_origin=True)
    fin_variants = asm.build_standalone_fin_variants()
    full_parts = asm.build_full_robot_assembly(fin_variant="F-S")
    logger.info("已构建完整机器人数字样机: 整机组件数=%d, 单鳍组件数=%d, 替换鳍片规格=%s",
                len(full_parts), len(single_fin_parts), list(fin_variants.keys()))

    # Step 3: 碰撞检测与运动空间核查
    checker = CollisionChecker(asm)
    collision_report = checker.run_all_checks()
    logger.info("碰撞检测完成: %s", collision_report["summary"])

    # Step 4: 质量、排水体积、静浮力与重心/浮心核算
    mass_calc = MassPropertiesCalculator(pm)
    mass_report = mass_calc.analyze_full_assembly(full_parts)
    logger.info("质量与浮力核算完成: 总质量=%.2fg, 总排水=%.2fcm3, 净浮力=%+.3fN, BG_z=%+.2fmm",
                mass_report["summary"]["total_mass_air_g"],
                mass_report["summary"]["total_displaced_volume_cm3"],
                mass_report["summary"]["net_buoyancy_N"],
                mass_report["summary"]["BG_vertical_separation_mm"])

    # Step 5: 生成 BOM 与待确认参数表 (CSV + XLSX)
    bom_gen = BOMGenerator(pm, mass_report)
    bom_files = bom_gen.generate_all()
    logger.info("已导出 BOM 与待确认参数表: %s", [str(p.name) for p in bom_files.values()])

    # Step 6: 导出全部三维与二维 CAD 工程文件 (FCStd, STEP, STL, DXF)
    exp_mgr = ExportManager(asm)
    exported_files = exp_mgr.export_all_cad_files(full_parts, single_fin_parts, fin_variants)
    logger.info("已导出 CAD 文件: FCStd=%d, STEP=%d, STL=%d, DXF=%d",
                len(exported_files["fcstd_files"]),
                len(exported_files["step_files"]),
                len(exported_files["stl_files"]),
                len(exported_files["dxf_files"]))

    # Step 7: 自动生成 13 张工程图 PDF 与 3D 预览 PNG
    drw_gen = DrawingGenerator(asm, mass_report, collision_report)
    drawing_files = drw_gen.generate_all_13_drawings(full_parts, single_fin_parts, fin_variants)
    logger.info("已生成全部 %d 张工程图 PDF 与总图册 %s",
                len(drawing_files["drawing_pdfs"]),
                drawing_files["combined_book_pdf"].name)

    # Step 8: 运行 20+1 项自动化验收测试与重新打开校验
    val_mgr = ValidationManager(
        pm, asm, full_parts, single_fin_parts, fin_variants,
        collision_report, mass_report, exported_files, drawing_files, bom_files
    )
    validation_report = val_mgr.run_all_20_acceptance_tests()
    logger.info("自动化验收测试完成: PASS=%d, WARNING=%d, BLOCKED=%d, FAIL=%d",
                validation_report["summary"]["pass_count"],
                validation_report["summary"]["warning_count"],
                validation_report["summary"]["blocked_count"],
                validation_report["summary"]["fail_count"])

    # Step 8.5: 生成离线零依赖 3D 交互式机器人数字样机 HTML
    viewer_html = generate_interactive_3d_viewer(PROJECT_ROOT, full_parts, mass_report, collision_report)
    logger.info("已生成离线交互式 3D 数字样机查看器: %s", viewer_html.name)

    # Step 9: 输出 Markdown 与 JSON 工程报告
    report_files = write_markdown_reports(PROJECT_ROOT, pm, collision_report, mass_report, validation_report)
    elapsed = time.time() - t0
    logger.info("SRDP V2.0 全自动机械结构设计与工程交付流水线执行完毕，总耗时 %.2f 秒。", elapsed)

    return {
        "runtime": rt_info,
        "collision_report": collision_report,
        "mass_report": mass_report,
        "validation_report": validation_report,
        "exported_files": exported_files,
        "drawing_files": drawing_files,
        "bom_files": bom_files,
        "report_files": report_files,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="SRDP 仿生水下机器人 FreeCAD 全自动机械结构设计与工程交付系统 V2.0")
    parser.add_argument("--mode", default="full", choices=["full", "check", "export"], help="运行模式: full(完整生成), check(模型检查), export(文件导出)")
    args, _ = parser.parse_known_args()
    res = run_pipeline(mode=args.mode)
    if res["validation_report"]["summary"]["fail_count"] > 0:
        sys.exit(1)
