#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
四鳍双自由度串联机构正运动学、四段平滑周期轨迹生成与力分配计算引擎 (Kinematics & Gait Engine)
严格遵循任务要求第四部分 (4.1, 4.2) 与实施总册第 7, 9, 14, 40, 41, 43 页：
1. 统一机体坐标系：+X 向前，+Y 向右，+Z 向下 (右手系，俯视顺时针为 +ψ)。
2. 串联双自由度齐次变换链 (绝不是仅移动显示位置的假动画)：
   T_world_S_base(mod) -> R_z(sign_S * theta_S) -> T_S_to_P -> R_u(sign_P * (theta_P - P_zero_offset)) -> T_P_to_Fin
3. 四模块安装方位与符号差异：
   - L (左鳍, Y=-b): 模块向外径向 u 沿 -Y (azimuth = -90°), 主平均力沿 +X
   - R (右鳍, Y=+b): 模块向外径向 u 沿 +Y (azimuth = +90°),  主平均力沿 +X (与 L 镜像，划桨符号相反)
   - F (前鳍, X=+a): 模块向外径向 u 沿 +X (azimuth = 0°),    主平均力沿 +Y
   - B (后鳍, X=-a): 模块向外径向 u 沿 -X (azimuth = 180°),  主平均力沿 +Y (与 F 镜像，划桨符号相反)
4. 四段平滑插值周期 (A 工作划水 -> B 原位羽化 -> C 低阻回程 -> D 恢复工作姿态)：
   采用三次多项式平滑插值 s(tau) = 3*tau^2 - 2*tau^3 (段首段尾角速度严格为 0，禁止突然跳角)。
"""
import math
from typing import Dict, Any, Tuple, List
import numpy as np
from .component_library import rot_x, rot_y, rot_z, trans


def smooth_step_cubic(tau: float) -> float:
    """实施总册 P14 规定的三次多项式零端点速度平滑插值函数: s(tau) = 3*tau^2 - 2*tau^3, tau in [0,1]"""
    t = max(0.0, min(1.0, float(tau)))
    return 3.0 * (t ** 2) - 2.0 * (t ** 3)


def smooth_step_cubic_derivative(tau: float, duration: float) -> float:
    """平滑插值对时间的导数 ds/dt = (6*tau - 6*tau^2) / duration"""
    if duration <= 1e-9:
        return 0.0
    t = max(0.0, min(1.0, float(tau)))
    return (6.0 * t - 6.0 * (t ** 2)) / float(duration)


class BionicFinKinematics:
    """四鳍双自由度串联机构运动学与四段周期步态模型"""

    MODULE_AZIMUTH_DEG = {
        "F": 0.0,     # 向外径向 u = +X [1, 0, 0]
        "R": 90.0,    # 向外径向 u = +Y [0, 1, 0]
        "B": 180.0,   # 向外径向 u = -X [-1, 0, 0]
        "L": -90.0,   # 向外径向 u = -Y [0, -1, 0]
    }

    # 为产生正向机体推进力 (L,R 沿 +X 向前; F,B 沿 +Y 向右)，有效工作行程 (Phase A) 中鳍叶应向相反方向推动水流：
    # - L (位于 -Y，向外为 -Y)：向后 (-X) 划水对应绕 +Z 逆时针旋转 (-1) 或顺时针 (+1)：
    #   在右手系 (X前, Y右, Z下) 中，向量 u_L = [0, -1, 0]。绕 +Z 旋转 d_theta 时：
    #   R_z(d_theta) * [0, -1, 0]^T = [sin(d_theta), -cos(d_theta), 0]^T。
    #   因此 d_theta 从 +A 到 -A (减小) 时，鳍尖向 -X (向后) 扫水，推动水向后，机体获得 +X (向前) 推力！
    # - R (位于 +Y，向外为 +Y)：u_R = [0, +1, 0]。R_z(d_theta) * [0, 1, 0]^T = [-sin(d_theta), cos(d_theta), 0]^T。
    #   因此 d_theta 从 -A 到 +A (增大) 时，鳍尖向 -X (向后) 扫水，推动水向后，机体获得 +X (向前) 推力！
    #   可见 L 与 R 的 S 轴旋转方向符号严格相反 (-1 vs +1)！
    # - F (位于 +X，向外为 +X)：u_F = [1, 0, 0]。R_z(d_theta) * [1, 0, 0]^T = [cos(d_theta), sin(d_theta), 0]^T。
    #   为获得 +Y (向右) 推力，鳍尖需向 -Y (向左) 划水，即 d_theta 从 +A 到 -A (符号 -1)。
    # - B (位于 -X，向外为 -X)：u_B = [-1, 0, 0]。R_z(d_theta) * [-1, 0, 0]^T = [-cos(d_theta), -sin(d_theta), 0]^T。
    #   为获得 +Y (向右) 推力，鳍尖需向 -Y (向左) 划水，即 d_theta 从 -A 到 +A (符号 +1)。
    MODULE_STROKE_SIGN = {
        "L": -1.0,
        "R": +1.0,
        "F": -1.0,
        "B": +1.0,
    }

    # P 轴羽化方向符号 (保证各模块在 -45° 指令下均为竖直推水迎水面，+45° 指令下均为水平低阻回程面)
    MODULE_FEATHER_SIGN = {
        "L": +1.0,
        "R": -1.0,
        "F": +1.0,
        "B": -1.0,
    }

    def __init__(self, pm):
        self.pm = pm
        self.motion_cfg = pm.get("motion_parameters")
        self.fin_cfg = pm.get("fin_parameters")
        self.servo_cfg = pm.get("servo_parameters")["servo_ser2010"]
        self.hub_cfg = pm.get("servo_parameters")["servo_hub_ser0011"]
        self.lever_a = float(pm.derived["lever_arm_a_mm"])
        self.lever_b = float(pm.derived["lever_arm_b_mm"])
        self.s_to_p_radial = float(self.fin_cfg["fin_module_mechanics"]["s_to_p_radial_offset_mm"])  # 38.0 mm
        self.p_case_len = float(self.servo_cfg["reconstructed_placeholder_dimensions_mm"]["case_length_mm"])  # 54.0 mm
        self.hub_thk = float(self.hub_cfg["reconstructed_placeholder_dimensions_mm"]["thickness_mm"])  # 8.0 mm

    def get_module_base_transform(self, mod_code: str) -> np.ndarray:
        """
        返回模块基座在整机世界坐标系 (O: X前 Y右 Z下) 中的固定变换矩阵 T_world_modbase。
        变换后，模块的局部 +X 轴严格指向该模块向外的径向 u，局部 +Z 轴严格指向竖直向下 (+Z)。
        """
        if mod_code == "F":
            pos = (self.lever_a, 0.0, 0.0)
        elif mod_code == "B":
            pos = (-self.lever_a, 0.0, 0.0)
        elif mod_code == "L":
            pos = (0.0, -self.lever_b, 0.0)
        elif mod_code == "R":
            pos = (0.0, self.lever_b, 0.0)
        else:
            raise ValueError(f"未知的鳍模块代号: {mod_code}")

        az = self.MODULE_AZIMUTH_DEG[mod_code]
        return trans(*pos) @ rot_z(az)

    def compute_chain_transforms(self, mod_code: str,
                                 cmd_s_deg: float = 0.0,
                                 cmd_p_deg: float = -45.0) -> Dict[str, np.ndarray]:
        """
        根据 S 轴划桨指令角 cmd_s_deg 与 P 轴羽化指令角 cmd_p_deg，计算单模块串联机构所有层级的世界坐标齐次变换矩阵：
        - T_base: 模块固定基座与 S 轴伺服固定座
        - T_s_servo: S 轴伺服机壳 (固定在基座上，输出轴位于局部 (0,0,0) 沿竖直 Z 轴)
        - T_s_hub: S 轴输出毂 (随 S 轴旋转)
        - T_yoke: 短转架 (随 S 轴旋转)
        - T_p_servo: P 轴伺服机壳 (固定在短转架上，随 S 轴摆动；其自身输出轴沿转架径向 +X_yoke 伸出)
        - T_p_hub: P 轴输出毂 (随 S 轴摆动 + 绕径向 P 轴自转)
        - T_fin_clamp: 鳍片根部双夹板 (随 P 轴输出毂同步运动)
        - T_fin_blade: 可替换 PETG 鳍片 (随 P 轴输出毂同步运动；当 cmd_p_deg = -45° 时鳍面竖直，cmd_p_deg = +45° 时鳍面水平)
        """
        # 角度安全限幅检查 (硬件默认 ±70°)
        s_lim = self.motion_cfg["joint_definitions"]["S_stroke_axis"]["hardware_limit_deg"]
        p_lim = self.motion_cfg["joint_definitions"]["P_feather_axis"]["hardware_limit_deg"]
        s_clamped = max(float(s_lim[0]), min(float(s_lim[1]), float(cmd_s_deg)))
        p_clamped = max(float(p_lim[0]), min(float(p_lim[1]), float(cmd_p_deg)))

        # 考虑模块安装方向的符号映射
        physical_s_deg = self.MODULE_STROKE_SIGN[mod_code] * s_clamped
        # P 轴机械零偏：依据实施总册 P9，指令 -45° 时鳍面竖直 (局部横滚 90°)，指令 +45° 时鳍面水平 (局部横滚 0°)
        # 因此鳍面局部横滚角 phi_blade = (45.0 - p_clamped) * sign_P
        blade_roll_deg = (45.0 - p_clamped) * self.MODULE_FEATHER_SIGN[mod_code]

        T_base = self.get_module_base_transform(mod_code)

        # 1. S 轴伺服机壳固定在 T_base 下 (机壳 Z in [-58, -8] mm，输出轴伸出至 Z = +6 mm)
        T_s_servo = T_base @ trans(0.0, 0.0, -8.0) @ rot_z(180.0)

        # 2. S 轴旋转关节变换 R_z(physical_s_deg)，转架位于 Z = +14 mm (距中层框板 Z=0 净空 > 8 mm)
        T_s_rot = T_base @ rot_z(physical_s_deg)
        T_s_hub = T_s_rot @ trans(0.0, 0.0, 4.0)
        T_yoke = T_s_rot @ trans(0.0, 0.0, 16.0)

        # 3. P 轴伺服固定在短转架上 (随 S 轴一起转动！)
        # 旋转 Ry(90°) 后，P 轴伺服机壳位于 X in [34, 84] mm (与 S 轴伺服 X in [-37, +17] mm 保持 17mm 安全间距！)
        p_output_shoulder_x = 84.0
        T_p_servo = T_yoke @ trans(p_output_shoulder_x, 0.0, 12.0) @ rot_y(90.0)

        # 4. P 轴旋转关节变换：绕径向轴 (+X_yoke) 旋转 blade_roll_deg (位于 X = 96 mm，距转架外端 X=58mm 留出 38mm 净空！)
        T_p_origin = T_yoke @ trans(p_output_shoulder_x + 12.0, 0.0, 12.0)
        T_p_rot = T_p_origin @ rot_x(blade_roll_deg)

        # P 轴输出毂局部 +Z 经 Ry(90°) 朝向径向 +X
        T_p_hub = T_p_rot @ rot_y(90.0) @ trans(0.0, 0.0, -8.0)
        T_fin_clamp = T_p_rot
        T_fin_blade = T_p_rot

        return {
            "T_base": T_base,
            "T_s_servo": T_s_servo,
            "T_s_hub": T_s_hub,
            "T_yoke": T_yoke,
            "T_p_servo": T_p_servo,
            "T_p_hub": T_p_hub,
            "T_fin_clamp": T_fin_clamp,
            "T_fin_blade": T_fin_blade,
            "physical_s_deg": physical_s_deg,
            "blade_roll_deg": blade_roll_deg,
        }

    def evaluate_four_phase_gait(self, t_sec: float,
                                 amplitude_s_deg: float = 15.0,
                                 period_s: float = 5.0,
                                 feather_time_s: float = 0.85,
                                 reverse: bool = False) -> Dict[str, Any]:
        """
        计算四段平滑插值周期在时刻 t_sec 的指令角度、角速度与阶段标识 (实施总册 P14)：
        - Phase A (工作划水): S 从 -A (或反向 +A) 平滑走到 +A (或 -A)，P 保持 -45° (竖直迎水)
        - Phase B (原位羽化): S 保持端点，P 从 -45° 平滑转到 +45° (水平低阻)
        - Phase C (低阻回程): S 平滑回到起始端，P 保持 +45° (水平低阻)
        - Phase D (恢复工作姿态): S 保持起始端，P 从 +45° 平滑转回 -45° (竖直迎水)
        """
        T = float(period_s)
        t_f = float(feather_time_s)
        t_s = (T - 2.0 * t_f) / 2.0
        if t_s <= 0.1:
            raise ValueError("周期时间必须大于两倍羽化过渡时间 (2 * feather_time_s)")

        t_mod = float(t_sec) % T
        A = float(amplitude_s_deg)
        s_start = A if reverse else -A
        s_end = -A if reverse else A
        p_work = -45.0
        p_rec = 45.0

        if t_mod < t_s:
            # Phase A: 工作行程
            phase = "A_Power_Stroke"
            tau = t_mod / t_s
            s_val = smooth_step_cubic(tau)
            ds_dt = smooth_step_cubic_derivative(tau, t_s)
            cmd_s = s_start + (s_end - s_start) * s_val
            vel_s = (s_end - s_start) * ds_dt
            cmd_p = p_work
            vel_p = 0.0
        elif t_mod < t_s + t_f:
            # Phase B: 原位羽化
            phase = "B_Feathering"
            tau = (t_mod - t_s) / t_f
            s_val = smooth_step_cubic(tau)
            ds_dt = smooth_step_cubic_derivative(tau, t_f)
            cmd_s = s_end
            vel_s = 0.0
            cmd_p = p_work + (p_rec - p_work) * s_val
            vel_p = (p_rec - p_work) * ds_dt
        elif t_mod < 2.0 * t_s + t_f:
            # Phase C: 低阻回程
            phase = "C_Recovery_Stroke"
            tau = (t_mod - (t_s + t_f)) / t_s
            s_val = smooth_step_cubic(tau)
            ds_dt = smooth_step_cubic_derivative(tau, t_s)
            cmd_s = s_end + (s_start - s_end) * s_val
            vel_s = (s_start - s_end) * ds_dt
            cmd_p = p_rec
            vel_p = 0.0
        else:
            # Phase D: 恢复工作面
            phase = "D_Unfeathering"
            tau = (t_mod - (2.0 * t_s + t_f)) / t_f
            s_val = smooth_step_cubic(tau)
            ds_dt = smooth_step_cubic_derivative(tau, t_f)
            cmd_s = s_start
            vel_s = 0.0
            cmd_p = p_rec + (p_work - p_rec) * s_val
            vel_p = (p_work - p_rec) * ds_dt

        return {
            "t_sec": round(t_sec, 4),
            "t_mod_sec": round(t_mod, 4),
            "phase": phase,
            "cmd_s_deg": round(cmd_s, 4),
            "cmd_p_deg": round(cmd_p, 4),
            "vel_s_deg_s": round(vel_s, 4),
            "vel_p_deg_s": round(vel_p, 4),
        }

    def allocate_horizontal_forces(self, fx_N: float, fy_N: float, mz_Nm: float,
                                   limit_N: float = 1.0) -> Dict[str, Any]:
        """
        实施总册 P41 / P59 给出的四鳍水平平均力等力矩分配与共同缩放算法：
        B = [[1, 1, 0, 0],
             [0, 0, 1, 1],
             [b, -b, a, -a]]
        f_L = Fx/2 + Mz/(4b), f_R = Fx/2 - Mz/(4b)
        f_F = Fy/2 + Mz/(4a), f_B = Fy/2 - Mz/(4a)
        """
        a_m = self.lever_a / 1000.0
        b_m = self.lever_b / 1000.0
        f_raw = [
            fx_N / 2.0 + mz_Nm / (4.0 * b_m),
            fx_N / 2.0 - mz_Nm / (4.0 * b_m),
            fy_N / 2.0 + mz_Nm / (4.0 * a_m),
            fy_N / 2.0 - mz_Nm / (4.0 * a_m),
        ]
        max_abs = max(max(abs(x) for x in f_raw), limit_N)
        scale = min(1.0, limit_N / max_abs)
        f_scaled = [v * scale for v in f_raw]
        return {
            "fL_N": f_scaled[0],
            "fR_N": f_scaled[1],
            "fF_N": f_scaled[2],
            "fB_N": f_scaled[3],
            "common_scale": scale,
            "saturated": scale < 0.999999,
        }
