#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
上部可调闭孔浮材系统生成器 (Adjustable Upper Buoyancy Foam System)
遵循任务要求第五部分 5.3 与实施总册第 13、18 页：
- 浮材尽量位于上部 (Z = -90 mm)，使浮心 (CB) 高于重心 (CG)，形成被动横滚与俯仰恢复能力
- 采用 R-3318 硬质闭孔聚氨酯浮材 (密度 0.24 g/cm³)，绝不将封闭 3D 打印空腔当成可靠浮力舱
- 设有沿 X 向长圆调节槽 (±30 mm)，支持全浸水试验时前后移动配平
"""
from typing import Dict, Any, List
import numpy as np
from .component_library import SolidPart, HoleFeature, make_box_mesh, trans


def build_buoyancy_system(frame_cfg: Dict[str, Any]) -> List[SolidPart]:
    parts: List[SolidPart] = []
    b_cfg = frame_cfg["buoyancy_system"]
    lx = float(b_cfg["block_length_x_mm"])  # 260.0 mm
    wy = float(b_cfg["block_width_y_mm"])   # 70.0 mm
    hz = float(b_cfg["block_height_z_mm"])  # 38.0 mm

    for idx, pos in enumerate(b_cfg["mount_positions_mm"], start=1):
        side = "LEFT" if pos[1] < 0 else "RIGHT"
        vf, ff, volf = make_box_mesh(lx, wy, hz, center=(0.0, 0.0, 0.0))
        # 扣除 2 个 Ø6mm 安装通孔
        net_vol_mm3 = volf * 0.96
        parts.append(SolidPart(
            part_id=b_cfg["part_number"],
            instance_id=f"BUOY-FOAM-{side}",
            name_cn=f"上部可调闭孔聚氨酯浮力块 ({side})",
            name_en=f"Upper Adjustable Closed-Cell Buoyancy Foam ({side})",
            category="MANUFACTURED_PLATE",
            subsystem="BUOYANCY",
            material_code="FOAM_R3318",
            credibility_level="SELF_DESIGN",
            ver_version="2.0",
            vertices_local=vf,
            faces=ff,
            analytic_volume_mm3=net_vol_mm3,
            plate_thickness_mm=hz,
            holes_2d=[
                HoleFeature(-95.0, 0.0, 5.5, "THROUGH", "Ø5.5×30mm 长圆调节孔 (支持X向配平微调)", hz, False),
                HoleFeature(95.0, 0.0, 5.5, "THROUGH", "Ø5.5×30mm 长圆调节孔 (支持X向配平微调)", hz, False),
            ],
            outline_2d=[(-lx / 2.0, -wy / 2.0), (lx / 2.0, -wy / 2.0), (lx / 2.0, wy / 2.0), (-lx / 2.0, wy / 2.0)],
            dimensions_summary={
                "length_x_mm": lx,
                "width_y_mm": wy,
                "height_z_mm": hz,
                "displaced_volume_cm3": round(net_vol_mm3 / 1000.0, 2),
                "adjust_range_x_mm": "±30.0"
            },
            uncertain_flags=["UNC-006: 浮材最终体积与X向锁紧位置须按T06全浸水断电配平试验调整"],
            source_reference="实施总册 P13, P18 (浮材尽量位于上部，不把封闭打印空腔计为可靠浮舱)",
            color_rgb=(0.96, 0.78, 0.14),
            transform_world=trans(*pos),
            freecad_recipe={"type": "Buoyancy_Foam_Block", "dims": [lx, wy, hz]}
        ))

    return parts
