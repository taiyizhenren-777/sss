#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
中央 T200 垂向推进器安装座与进出水防护网罩生成器 (T200 Mount & Flow Guard Generator)
遵循任务要求第五部分 5.2 与实施总册第 8、18、21、32 页：
- 中央 T200 轴线精确对准机体中心 O(0,0,0)，推力方向沿 +Z (竖直)
- 采用官方已知 4×M3 (19.0 mm 间距) + 1×M6 中心孔设计 L 型高刚度安装支座 (MFG-T200-BRACKET)
- 上下进出水口配置开式环形防缠绕护网圈 (MFG-T200-GUARD-RING)，防止系缆或手指卷入螺旋桨
"""
from typing import Dict, Any, List
import numpy as np
from .component_library import (
    SolidPart, HoleFeature, make_box_mesh, make_tube_mesh, combine_meshes, trans
)
from .purchased_components import build_t200_thruster_solid


def build_thruster_system(thr_cfg: Dict[str, Any]) -> List[SolidPart]:
    parts: List[SolidPart] = []
    t200_info = thr_cfg["t200_thruster"]

    # 1. T200 推进器本体 (位于原点 O(0,0,0))
    parts.append(build_t200_thruster_solid(t200_info, transform_world=np.eye(4, dtype=float)))

    # 2. T200 中央安装支架 (MFG-T200-BRACKET)
    # 连接 T200 侧面安装凸台 (X = +53mm) 至主承力中层框板内环壁 (X in [46, 78] mm)
    v_flange, f_flange, vol_fl = make_box_mesh(32.0, 44.0, 6.0, center=(62.0, 0.0, 3.0))
    v_web, f_web, vol_wb = make_box_mesh(6.0, 36.0, 40.0, center=(53.0, 0.0, 0.0))
    vb, fb, volb = combine_meshes([(v_flange, f_flange, vol_fl), (v_web, f_web, vol_wb)])

    hs = 19.0 / 2.0  # 官方已知 19mm M3 孔距
    holes = [
        HoleFeature(-hs, -hs, 3.2, "THROUGH", "4×Ø3.2 T200官方安装孔 (间距19.0mm, 配M3×10螺钉, 拧紧力矩0.5-1.3N·m)", 6.0, False),
        HoleFeature(hs, -hs, 3.2, "THROUGH", "4×Ø3.2 T200官方安装孔 (间距19.0mm)", 6.0, False),
        HoleFeature(-hs, hs, 3.2, "THROUGH", "4×Ø3.2 T200官方安装孔 (间距19.0mm)", 6.0, False),
        HoleFeature(hs, hs, 3.2, "THROUGH", "4×Ø3.2 T200官方安装孔 (间距19.0mm)", 6.0, False),
        HoleFeature(0.0, 0.0, 6.4, "THROUGH", "Ø6.4 T200中心M6螺栓孔 (官方已知)", 6.0, False),
        HoleFeature(-14.0, 16.0, 4.2, "THROUGH", "2×Ø4.2 主框架连接孔 (M4)", 6.0, False),
        HoleFeature(14.0, 16.0, 4.2, "THROUGH", "2×Ø4.2 主框架连接孔 (M4)", 6.0, False),
    ]
    parts.append(SolidPart(
        part_id="MFG-T200-BRACKET",
        instance_id="T200-MOUNT-BRK-01",
        name_cn="中央T200垂向推进器安装座",
        name_en="Central T200 Vertical Thruster Mounting Bracket",
        category="MANUFACTURED_PLATE",
        subsystem="THRUSTER",
        material_code="AL_6061_T6",
        credibility_level="B",
        ver_version="2.0",
        vertices_local=vb,
        faces=fb,
        analytic_volume_mm3=volb,
        plate_thickness_mm=6.0,
        holes_2d=holes,
        outline_2d=[(-22.0, -20.0), (22.0, -20.0), (22.0, 20.0), (-22.0, 20.0)],
        dimensions_summary={"m3_hole_spacing_mm_known": 19.0, "center_hole_mm_known": 6.4, "thickness_mm": 6.0},
        uncertain_flags=[],
        source_reference="Blue Robotics T200 官方技术规格 (4×M3 孔距 19mm + 1×M6) & 实施总册 P18/P21",
        color_rgb=(0.20, 0.65, 0.55),
        transform_world=np.eye(4, dtype=float),
        freecad_recipe={"type": "T200_Mount_Bracket", "hole_spacing": 19.0}
    ))

    # 3. 垂推进出水口防缠绕护罩环 (MFG-T200-GUARD, 上下各1个，位于 Z = ±44 mm)
    for g_idx, z_pos in enumerate([-44.0, 44.0], start=1):
        vg, fg, volg = make_tube_mesh(54.0, 48.0, 8.0, axis="Z", center=(0.0, 0.0, z_pos), segments=28)
        parts.append(SolidPart(
            part_id="MFG-T200-GUARD",
            instance_id=f"T200-GUARD-{g_idx:02d}",
            name_cn=f"T200垂推进出水防缆缠绕保护环 #{g_idx}",
            name_en=f"T200 Nozzle Anti-Entanglement Guard Ring #{g_idx}",
            category="MANUFACTURED_PRINT",
            subsystem="THRUSTER",
            material_code="PETG_3D_PRINTED",
            credibility_level="SELF_DESIGN",
            ver_version="2.0",
            vertices_local=vg,
            faces=fg,
            analytic_volume_mm3=volg,
            plate_thickness_mm=8.0,
            dimensions_summary={"outer_dia_mm": 108.0, "inner_clear_dia_mm": 96.0, "height_mm": 8.0},
            source_reference="实施总册 P18, P27, P32 (进出口防护与系缆隔离，装后重新标定低输出曲线)",
            color_rgb=(0.95, 0.60, 0.15),
            transform_world=np.eye(4, dtype=float),
            freecad_recipe={"type": "T200_Guard_Ring", "od": 108.0, "id": 96.0}
        ))

    return parts
