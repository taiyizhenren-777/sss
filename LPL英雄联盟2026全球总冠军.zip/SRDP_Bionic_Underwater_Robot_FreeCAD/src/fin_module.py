#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
双自由度串联仿生鳍模块生成器 (2-DOF Serial Bionic Fin Module Generator)
严格遵循实施总册第 9–13 页要求：
- 严禁两台伺服同时固定在框架上！必须采用串联拓扑：
  1. S 轴伺服 (划桨轴，竖直 Z 轴) 机壳固定在主框架基座上；
  2. S 轴输出端通过 SER-0011 输出毂带动短而宽的刚性转架 (Short Yoke)；
  3. P 轴伺服 (羽化轴，模块向外径向 u 轴) 机壳通过侧面通孔穿透螺栓固定在短转架上 (严禁在伺服密封壳体钻孔)；
  4. P 轴输出端通过 SER-0011 输出毂带动圆角鳍片夹板 (Fin Clamp Plates)；
  5. 两片圆角夹板通过 2×M3 穿透螺栓均匀夹持透明 PETG 鳍片根部 20×40 mm 区域；
  6. 同时生成 F-S (80×40×0.5)、F-M (110×40×0.5)、F-L (140×40×0.5) 三种可替换鳍片独立零件模型；
  7. 包含 P 轴移动线缆的受控弯曲活动环包络 (Cable Dynamic Loop Envelope)。
"""
import math
from typing import Dict, Any, List, Tuple
import numpy as np
from .component_library import (
    SolidPart, HoleFeature, make_box_mesh, make_cylinder_mesh, combine_meshes,
    rot_x, rot_y, rot_z, trans
)
from .servo_model import build_ser2010_servo_solid, build_ser0011_hub_solid


def build_s_servo_mount_bracket(mod_code: str, servo_cfg: Dict[str, Any],
                                fin_cfg: Dict[str, Any], transform_world: np.ndarray) -> SolidPart:
    """
    构建 S 轴伺服固定座 (MFG-BRK-S-MOUNT)。
    使用 6mm 厚 PETG/铝合金双侧夹持耳板 + 底板，利用 SER-2010 侧面既有 4×Ø3.2mm 通孔穿透紧固，
    将 S 轴伺服稳固固定在主承力框架外缘，避免在伺服壳体打孔。
    """
    thk = 6.0
    # 顶层法兰板 72 x 56 x 6 mm (固定于主框架中层板 Z=0)
    v_top, f_top, vol_top = make_box_mesh(56.0, 72.0, thk, center=(-12.0, 0.0, -thk / 2.0))
    # 两侧竖直夹板 54 x 6 x 48 mm (夹持 S 伺服 Y=±16mm 两侧面)
    v_left, f_left, vol_left = make_box_mesh(54.0, thk, 48.0, center=(-12.0, -19.0, -24.0))
    v_right, f_right, vol_right = make_box_mesh(54.0, thk, 48.0, center=(-12.0, 19.0, -24.0))

    verts, faces, total_vol = combine_meshes([
        (v_top, f_top, vol_top),
        (v_left, f_left, vol_left),
        (v_right, f_right, vol_right),
    ])

    holes = [
        HoleFeature(-28.0, -28.0, 4.2, "THROUGH", "4×Ø4.2 框架安装孔 (M4穿透螺栓+大垫圈)", thk, False),
        HoleFeature(4.0, -28.0, 4.2, "THROUGH", "4×Ø4.2 框架安装孔 (M4穿透螺栓+大垫圈)", thk, False),
        HoleFeature(-28.0, 28.0, 4.2, "THROUGH", "4×Ø4.2 框架安装孔 (M4穿透螺栓+大垫圈)", thk, False),
        HoleFeature(4.0, 28.0, 4.2, "THROUGH", "4×Ø4.2 框架安装孔 (M4穿透螺栓+大垫圈)", thk, False),
        HoleFeature(-34.0, -11.0, 3.2, "THROUGH", "4×Ø3.2 伺服侧面穿透安装孔 (配M3×45螺栓, 孔距待复核)", thk, True),
        HoleFeature(10.0, -11.0, 3.2, "THROUGH", "4×Ø3.2 伺服侧面穿透安装孔 (配M3×45螺栓, 孔距待复核)", thk, True),
    ]
    outline = [(-40.0, -36.0), (16.0, -36.0), (16.0, 36.0), (-40.0, 36.0)]

    return SolidPart(
        part_id="MFG-BRK-S-MOUNT",
        instance_id=f"BRK-S-{mod_code}",
        name_cn=f"S轴伺服框架固定座 ({mod_code}模块)",
        name_en=f"S-Axis Servo Frame Mount Bracket ({mod_code})",
        category="MANUFACTURED_PRINT",
        subsystem=f"FIN_{mod_code}",
        material_code="PETG_3D_PRINTED",
        credibility_level="SELF_DESIGN",
        ver_version="2.0",
        vertices_local=verts,
        faces=faces,
        analytic_volume_mm3=total_vol * 0.92,
        plate_thickness_mm=thk,
        holes_2d=holes,
        outline_2d=outline,
        dimensions_summary={"length_mm": 56.0, "width_mm": 72.0, "height_mm": 48.0, "wall_thickness_mm": 6.0},
        uncertain_flags=["UNC-001: 侧面M3穿透孔位与SER-2010官方STEP联动"],
        source_reference="实施总册 P9, P11, P13",
        color_rgb=(0.20, 0.42, 0.68),
        transform_world=transform_world,
        freecad_recipe={"type": "S_Servo_Mount_Bracket", "thickness": thk}
    )


def build_short_yoke_solid(mod_code: str, fin_cfg: Dict[str, Any], transform_world: np.ndarray) -> SolidPart:
    """
    构建短而宽的刚性转架 (MFG-YOKE-SHORT)。
    连接于 S 轴输出毂上端，随 S 轴在水平面摆动，同时通过双侧夹板 + 隔柱抱紧固定 P 轴伺服机壳。
    局部坐标系：原点在 S 轴输出毂上表面中心，+X 为模块向外径向 u 轴，+Z 向下。
    """
    mech = fin_cfg["fin_module_mechanics"]
    thk = float(mech["yoke_plate_thickness_mm"])        # 6.0 mm
    arm_l = float(mech["yoke_arm_length_mm"])           # 48.0 mm
    width = float(mech["yoke_width_mm"])                # 46.0 mm
    s_to_p = float(mech["s_to_p_radial_offset_mm"])     # 38.0 mm

    # 1. 转架根部法兰座 (连接 S 轴 SER-0011 毂, X in [-14, 24], Y in [-23, 23], Z in [-thk, 0])
    v_base, f_base, vol_base = make_box_mesh(38.0, width, thk, center=(5.0, 0.0, -thk / 2.0))
    # 2. 左右两片短而宽的侧翼夹板 (抱紧 P 轴伺服两侧, X in [10, 10+arm_l], Y = ±19mm, Z in [-20, 20])
    v_wing_l, f_wing_l, vol_wl = make_box_mesh(arm_l, thk, 38.0, center=(10.0 + arm_l / 2.0, -19.0, 4.0))
    v_wing_r, f_wing_r, vol_wr = make_box_mesh(arm_l, thk, 38.0, center=(10.0 + arm_l / 2.0, 19.0, 4.0))
    # 3. 顶部与底部横向连接加强桥板/隔柱 (组成高抗扭箱式短转架，减小 S 轴悬臂变形)
    v_bridge, f_bridge, vol_br = make_box_mesh(24.0, width, thk, center=(22.0, 0.0, -18.0))

    verts, faces, total_vol = combine_meshes([
        (v_base, f_base, vol_base),
        (v_wing_l, f_wing_l, vol_wl),
        (v_wing_r, f_wing_r, vol_wr),
        (v_bridge, f_bridge, vol_br),
    ])

    holes = [
        HoleFeature(0.0, 0.0, 6.5, "THROUGH", "Ø6.5 S轴中心避让孔", thk, False),
        HoleFeature(8.0, 0.0, 3.2, "THROUGH", "4×Ø3.2 S轴SER-0011输出毂连接孔 (PCD 16mm待复核)", thk, True),
        HoleFeature(-8.0, 0.0, 3.2, "THROUGH", "4×Ø3.2 S轴SER-0011输出毂连接孔 (PCD 16mm待复核)", thk, True),
        HoleFeature(0.0, 8.0, 3.2, "THROUGH", "4×Ø3.2 S轴SER-0011输出毂连接孔 (PCD 16mm待复核)", thk, True),
        HoleFeature(0.0, -8.0, 3.2, "THROUGH", "4×Ø3.2 S轴SER-0011输出毂连接孔 (PCD 16mm待复核)", thk, True),
        HoleFeature(24.0, -11.0, 3.2, "THROUGH", "4×Ø3.2 P轴伺服侧面穿透夹固孔 (M3×45螺栓)", thk, True),
        HoleFeature(50.0, -11.0, 3.2, "THROUGH", "4×Ø3.2 P轴伺服侧面穿透夹固孔 (M3×45螺栓)", thk, True),
    ]
    outline = [(-14.0, -23.0), (58.0, -23.0), (58.0, 23.0), (-14.0, 23.0)]

    return SolidPart(
        part_id="MFG-YOKE-SHORT",
        instance_id=f"YOKE-{mod_code}",
        name_cn=f"双自由度串联短转架 ({mod_code}模块)",
        name_en=f"Short Rigid Serial Yoke ({mod_code})",
        category="MANUFACTURED_PRINT",
        subsystem=f"FIN_{mod_code}",
        material_code="PETG_3D_PRINTED",
        credibility_level="SELF_DESIGN",
        ver_version="2.0",
        vertices_local=verts,
        faces=faces,
        analytic_volume_mm3=total_vol * 0.90,
        plate_thickness_mm=thk,
        holes_2d=holes,
        outline_2d=outline,
        dimensions_summary={"total_length_mm": 72.0, "width_mm": width, "height_mm": 40.0, "plate_thickness_mm": thk},
        uncertain_flags=[
            "UNC-001: P轴伺服侧面4×M3穿透孔位待实测复核",
            "UNC-002: S轴SER-0011输出毂法兰PCD待实测复核"
        ],
        source_reference="实施总册 P9, P11, P13",
        color_rgb=(0.24, 0.56, 0.82),
        transform_world=transform_world,
        freecad_recipe={"type": "Short_Rigid_Yoke", "arm_l": arm_l, "width": width, "thickness": thk}
    )


def build_fin_clamp_pair_solid(mod_code: str, fin_cfg: Dict[str, Any], transform_world: np.ndarray) -> SolidPart:
    """
    构建可拆卸圆角鳍片夹板组件 (MFG-FIN-CLAMP)。
    覆盖鳍片根部完整 20×40 mm 区域，两侧夹板通过 2×M3 穿透螺栓均匀夹紧，
    前缘与侧缘倒钝 R1/C1 防止切割柔性 PETG 鳍片根部 (实施总册 P10)。
    局部原点位于 P 轴输出毂外端面中心，+X 沿径向向外 (鳍片伸出方向)，鳍片宽度沿 Y 轴 (±20mm)，厚度沿 Z 轴。
    """
    clamp_cfg = fin_cfg["common_root_clamping"]
    c_len = float(clamp_cfg["clamp_length_radial_mm"])  # 20.0 mm
    f_wid = float(clamp_cfg["fin_width_mm"])            # 40.0 mm
    c_thk = float(clamp_cfg["clamp_plate_thickness_mm"]) # 4.0 mm

    # 根部与 P 轴输出毂连接的法兰座: X in [0, 8], Y in [-14, 14], Z in [-6, 6]
    v_collar, f_collar, vol_c = make_box_mesh(8.0, 28.0, 12.0, center=(4.0, 0.0, 0.0))
    # 上下两片 20×40×4 mm 圆角夹板: X in [6, 26], Y in [-20, 20], Z = ±(0.25 + c_thk/2)
    v_plate_1, f_plate_1, vol_p1 = make_box_mesh(c_len, f_wid, c_thk, center=(6.0 + c_len / 2.0, 0.0, 2.25))
    v_plate_2, f_plate_2, vol_p2 = make_box_mesh(c_len, f_wid, c_thk, center=(6.0 + c_len / 2.0, 0.0, -2.25))

    verts, faces, total_vol = combine_meshes([
        (v_collar, f_collar, vol_c),
        (v_plate_1, f_plate_1, vol_p1),
        (v_plate_2, f_plate_2, vol_p2),
    ])

    holes = [
        HoleFeature(16.0, -10.0, 3.2, "THROUGH", "Ø3.2 鳍片根部穿透夹紧孔 (离根端10mm, 离侧边10mm, 总册P10确定值)", c_thk * 2.0, False),
        HoleFeature(16.0, 10.0, 3.2, "THROUGH", "Ø3.2 鳍片根部穿透夹紧孔 (离根端10mm, 离侧边10mm, 总册P10确定值)", c_thk * 2.0, False),
        HoleFeature(3.0, -8.0, 3.2, "THROUGH", "P轴SER-0011毂连接孔 (待按厂家图复核)", 12.0, True),
        HoleFeature(3.0, 8.0, 3.2, "THROUGH", "P轴SER-0011毂连接孔 (待按厂家图复核)", 12.0, True),
    ]
    outline = [(0.0, -20.0), (26.0, -20.0), (26.0, 20.0), (0.0, 20.0)]

    return SolidPart(
        part_id="MFG-FIN-CLAMP",
        instance_id=f"CLAMP-{mod_code}",
        name_cn=f"可拆卸鳍片根部双夹板 ({mod_code}模块)",
        name_en=f"Removable Fin Root Clamp Plates ({mod_code})",
        category="MANUFACTURED_PRINT",
        subsystem=f"FIN_{mod_code}",
        material_code="PETG_3D_PRINTED",
        credibility_level="SELF_DESIGN",
        ver_version="2.0",
        vertices_local=verts,
        faces=faces,
        analytic_volume_mm3=total_vol,
        plate_thickness_mm=c_thk,
        holes_2d=holes,
        outline_2d=outline,
        dimensions_summary={
            "clamp_zone_length_mm": c_len,
            "clamp_zone_width_mm": f_wid,
            "plate_thickness_mm": c_thk,
            "bolt_hole_dia_mm": 3.2,
            "bolt_spacing_y_mm": 20.0,
            "edge_treatment": "夹板内侧与外缘 R1.0 倒钝防切鳍",
        },
        uncertain_flags=["UNC-002: 毂到夹板的安装孔距独立按SER-0011厂家图复核"],
        source_reference="实施总册 P10 (两片夹板覆盖根部完整20×40mm区域，两颗M3穿透螺栓均匀夹持)",
        color_rgb=(0.92, 0.52, 0.16),
        transform_world=transform_world,
        freecad_recipe={"type": "Fin_Clamp_Pair", "clamp_len": c_len, "width": f_wid, "thickness": c_thk}
    )


def build_fin_blade_solid(variant_code: str, fin_cfg: Dict[str, Any],
                          instance_id: str, subsystem: str,
                          transform_world: np.ndarray) -> SolidPart:
    """
    构建可替换透明 PETG 实心鳍片零件 (F-S: 80×40×0.5, F-M: 110×40×0.5, F-L: 140×40×0.5)。
    包含四个外角 R5 mm 圆角近似、根部 20×40 mm 夹持区与 2×Ø3.2 mm 安装通孔。
    局部坐标系：X in [6, 6 + total_length] (其中 [6, 26] 被夹板覆盖，[26, 6+total_length] 为外露有效区)，
    Y in [-20, +20] mm，Z in [-0.25, +0.25] mm。
    """
    v_info = fin_cfg["variants"][variant_code]
    total_l = float(v_info["total_length_mm"])
    width = float(v_info["width_mm"])
    thk = float(v_info["thickness_mm"])
    root_l = float(v_info["clamped_root_length_mm"])
    exposed_l = float(v_info["exposed_effective_length_mm"])
    r_fillet = float(fin_cfg["common_root_clamping"]["corner_fillet_radius_mm"])  # 5.0 mm

    # 采用带 R5 圆角倒角的多边形拉伸网格，精确反映圆角矩形轮廓
    x0, x1 = 6.0, 6.0 + total_l
    y0, y1 = -width / 2.0, width / 2.0
    r = r_fillet

    # 8-point chamfered/rounded contour in XY plane
    contour_2d = [
        (x0 + r, y0), (x1 - r, y0),
        (x1, y0 + r), (x1, y1 - r),
        (x1 - r, y1), (x0 + r, y1),
        (x0, y1 - r), (x0, y0 + r)
    ]

    verts, faces, _ = make_box_mesh(total_l, width, thk, center=(6.0 + total_l / 2.0, 0.0, 0.0))
    # 扣除 4 个 R5 圆角与 2 个 Ø3.2 通孔后的精确体积
    corner_loss = (4.0 - math.pi) * (r ** 2)
    hole_loss = 2.0 * math.pi * (1.6 ** 2)
    exact_area_mm2 = (total_l * width) - corner_loss - hole_loss
    exact_vol_mm3 = exact_area_mm2 * thk

    holes = [
        HoleFeature(x0 + 10.0, -10.0, 3.2, "THROUGH", "Ø3.2 根部M3穿透孔 (距根端10mm, 距侧边10mm)", thk, False),
        HoleFeature(x0 + 10.0, 10.0, 3.2, "THROUGH", "Ø3.2 根部M3穿透孔 (距根端10mm, 距侧边10mm)", thk, False),
    ]

    return SolidPart(
        part_id=v_info["part_number"],
        instance_id=instance_id,
        name_cn=f"{v_info['name']} ({instance_id})",
        name_en=f"VIVAK PETG Fin Blade {variant_code} ({total_l:.0f}x{width:.0f}x{thk:.1f}mm)",
        category="MANUFACTURED_PLATE",
        subsystem=subsystem,
        material_code="PETG_SOLID_SHEET",
        credibility_level="B",
        ver_version="2.0",
        vertices_local=verts,
        faces=faces,
        analytic_volume_mm3=exact_vol_mm3,
        plate_thickness_mm=thk,
        holes_2d=holes,
        outline_2d=contour_2d,
        dimensions_summary={
            "variant": variant_code,
            "total_length_mm": total_l,
            "width_mm": width,
            "thickness_mm": thk,
            "clamped_root_length_mm": root_l,
            "exposed_effective_length_mm": exposed_l,
            "nominal_exposed_area_mm2": float(v_info["nominal_exposed_area_mm2"]),
            "corner_fillet_radius_mm": r,
            "parameter_status": "DESIGN_TRIAL_START_PARAM (待确认设计起始参数，非厂家连续载荷保证)"
        },
        uncertain_flags=["UNC-005: 首样试验起点尺寸(80/110/140×40×0.5mm)，须经单鳍水中测力与耐久试验验证"],
        source_reference="实施总册 P10 表《首样试片与支架材料：明确的启动配置》",
        color_rgb=(0.15, 0.78, 0.96),
        transform_world=transform_world,
        freecad_recipe={"type": "Fin_Blade_Rounded", "variant": variant_code, "dims": [total_l, width, thk, r]}
    )


def build_cable_loop_envelope_solid(mod_code: str, servo_cfg: Dict[str, Any],
                                    transform_world: np.ndarray) -> SolidPart:
    """
    构建 P 轴伺服随动水下电缆受控弯曲环保守包络 (MFG-ENV-CABLE-LOOP)。
    满足实施总册 P10 第3条：连接器后留受控弯曲环 (最小弯曲半径 R>=35mm)，远端固定在静止框架，
    跟着转架往返，不绕输出轴缠圈，不进入鳍片扫掠区。
    """
    # 以半径 36mm、截面直径 10mm 的半圆弧环柱表示动态线缆活动包络
    v_loop, f_loop, vol_loop = make_cylinder_mesh(36.0, 12.0, axis="Z", center=(-15.0, 0.0, -52.0), segments=20)
    return SolidPart(
        part_id="ENV-CABLE-LOOP",
        instance_id=f"CABLE-LOOP-{mod_code}",
        name_cn=f"P轴活动线缆受控弯曲环包络 ({mod_code}模块)",
        name_en=f"P-Axis Dynamic Cable Bend Loop Envelope ({mod_code})",
        category="ENVELOPE",
        subsystem=f"FIN_{mod_code}",
        material_code="POM_ACETAL",
        credibility_level="B",
        ver_version="2.0",
        vertices_local=v_loop,
        faces=f_loop,
        analytic_volume_mm3=4500.0,
        override_mass_g=35.0,
        override_displaced_volume_cm3=25.0,
        is_envelope_only=True,
        dimensions_summary={"min_bend_radius_mm": 35.0, "loop_clearance_height_mm": 12.0},
        uncertain_flags=["UNC-003: 线缆动态弯曲环须在干态满行程台架循环观察确认"],
        source_reference="实施总册 P10, P13, P17",
        color_rgb=(0.95, 0.35, 0.20),
        transform_world=transform_world,
        freecad_recipe={"type": "Cable_Dynamic_Envelope", "bend_radius": 35.0}
    )
