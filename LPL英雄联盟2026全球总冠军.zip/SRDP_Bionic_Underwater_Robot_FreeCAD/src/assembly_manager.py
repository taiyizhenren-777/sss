#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
整机三维总装与单鳍模块装配管理器 (Full Robot & Single Fin Module Assembly Manager)
负责：
1. 构建单鳍模块完整双自由度串联装配体 (含 S/P 伺服、2个 SER-0011 输出毂、S轴固定座、短转架、鳍片夹板、F-S/F-M/F-L 三种鳍片、活动线缆包络)
2. 构建整机完整四鳍仿生水下机器人总装配体：
   - 4 套正交分布的双自由度仿生鳍模块 (L, R, F, B) -> 共 8 台 SER-2010 水下伺服 + 8 个 SER-0011 毂
   - 1 台中央 T200 垂向推进器 + 安装支架 + 2 个防缠绕保护环
   - 2 套对称平衡成品水密电子舱 + 4 套抱箍安装座
   - 1 套完整开放式承力框架 (主框板 + 4根2020铝型材梁 + 4块上下连接桥板 + 8根不锈钢隔柱 + 2套底部脚架 + 4个独立回收吊耳 + 3个理缆夹 + 1块上视双ArUco视觉靶板)
   - 2 块上部可调闭孔聚氨酯浮材
   - 2 条下部多孔可调配重导轨 + 4 块 316 不锈钢可调配重块
3. 支持动态更新任意姿态 (joint_pose_map) 下的全部零件世界坐标，供碰撞检测、运动包络渲染与 FreeCAD 导出使用。
"""
from typing import Dict, Any, List, Optional, Tuple
import numpy as np
from .component_library import SolidPart
from .parameter_manager import ParameterManager
from .kinematics import BionicFinKinematics
from .servo_model import build_ser2010_servo_solid, build_ser0011_hub_solid
from .fin_module import (
    build_s_servo_mount_bracket,
    build_short_yoke_solid,
    build_fin_clamp_pair_solid,
    build_fin_blade_solid,
    build_cable_loop_envelope_solid,
)
from .frame_generator import build_frame_components
from .enclosure_mount import build_enclosure_system
from .thruster_mount import build_thruster_system
from .buoyancy_system import build_buoyancy_system
from .ballast_system import build_ballast_system
from .cable_envelope import build_cable_management_clamps


class AssemblyManager:
    def __init__(self, pm: ParameterManager):
        self.pm = pm
        self.kin = BionicFinKinematics(pm)

    def build_single_fin_module_parts(self, mod_code: str = "F",
                                      cmd_s_deg: float = 0.0,
                                      cmd_p_deg: float = -45.0,
                                      fin_variant: str = "F-S",
                                      at_origin: bool = False) -> List[SolidPart]:
        """
        构建单套双自由度串联仿生鳍模块的全部零件列表。
        若 at_origin=True，则将该模块基座置于原点 (用于单鳍模块独立 CAD 文件、单鳍爆炸图与单鳍台架装配)。
        """
        servo_cfg = self.pm.get("servo_parameters")["servo_ser2010"]
        hub_cfg = self.pm.get("servo_parameters")["servo_hub_ser0011"]
        fin_cfg = self.pm.get("fin_parameters")

        tf = self.kin.compute_chain_transforms(mod_code, cmd_s_deg=cmd_s_deg, cmd_p_deg=cmd_p_deg)
        if at_origin:
            # 将 T_base 归一化到世界原点
            T_inv = np.linalg.inv(tf["T_base"])
            for k in ["T_base", "T_s_servo", "T_s_hub", "T_yoke", "T_p_servo", "T_p_hub", "T_fin_clamp", "T_fin_blade"]:
                tf[k] = T_inv @ tf[k]

        sub = f"FIN_{mod_code}"
        parts = [
            # 1. S 轴固定座 (固定于框架)
            build_s_servo_mount_bracket(mod_code, servo_cfg, fin_cfg, tf["T_base"]),
            # 2. S 轴水下伺服 (机壳固定于框架)
            build_ser2010_servo_solid(servo_cfg, f"S-{mod_code}", sub, tf["T_s_servo"]),
            # 3. S 轴 SER-0011 输出毂 (随 S 轴旋转)
            build_ser0011_hub_solid(hub_cfg, f"HUB-S-{mod_code}", sub, tf["T_s_hub"]),
            # 4. 串联短转架 (随 S 轴旋转)
            build_short_yoke_solid(mod_code, fin_cfg, tf["T_yoke"]),
            # 5. P 轴水下伺服 (机壳固定于转架上，随 S 轴旋转)
            build_ser2010_servo_solid(servo_cfg, f"P-{mod_code}", sub, tf["T_p_servo"]),
            # 6. P 轴 SER-0011 输出毂 (随 S 轴摆动 + 绕 P 轴羽化旋转)
            build_ser0011_hub_solid(hub_cfg, f"HUB-P-{mod_code}", sub, tf["T_p_hub"]),
            # 7. 可拆卸鳍片根部双夹板 (随 P 轴输出毂旋转)
            build_fin_clamp_pair_solid(mod_code, fin_cfg, tf["T_fin_clamp"]),
            # 8. 可替换 PETG 鳍片 (默认安装 F-S 小鳍首轮试验片)
            build_fin_blade_solid(fin_variant, fin_cfg, f"FIN-{fin_variant}-{mod_code}", sub, tf["T_fin_blade"]),
            # 9. P 轴活动电缆受控弯曲环包络
            build_cable_loop_envelope_solid(mod_code, servo_cfg, tf["T_yoke"]),
        ]
        return parts

    def build_full_robot_assembly(self,
                                  joint_angles: Optional[Dict[str, Tuple[float, float]]] = None,
                                  fin_variant: str = "F-S") -> List[SolidPart]:
        """
        构建完整四鳍仿生水下机器人总装配体的全部三维实体零件。
        joint_angles: {"L": (s_deg, p_deg), "R": (s_deg, p_deg), "F": (s_deg, p_deg), "B": (s_deg, p_deg)}
        默认全部处于 S=0° 中位、P=-45° 竖直工作迎水姿态。
        """
        if joint_angles is None:
            joint_angles = {
                "L": (0.0, -45.0),
                "R": (0.0, -45.0),
                "F": (0.0, -45.0),
                "B": (0.0, -45.0),
            }

        all_parts: List[SolidPart] = []

        # 1. 开放式承力框架、底部脚架、回收吊耳、上视双ID视觉靶
        all_parts.extend(build_frame_components(self.pm.get("frame_parameters"), self.pm.derived))

        # 2. 中央 T200 垂向推进器、安装座与上下进出水防护圈
        all_parts.extend(build_thruster_system(self.pm.get("thruster_parameters")))

        # 3. 成品水密电子舱系统与抱箍安装座
        all_parts.extend(build_enclosure_system(self.pm.get("enclosure_parameters"), self.pm.derived))

        # 4. 上部可调闭孔浮材系统
        all_parts.extend(build_buoyancy_system(self.pm.get("frame_parameters")))

        # 5. 下部多孔配重导轨与可移动配重块系统
        all_parts.extend(build_ballast_system(self.pm.get("frame_parameters")))

        # 6. 主系缆与穿舱线束固定保护夹
        all_parts.extend(build_cable_management_clamps())

        # 7. 四套正交分布的双自由度串联仿生鳍模块 (L, R, F, B)
        for mod_code in ["L", "R", "F", "B"]:
            s_deg, p_deg = joint_angles.get(mod_code, (0.0, -45.0))
            mod_parts = self.build_single_fin_module_parts(
                mod_code=mod_code,
                cmd_s_deg=s_deg,
                cmd_p_deg=p_deg,
                fin_variant=fin_variant,
                at_origin=False,
            )
            all_parts.extend(mod_parts)

        return all_parts

    def build_standalone_fin_variants(self) -> Dict[str, SolidPart]:
        """生成 F-S, F-M, F-L 三种独立可替换鳍片零件模型。"""
        fin_cfg = self.pm.get("fin_parameters")
        out = {}
        for v_code in ["F-S", "F-M", "F-L"]:
            out[v_code] = build_fin_blade_solid(
                v_code, fin_cfg, instance_id=f"STANDALONE-{v_code}",
                subsystem="FIN_SPARE", transform_world=np.eye(4, dtype=float)
            )
        return out
