"""SRDP Bionic Underwater Robot FreeCAD Parametric Engineering System V2.0"""
__version__ = "2.0.0"
