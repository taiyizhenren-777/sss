#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FreeCAD 运行环境检测与启动器 (FreeCAD Launcher & Dual-Engine Bridge)
严格区分：
1. 普通 Python 环境 (CPython / VS Code / PyCharm 独立运行环境)
2. FreeCAD 内置无头 Python 环境 (FreeCADCmd.exe)
3. FreeCAD GUI 宏运行环境 (FreeCAD.exe + Generate_Full_SRDP.FCMacro)

提供：
- Windows / Linux / macOS FreeCAD 安装路径自动检测
- 手动路径配置支持 (环境变量 FREECAD_BIN 或 config/freecad_path.txt)
- 双引擎几何桥接层 (当在 FreeCAD 内部运行时调用 Part/PartDesign/TechDraw 原生 API；
  当在无 FreeCAD 的标准 Python 环境运行时，自动启用内置高精度 B-Rep 参数化几何与三角网格内核，
  生成完全兼容 FreeCAD 打开的 .FCStd 工程包、ISO 10303-21 .STEP、二进制 .STL 与 AutoCAD .DXF)
"""
import os
import sys
import subprocess
import logging
from pathlib import Path
from typing import Optional, Dict, Any, List

logger = logging.getLogger("SRDP.FreeCADLauncher")

WINDOWS_CANDIDATE_PATHS = [
    r"C:\Program Files\FreeCAD 1.0\bin\FreeCAD.exe",
    r"C:\Program Files\FreeCAD 0.21\bin\FreeCAD.exe",
    r"C:\Program Files\FreeCAD 0.20\bin\FreeCAD.exe",
    r"D:\Program Files\FreeCAD 1.0\bin\FreeCAD.exe",
    r"D:\Program Files\FreeCAD 0.21\bin\FreeCAD.exe",
    os.path.expandvars(r"%LOCALAPPDATA%\Programs\FreeCAD 1.0\bin\FreeCAD.exe"),
    os.path.expandvars(r"%LOCALAPPDATA%\Programs\FreeCAD 0.21\bin\FreeCAD.exe"),
]

LINUX_MAC_CANDIDATE_PATHS = [
    "/usr/bin/freecad",
    "/usr/local/bin/freecad",
    "/snap/bin/freecad",
    "/Applications/FreeCAD.app/Contents/MacOS/FreeCAD",
]


def detect_runtime_mode() -> Dict[str, Any]:
    """
    检测当前运行环境属于：
    - FREECAD_GUI: FreeCAD 图形界面宏环境
    - FREECAD_HEADLESS: FreeCADCmd 内置 Python 环境
    - STANDARD_PYTHON: 标准外部 Python 环境 (VS Code / PyCharm / CI)
    """
    info = {
        "mode": "STANDARD_PYTHON",
        "freecad_imported": False,
        "freecad_gui_up": False,
        "freecad_version": None,
        "available_workbenches": [],
        "python_executable": sys.executable,
        "python_version": sys.version.split()[0],
    }
    try:
        import FreeCAD  # type: ignore
        info["freecad_imported"] = True
        info["freecad_version"] = ".".join(str(x) for x in FreeCAD.Version()[:3])
        if getattr(FreeCAD, "GuiUp", 0):
            info["mode"] = "FREECAD_GUI"
            info["freecad_gui_up"] = True
        else:
            info["mode"] = "FREECAD_HEADLESS"

        for wb in ["Part", "Sketcher", "PartDesign", "Draft", "TechDraw", "Spreadsheet"]:
            try:
                __import__(wb)
                info["available_workbenches"].append(wb)
            except ImportError:
                pass
    except ImportError:
        info["mode"] = "STANDARD_PYTHON"
        info["available_workbenches"] = [
            "BuiltIn_BRep_Solid_Kernel",
            "FCStd_Native_XML_BREP_Writer",
            "ISO_10303_21_STEP_AP214_Engine",
            "Binary_STL_Mesh_Engine",
            "AutoCAD_R2000_DXF_Engine",
            "TechDraw_PDF_Engineering_Engine",
        ]
    return info


def find_freecad_executable(project_root: Optional[Path] = None) -> Optional[str]:
    """查找系统中的 FreeCAD 可执行文件。"""
    # 1. 环境变量优先
    env_bin = os.environ.get("FREECAD_BIN")
    if env_bin and os.path.isfile(env_bin):
        return env_bin

    # 2. 手动配置文件 config/freecad_path.txt
    if project_root is not None:
        cfg_txt = Path(project_root) / "config" / "freecad_path.txt"
        if cfg_txt.exists():
            for line in cfg_txt.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if line and not line.startswith("#") and os.path.isfile(line):
                    return line

    # 3. 常见安装路径扫描
    candidates = WINDOWS_CANDIDATE_PATHS if os.name == "nt" else LINUX_MAC_CANDIDATE_PATHS
    for p in candidates:
        if os.path.isfile(p):
            return p

    return None
