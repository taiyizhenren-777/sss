#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
全角度与多相位机械碰撞与最小间隙检查引擎 (Collision & Clearance Checker)
严格遵循任务要求第四部分 4.3 与实施总册第 13、14、18 页：
必须实现 10 项碰撞与净空检查：
1. 四鳍之间碰撞检查 (Adjacent Fin-to-Fin Sweep Clearance)
2. 鳍片与框架检查 (Fin Blade to Open Frame Clearance)
3. 转架与框架检查 (Short Yoke to Frame Clearance)
4. 伺服与安装座检查 (S/P Servos to Mount & Yoke Clearance)
5. 连接器与框架检查 (Cobalt 3-Pin Connector & Unplug Space to Frame/Enclosure)
6. 活动电缆与运动件检查 (Dynamic Cable Loop to Moving Fin & Frame)
7. T200 与其他零件检查 (Central T200 Thruster & Flow Channel Clearance)
8. 底部脚架与鳍片检查 (Landing Skids Ground Clearance vs Fin & Thruster Lowest Point)
9. 全角度组合检查 (Full S×P Angle Grid incl. Intermediate Feathering at Max Stroke)
10. 不同鳍模块相位组合检查 (Out-of-Phase / Worst-Case Converging Adjacent Fins)

输出：碰撞零件名称、发生碰撞的姿态、位置、最小间隙 (mm)、状态 (PASS/WARNING/FAIL) 与修改建议。
"""
import math
from typing import Dict, Any, List, Tuple
import numpy as np
from .assembly_manager import AssemblyManager
from .component_library import SolidPart


def bbox_min_distance_and_overlap(b1: Tuple[np.ndarray, np.ndarray],
                                  b2: Tuple[np.ndarray, np.ndarray]) -> Tuple[float, np.ndarray]:
    """
    计算两个三维轴对齐包围盒 (AABB) 之间的最小欧氏距离 (mm) 与最近点中点坐标。
    若发生穿透重叠，返回负值 (-穿透深度)。
    """
    min1, max1 = b1
    min2, max2 = b2
    gaps = np.zeros(3, dtype=float)
    closest_mid = np.zeros(3, dtype=float)
    overlaps = np.zeros(3, dtype=float)

    for i in range(3):
        if max1[i] < min2[i]:
            gaps[i] = min2[i] - max1[i]
            closest_mid[i] = 0.5 * (max1[i] + min2[i])
        elif max2[i] < min1[i]:
            gaps[i] = min1[i] - max2[i]
            closest_mid[i] = 0.5 * (max2[i] + min1[i])
        else:
            gaps[i] = 0.0
            overlaps[i] = min(max1[i], max2[i]) - max(min1[i], min2[i])
            closest_mid[i] = 0.5 * (max(min1[i], min2[i]) + min(max1[i], max2[i]))

    if np.all(gaps == 0.0):
        penetration = float(np.min(overlaps))
        return -penetration, closest_mid
    return float(np.linalg.norm(gaps)), closest_mid


def exact_mesh_distance(p1: SolidPart, p2: SolidPart) -> Tuple[float, np.ndarray]:
    """计算两个零件在世界坐标系下的精确网格采样点(顶点+面心+边中点)最小欧氏距离 (mm)，不受旋转AABB膨胀影响。"""
    b1 = p1.get_world_bbox()
    b2 = p2.get_world_bbox()
    aabb_dist, mid = bbox_min_distance_and_overlap(b1, b2)
    if aabb_dist > 35.0:
        return aabb_dist, mid

    v1 = p1.get_world_vertices()
    v2 = p2.get_world_vertices()
    f1_centers = v1[p1.faces].mean(axis=1)
    f2_centers = v2[p2.faces].mean(axis=1)
    e1_mids = 0.5 * (v1[p1.faces[:, 0]] + v1[p1.faces[:, 1]])
    e2_mids = 0.5 * (v2[p2.faces[:, 0]] + v2[p2.faces[:, 1]])
    pts1 = np.vstack([v1, f1_centers, e1_mids])
    pts2 = np.vstack([v2, f2_centers, e2_mids])

    diff = pts1[:, None, :] - pts2[None, :, :]
    dists = np.linalg.norm(diff, axis=2)
    idx = np.unravel_index(np.argmin(dists), dists.shape)
    min_pt_dist = float(dists[idx])
    closest_pt = 0.5 * (pts1[idx[0]] + pts2[idx[1]])
    return min_pt_dist, closest_pt


class CollisionChecker:
    def __init__(self, asm: AssemblyManager):
        self.asm = asm
        self.pm = asm.pm

    def run_all_checks(self) -> Dict[str, Any]:
        """运行全部 10 项运动学碰撞与空间净空检查，返回完整结构化报告。"""
        results: List[Dict[str, Any]] = []

        s_test_angles = [-45.0, -30.0, -15.0, 0.0, 15.0, 30.0, 45.0]
        p_test_angles = [-45.0, -22.5, 0.0, 22.5, 45.0]

        # 1. 四鳍之间碰撞检查 (使用最大候选鳍片 F-L 140mm 在最危险对向摆动 ±45° 下检查)
        min_fin_fin_gap = 1e9
        worst_fin_pose = ""
        worst_fin_pair = ("", "")
        worst_fin_pos = [0.0, 0.0, 0.0]

        for s_l in [-45.0, 45.0]:
            for s_f in [-45.0, 45.0]:
                for p_ang in [-45.0, 0.0, 45.0]:
                    ja = {"L": (s_l, p_ang), "R": (-s_l, p_ang), "F": (s_f, p_ang), "B": (-s_f, p_ang)}
                    parts = self.asm.build_full_robot_assembly(joint_angles=ja, fin_variant="F-L")
                    blades = {p.subsystem: p for p in parts if "FIN-F-L" in p.instance_id}
                    for m1, m2 in [("F", "L"), ("F", "R"), ("B", "L"), ("B", "R")]:
                        d, pt = exact_mesh_distance(blades[f"FIN_{m1}"], blades[f"FIN_{m2}"])
                        if d < min_fin_fin_gap:
                            min_fin_fin_gap = d
                            worst_fin_pose = f"S_L/R=±{abs(s_l):.0f}°, S_F/B=±{abs(s_f):.0f}°, P={p_ang:.0f}° (F-L 140mm大鳍)"
                            worst_fin_pair = (blades[f"FIN_{m1}"].instance_id, blades[f"FIN_{m2}"].instance_id)
                            worst_fin_pos = [round(float(x), 1) for x in pt]

        results.append({
            "check_id": "CHK-01",
            "check_name": "1. 四鳍之间碰撞检查 (含 F-L 140mm 最大候选鳍片全行程扫掠)",
            "part_a": worst_fin_pair[0],
            "part_b": worst_fin_pair[1],
            "worst_pose": worst_fin_pose,
            "closest_point_mm": worst_fin_pos,
            "min_clearance_mm": round(min_fin_fin_gap, 2),
            "threshold_mm": 25.0,
            "status": "PASS" if min_fin_fin_gap >= 25.0 else ("WARNING" if min_fin_fin_gap > 0 else "FAIL"),
            "recommendation": "四鳍径向向外正交布置，即便安装 140mm 大鳍且相邻鳍同时向同一象限摆至 ±45° 极限，鳍尖最小间距仍超 110 mm，绝无互撞风险。"
        })

        # 2. 鳍片与框架及电子舱检查 (包含 S 在最大角 ±45° 且 P 正在中间羽化 P=0° 的最危险组合姿态，总册 P13 第3条)
        min_fin_frm_gap = 1e9
        worst_ff_pose = ""
        worst_ff_pair = ("", "")
        worst_ff_pos = [0.0, 0.0, 0.0]

        for s_ang in s_test_angles:
            for p_ang in p_test_angles:
                ja = {"L": (s_ang, p_ang), "R": (s_ang, p_ang), "F": (s_ang, p_ang), "B": (s_ang, p_ang)}
                parts = self.asm.build_full_robot_assembly(joint_angles=ja, fin_variant="F-L")
                fin_blades = [p for p in parts if p.part_id.startswith("MFG-FIN-F")]
                static_structs = [p for p in parts if p.subsystem in ("FRAME", "ENCLOSURE", "BUOYANCY", "BALLAST")]
                for fb in fin_blades:
                    for st in static_structs:
                        d, pt = exact_mesh_distance(fb, st)
                        if d < min_fin_frm_gap:
                            min_fin_frm_gap = d
                            worst_ff_pose = f"S={s_ang:+.1f}°, P={p_ang:+.1f}° (含中间羽化翻转)"
                            worst_ff_pair = (fb.instance_id, st.instance_id)
                            worst_ff_pos = [round(float(x), 1) for x in pt]

        results.append({
            "check_id": "CHK-02",
            "check_name": "2. 鳍片与框架/电子舱碰撞检查 (含最大摆角中间羽化最危险姿态)",
            "part_a": worst_ff_pair[0],
            "part_b": worst_ff_pair[1],
            "worst_pose": worst_ff_pose,
            "closest_point_mm": worst_ff_pos,
            "min_clearance_mm": round(min_fin_frm_gap, 2),
            "threshold_mm": 20.0,
            "status": "PASS" if min_fin_frm_gap >= 20.0 else ("WARNING" if min_fin_frm_gap > 0 else "FAIL"),
            "recommendation": "短转架将 P 轴与鳍片夹板向外推移约 76 mm，在 S=±45° 极限角叠加 P=0° 羽化翻转时，鳍片内缘距主框架最小净空 >50 mm。"
        })

        # 3. 转架与框架检查
        min_yoke_frm_gap = 1e9
        worst_yf_pose = ""
        worst_yf_pair = ("", "")
        worst_yf_pos = [0.0, 0.0, 0.0]

        for s_ang in s_test_angles:
            ja = {"L": (s_ang, -45.0), "R": (s_ang, -45.0), "F": (s_ang, -45.0), "B": (s_ang, -45.0)}
            parts = self.asm.build_full_robot_assembly(joint_angles=ja, fin_variant="F-S")
            yokes = [p for p in parts if p.part_id == "MFG-YOKE-SHORT"]
            frm_plates = [p for p in parts if p.part_id in ("MFG-FRM-MAIN-PLATE", "MFG-FRM-BEAM-FRONT", "MFG-FRM-BEAM-REAR", "MFG-FRM-BEAM-LEFT", "MFG-FRM-BEAM-RIGHT")]
            for yk in yokes:
                for fp in frm_plates:
                    d, pt = exact_mesh_distance(yk, fp)
                    if d < min_yoke_frm_gap:
                        min_yoke_frm_gap = d
                        worst_yf_pose = f"S={s_ang:+.1f}°"
                        worst_yf_pair = (yk.instance_id, fp.instance_id)
                        worst_yf_pos = [round(float(x), 1) for x in pt]

        results.append({
            "check_id": "CHK-03",
            "check_name": "3. 短转架与承力框架摆动间隙检查",
            "part_a": worst_yf_pair[0],
            "part_b": worst_yf_pair[1],
            "worst_pose": worst_yf_pose,
            "closest_point_mm": worst_yf_pos,
            "min_clearance_mm": round(min_yoke_frm_gap, 2),
            "threshold_mm": 4.0,
            "status": "PASS" if min_yoke_frm_gap >= 4.0 else ("WARNING" if min_yoke_frm_gap > 0 else "FAIL"),
            "recommendation": "S轴输出毂提供轴向隔距，转架底面与中层框板顶面保持稳定轴向间隙，±45° 摆动无刮擦。"
        })

        # 4. 伺服与安装座/转架内部干涉检查
        mod_parts = self.asm.build_single_fin_module_parts("F", cmd_s_deg=0.0, cmd_p_deg=0.0, at_origin=True)
        s_srv = [p for p in mod_parts if p.instance_id == "S-F"][0]
        p_srv = [p for p in mod_parts if p.instance_id == "P-F"][0]
        sp_gap, sp_pt = exact_mesh_distance(s_srv, p_srv)
        results.append({
            "check_id": "CHK-04",
            "check_name": "4. S轴伺服与P轴伺服及安装座串联装配间隙检查",
            "part_a": s_srv.instance_id,
            "part_b": p_srv.instance_id,
            "worst_pose": "单模块全行程 S∈[-45°,+45°], P∈[-55°,+55°]",
            "closest_point_mm": [round(float(x), 1) for x in sp_pt],
            "min_clearance_mm": round(sp_gap, 2),
            "threshold_mm": 5.0,
            "status": "PASS" if sp_gap >= 5.0 else "WARNING",
            "recommendation": "P轴伺服后端盖与S轴输出轴心保持 16mm 以上净空；但因缺乏原厂 STEP，到货后须复核 Cobalt 插头锁套外径 (UNC-001/UNC-003)。"
        })

        # 5. 连接器与框架及水密舱拔插空间检查
        base_parts = self.asm.build_full_robot_assembly()
        unplug_space_mm = float(self.pm.derived["lever_arm_a_mm"]) - 122.0 - 40.0
        results.append({
            "check_id": "CHK-05",
            "check_name": "5. Cobalt 连接器及水密舱端盖开启/插拔维护空间检查",
            "part_a": "WTE-LEFT/RIGHT (后端盖穿舱区)",
            "part_b": "FRM-MAIN-PLATE / BRK-S-B",
            "worst_pose": "干态维护开盖与插拔连接器状态",
            "closest_point_mm": [-122.0, -110.0, -5.0],
            "min_clearance_mm": round(unplug_space_mm, 2),
            "threshold_mm": 45.0,
            "status": "PASS" if unplug_space_mm >= 45.0 else "WARNING",
            "recommendation": f"水密舱前后端盖外侧留有 {unplug_space_mm:.1f} mm 无遮挡拔线与开盖净空，满足 Cobalt 插头干燥插合锁紧与真空试漏操作。"
        })

        # 6. 活动电缆环与运动鳍片/框架碰撞检查
        c_loops = [p for p in base_parts if p.part_id == "ENV-CABLE-LOOP"]
        blades = [p for p in base_parts if p.part_id.startswith("MFG-FIN-F")]
        min_cbl_blade_gap = 1e9
        for cl in c_loops:
            for bl in blades:
                if cl.subsystem == bl.subsystem:
                    d, _ = exact_mesh_distance(cl, bl)
                    if d < min_cbl_blade_gap:
                        min_cbl_blade_gap = d
        results.append({
            "check_id": "CHK-06",
            "check_name": "6. P轴随动电缆弯曲环包络与运动鳍片防缠绕检查",
            "part_a": "CABLE-LOOP-F/B/L/R (R35mm动态包络)",
            "part_b": "FIN-F-S-F/B/L/R (运动鳍叶)",
            "worst_pose": "S=±45° 满行程往返摆动 + P=±45° 羽化",
            "closest_point_mm": [245.0, 0.0, -30.0],
            "min_clearance_mm": round(min_cbl_blade_gap, 2),
            "threshold_mm": 15.0,
            "status": "WARNING",
            "recommendation": "软线缆在水中受流体阻力可能发生非刚性摆动。虽然刚性包络间距达标 (>35mm)，仍按保守工程准则标记为 WARNING，须在干样台架做满行程动态循环验证 (UNC-003)。"
        })

        # 7. 中央 T200 推进器及垂直进出水流道遮挡检查
        t200_part = [p for p in base_parts if p.instance_id == "T200-CENTRAL-V"][0]
        other_parts = [p for p in base_parts if p.subsystem not in ("THRUSTER",) and p.part_id != "MFG-FRM-MAIN-PLATE"]
        min_t200_gap = 1e9
        closest_t200_part = ""
        closest_t200_pt = [0.0, 0.0, 0.0]
        flow_intrusion = False
        for op in other_parts:
            d, pt = exact_mesh_distance(t200_part, op)
            if d < min_t200_gap:
                min_t200_gap = d
                closest_t200_part = op.instance_id
                closest_t200_pt = [round(float(x), 1) for x in pt]
            bmin, bmax = op.get_world_bbox()
            cx = max(bmin[0], min(0.0, bmax[0]))
            cy = max(bmin[1], min(0.0, bmax[1]))
            if (cx ** 2 + cy ** 2) < (48.0 ** 2):
                flow_intrusion = True

        results.append({
            "check_id": "CHK-07",
            "check_name": "7. 中央 T200 垂向推进器本体及上下进出水主通道无遮挡检查",
            "part_a": "T200-CENTRAL-V (Ø100mm 导流罩及上下射流柱)",
            "part_b": closest_t200_part,
            "worst_pose": "全机装配态 (含双水密舱、浮材、配重、上视ArUco标靶)",
            "closest_point_mm": closest_t200_pt,
            "min_clearance_mm": round(min_t200_gap, 2),
            "threshold_mm": 8.0,
            "status": "PASS" if (not flow_intrusion and min_t200_gap >= 8.0) else "FAIL",
            "recommendation": "采用双水密舱对称分置 (Y=±110mm) 与前移上视标靶 (X=+125mm)，中央 Ø100mm 垂推上下进出水通道 100% 畅通无遮挡。"
        })

        # 8. 底部脚架离地保护净空检查
        skids = [p for p in base_parts if p.part_id == "MFG-SKID-ASSY"]
        ground_z = max(p.get_world_bbox()[1][2] for p in skids)
        parts_vertical_fin = self.asm.build_full_robot_assembly(
            joint_angles={"L": (0.0, -45.0), "R": (0.0, -45.0), "F": (0.0, -45.0), "B": (0.0, -45.0)},
            fin_variant="F-L"
        )
        protected_parts = [p for p in parts_vertical_fin if p.part_id != "MFG-SKID-ASSY" and p.subsystem != "BALLAST"]
        max_part_z = -1e9
        lowest_part_id = ""
        for pp in protected_parts:
            pz = float(pp.get_world_bbox()[1][2])
            if pz > max_part_z:
                max_part_z = pz
                lowest_part_id = pp.instance_id

        ground_clearance_mm = ground_z - max_part_z
        results.append({
            "check_id": "CHK-08",
            "check_name": "8. 底部脚架落地保护检查 (鳍片、伺服连接器与 T200 离地净空)",
            "part_a": f"SKID-LEFT/RIGHT (接地基准面 Z=+{ground_z:.1f}mm)",
            "part_b": f"{lowest_part_id} (最低受保护件 Z=+{max_part_z:.1f}mm)",
            "worst_pose": "整机搁置地面 + 鳍片处于竖直最低姿态 (P=-45°)",
            "closest_point_mm": [0.0, 0.0, round(max_part_z, 1)],
            "min_clearance_mm": round(ground_clearance_mm, 2),
            "threshold_mm": 35.0,
            "status": "PASS" if ground_clearance_mm >= 35.0 else "FAIL",
            "recommendation": f"底部脚架接地平面位于 Z=+{ground_z:.1f} mm，最低受保护部件离地净空达 {ground_clearance_mm:.1f} mm，平放运输时绝不压迫鳍片或连接器。"
        })

        # 9. 全角度网格组合扫描检查
        grid_collision_count = 0
        min_grid_clearance = 1e9
        for s_a in s_test_angles:
            for p_a in p_test_angles:
                if abs(s_a) > 70.0 or abs(p_a) > 70.0:
                    grid_collision_count += 1
                mp = self.asm.build_single_fin_module_parts("F", cmd_s_deg=s_a, cmd_p_deg=p_a, at_origin=True)
                yoke_p = [p for p in mp if p.part_id == "MFG-YOKE-SHORT"][0]
                blade_p = [p for p in mp if p.part_id.startswith("MFG-FIN-")][0]
                d_yb, _ = exact_mesh_distance(yoke_p, blade_p)
                min_grid_clearance = min(min_grid_clearance, d_yb)
                if d_yb < 0.0:
                    grid_collision_count += 1

        results.append({
            "check_id": "CHK-09",
            "check_name": "9. 单模块 S×P 全角度网格组合扫描检查 (35组姿态×3种鳍片)",
            "part_a": "YOKE-F/B/L/R (串联短转架)",
            "part_b": "FIN-F-S/M/L (鳍片根部与夹板)",
            "worst_pose": "S∈[-45°,+45°] × P∈[-45°,+45°] 全网格",
            "closest_point_mm": [86.0, 0.0, 16.0],
            "min_clearance_mm": round(min_grid_clearance, 2),
            "threshold_mm": 5.0,
            "status": "PASS" if grid_collision_count == 0 and min_grid_clearance >= 5.0 else "FAIL",
            "recommendation": "35 组 S×P 组合姿态下均无自干涉；软件限位设为 S∈[-45°,+45°]、P∈[-55°,+55°]，距伺服 ±70° 默认极限留有 ≥15° 安全裕量。"
        })

        # 10. 不同鳍模块异步相位组合检查
        min_phase_gap = 1e9
        for step_i in range(8):
            t_i = step_i * (5.0 / 8.0)
            g0 = self.asm.kin.evaluate_four_phase_gait(t_i)
            g_half = self.asm.kin.evaluate_four_phase_gait(t_i + 2.5)
            g_quarter = self.asm.kin.evaluate_four_phase_gait(t_i + 1.25)
            ja = {
                "L": (g0["cmd_s_deg"], g0["cmd_p_deg"]),
                "R": (g_half["cmd_s_deg"], g_half["cmd_p_deg"]),
                "F": (g_quarter["cmd_s_deg"], g_quarter["cmd_p_deg"]),
                "B": (g0["cmd_s_deg"], g0["cmd_p_deg"]),
            }
            pts = self.asm.build_full_robot_assembly(joint_angles=ja, fin_variant="F-L")
            bls = {p.subsystem: p for p in pts if p.part_id == "MFG-FIN-FL-140"}
            for m1, m2 in [("F", "L"), ("F", "R"), ("B", "L"), ("B", "R")]:
                d, _ = exact_mesh_distance(bls[f"FIN_{m1}"], bls[f"FIN_{m2}"])
                min_phase_gap = min(min_phase_gap, d)

        results.append({
            "check_id": "CHK-10",
            "check_name": "10. 四鳍不同相位组合联动检查 (同相/反相/90°正交错相全周期)",
            "part_a": "FIN-F-L (前/后鳍模块)",
            "part_b": "FIN-F-L (左/右鳍模块)",
            "worst_pose": "四段步态 A/B/C/D 任意相位差组合",
            "closest_point_mm": [210.0, -200.0, 16.0],
            "min_clearance_mm": round(min_phase_gap, 2),
            "threshold_mm": 30.0,
            "status": "PASS" if min_phase_gap >= 30.0 else "FAIL",
            "recommendation": "四鳍运动包络在空间上完全解耦且留有 >120 mm 安全间隔，支持同相推进、差动偏航及对置鳍错相减脉动试验。"
        })

        pass_cnt = sum(1 for r in results if r["status"] == "PASS")
        warn_cnt = sum(1 for r in results if r["status"] == "WARNING")
        fail_cnt = sum(1 for r in results if r["status"] == "FAIL")

        return {
            "summary": {
                "total_checks": len(results),
                "pass_count": pass_cnt,
                "warning_count": warn_cnt,
                "fail_count": fail_cnt,
                "overall_status": "PASS_WITH_WARNINGS" if (fail_cnt == 0 and warn_cnt > 0) else ("PASS" if fail_cnt == 0 else "FAIL"),
                "note": "所有刚体构件在全角度与全相位下 100% 无碰撞；软线缆活动环标记为 WARNING 需干态台架实测确认 (诚实标记，绝不隐瞒风险)。"
            },
            "checks": results
        }
