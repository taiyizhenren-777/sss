#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
工程物料清单 (BOM) 与待确认参数表生成器 (BOM & Uncertain Parameter Sheet Generator)
生成：
1. output/bom/SRDP_Robot_BOM.csv (UTF-8 with BOM，方便 Windows Excel 直接双击打开不乱码)
2. output/bom/SRDP_Uncertain_Parameters.csv
3. output/bom/SRDP_Robot_BOM_and_Parameters.xlsx (多工作表专业工程工作簿，含 Excel 动态公式、汇总卡片与嵌入式分析图表)
"""
import csv
from pathlib import Path
from typing import Dict, Any, List
try:
    import openpyxl
    from openpyxl.chart import BarChart, Reference
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter
    from openpyxl.utils.cell import range_boundaries
    HAS_OPENPYXL = True
except ImportError:
    HAS_OPENPYXL = False


def _style_merged(ws, cell_range: str, font=None, fill=None, alignment=None, border=None):
    min_col, min_row, max_col, max_row = range_boundaries(cell_range)
    for row in ws.iter_rows(min_row=min_row, max_row=max_row, min_col=min_col, max_col=max_col):
        for cell in row:
            if font:
                cell.font = font
            if fill:
                cell.fill = fill
            if alignment:
                cell.alignment = alignment
            if border:
                cell.border = border


def _autofit_sheet(ws):
    merged_multi = {
        cell.coordinate
        for rng in ws.merged_cells.ranges
        if rng.min_col != rng.max_col
        for row in ws[rng.coord]
        for cell in row
    }
    for col in ws.columns:
        max_len = 0
        for cell in col:
            if cell.row in (1, 2, 4, 5, 6) or cell.coordinate in merged_multi:
                continue
            val = str(cell.value) if cell.value is not None else ""
            if not val.startswith("="):
                c_len = sum(2 if ord(ch) > 127 else 1 for ch in val)
                max_len = max(max_len, c_len)
        col_letter = get_column_letter(col[0].column)
        ws.column_dimensions[col_letter].width = min(max(max_len + 4, 12), 42)


class BOMGenerator:
    def __init__(self, pm, mass_report: Dict[str, Any]):
        self.pm = pm
        self.mass_report = mass_report
        self.project_root = pm.project_root
        self.bom_dir = self.project_root / "output" / "bom"
        self.bom_dir.mkdir(parents=True, exist_ok=True)

    def aggregate_bom_items(self) -> List[Dict[str, Any]]:
        grouped: Dict[str, Dict[str, Any]] = {}
        for row in self.mass_report["part_details"]:
            pid = row["part_id"]
            if pid not in grouped:
                grouped[pid] = {
                    "part_id": pid,
                    "name_cn": row["name_cn"].split(" (")[0],
                    "category": row["category"],
                    "subsystem": row["subsystem"],
                    "material_code": row["material_code"],
                    "credibility_level": row["credibility_level"],
                    "quantity": 0,
                    "unit_mass_g": row["mass_g"],
                    "unit_disp_cm3": row["displaced_volume_cm3"],
                    "drawing_no": self._map_drawing_no(pid),
                    "batch_plan": self._map_batch_plan(pid),
                    "remark": "整机装机件",
                }
            grouped[pid]["quantity"] += 1

        for v_code, pid, vname in [
            ("F-M", "MFG-FIN-FM-110", "F-M 中鳍替换试片 (110×40×0.5mm)"),
            ("F-L", "MFG-FIN-FL-140", "F-L 大鳍替换试片 (140×40×0.5mm)"),
        ]:
            if pid not in grouped:
                grouped[pid] = {
                    "part_id": pid,
                    "name_cn": vname,
                    "category": "MANUFACTURED_PLATE",
                    "subsystem": "FIN_SPARE",
                    "material_code": "PETG_SOLID_SHEET",
                    "credibility_level": "B",
                    "quantity": 4,
                    "unit_mass_g": 0.0,
                    "unit_disp_cm3": 0.0,
                    "drawing_no": "DRW-09",
                    "batch_plan": "第1批 (G3鳍面积试验组)",
                    "remark": "可替换试验备片 (待确认起点参数)",
                }

        return list(grouped.values())

    @staticmethod
    def _map_drawing_no(part_id: str) -> str:
        mapping = {
            "MFG-FRM-MAIN-PLATE": "DRW-06",
            "MFG-FRM-BEAM-FRONT": "DRW-06",
            "MFG-FRM-BEAM-REAR": "DRW-06",
            "MFG-FRM-BEAM-LEFT": "DRW-06",
            "MFG-FRM-BEAM-RIGHT": "DRW-06",
            "MFG-FRM-UPPER-BRIDGE": "DRW-06",
            "MFG-FRM-LOWER-BRIDGE": "DRW-06",
            "MFG-BRK-S-MOUNT": "DRW-07",
            "MFG-YOKE-SHORT": "DRW-08",
            "MFG-FIN-CLAMP": "DRW-09",
            "MFG-FIN-FS-080": "DRW-09",
            "MFG-FIN-FM-110": "DRW-09",
            "MFG-FIN-FL-140": "DRW-09",
            "MFG-T200-BRACKET": "DRW-10",
            "MFG-T200-GUARD": "DRW-10",
            "MFG-ENC-CRADLE": "DRW-11",
            "PUR-WTE-4IN-220": "DRW-11",
            "MFG-BALLAST-RAIL": "DRW-12",
            "PUR-BALLAST-SS316": "DRW-12",
            "MFG-SKID-ASSY": "DRW-13",
            "PUR-SER-2010": "DRW-04",
            "PUR-SER-0011": "DRW-04",
            "PUR-BR-T200": "DRW-10",
        }
        return mapping.get(part_id, "DRW-01")

    @staticmethod
    def _map_batch_plan(part_id: str) -> str:
        if part_id in ("PUR-SER-2010", "PUR-SER-0011", "MFG-BRK-S-MOUNT", "MFG-YOKE-SHORT", "MFG-FIN-CLAMP", "MFG-FIN-FS-080"):
            return "第1批单模块验证(2伺服/1鳍) -> 过门后第2批补齐4鳍8伺服"
        return "第2批全艇集成采购/加工"

    def generate_all(self) -> Dict[str, Path]:
        bom_items = self.aggregate_bom_items()
        unc_items = self.pm.get_uncertain_list()

        bom_csv = self.bom_dir / "SRDP_Robot_BOM.csv"
        with open(bom_csv, "w", encoding="utf-8-sig", newline="") as f:
            writer = csv.writer(f)
            writer.writerow([
                "序号", "零件编号(Part_ID)", "名称(Name)", "类别(Category)", "所属子系统(Subsystem)",
                "材料代号(Material)", "模型可信度(Credibility)", "装机数量(Qty)", "单件质量(g)",
                "总质量(g)", "单件排水体积(cm3)", "总排水体积(cm3)", "关联工程图号(Drawing)", "分批采购策略(Batch_Plan)", "备注(Remark)"
            ])
            for idx, item in enumerate(bom_items, start=1):
                q = item["quantity"]
                um = item["unit_mass_g"]
                ud = item["unit_disp_cm3"]
                writer.writerow([
                    idx, item["part_id"], item["name_cn"], item["category"], item["subsystem"],
                    item["material_code"], item["credibility_level"], q, round(um, 2),
                    round(q * um, 2), round(ud, 2), round(q * ud, 2),
                    item["drawing_no"], item["batch_plan"], item["remark"]
                ])

        unc_csv = self.bom_dir / "SRDP_Uncertain_Parameters.csv"
        with open(unc_csv, "w", encoding="utf-8-sig", newline="") as f:
            writer = csv.writer(f)
            writer.writerow([
                "待确认编号(Param_ID)", "关联部件编号(Component_ID)", "待确认参数名称",
                "当前占位设计值", "已知官方依据", "可信度等级", "实物复核与解除冻结方法", "关联图纸", "当前放行状态"
            ])
            for u in unc_items:
                writer.writerow([
                    u["param_id"], u["component_id"], u["parameter_name"],
                    u["current_placeholder_value"], u["known_official_facts"],
                    u["credibility_level"], u["verification_method"],
                    "; ".join(u["affected_drawings"]), u["release_status"]
                ])

        xlsx_path = self.bom_dir / "SRDP_Robot_BOM_and_Parameters.xlsx"
        self._build_excel_workbook(xlsx_path, bom_items, unc_items)

        return {
            "bom_csv": bom_csv,
            "uncertain_csv": unc_csv,
            "bom_xlsx": xlsx_path,
        }

    def _build_excel_workbook(self, xlsx_path: Path, bom_items: List[Dict[str, Any]], unc_items: List[Dict[str, Any]]) -> None:
        if not HAS_OPENPYXL:
            return
        wb = openpyxl.Workbook()

        PRIMARY = "1B365D"
        ALT_FILL = "F4F7FA"
        BORDER_CLR = "D0D7DE"

        header_fill = PatternFill(start_color=PRIMARY, end_color=PRIMARY, fill_type="solid")
        alt_fill = PatternFill(start_color=ALT_FILL, end_color=ALT_FILL, fill_type="solid")

        th_font = Font(name="Calibri", size=10, bold=True, color="FFFFFF")
        td_font = Font(name="Calibri", size=10, bold=False, color="1F2328")
        bold_font = Font(name="Calibri", size=10, bold=True, color="1B365D")

        thin_border = Border(
            left=Side(style="thin", color=BORDER_CLR),
            right=Side(style="thin", color=BORDER_CLR),
            top=Side(style="thin", color=BORDER_CLR),
            bottom=Side(style="thin", color=BORDER_CLR),
        )
        total_border = Border(
            top=Side(style="thin", color=PRIMARY),
            bottom=Side(style="double", color=PRIMARY),
            left=Side(style="thin", color=BORDER_CLR),
            right=Side(style="thin", color=BORDER_CLR),
        )

        # Sheet 1: 整机BOM总表 (Row 1 为标准表头)
        ws1 = wb.active
        ws1.title = "1_整机BOM总表"
        ws1.views.sheetView[0].showGridLines = True
        ws1.freeze_panes = "A2"

        headers1 = [
            "序号", "零件编号", "零件中文名称", "零件类别", "所属子系统",
            "材料编码", "可信度", "数量", "单件质量(g)", "总质量(g)",
            "单件排水(cm³)", "总排水(cm³)", "工程图号", "分批采购与加工说明"
        ]
        for col_idx, h_text in enumerate(headers1, start=1):
            c = ws1.cell(row=1, column=col_idx, value=h_text)
            c.font = th_font
            c.fill = header_fill
            c.border = thin_border
            c.alignment = Alignment(horizontal="left", vertical="center")
        ws1.row_dimensions[1].height = 26

        for idx, item in enumerate(bom_items, start=1):
            r = 1 + idx
            ws1.cell(row=r, column=1, value=idx)
            ws1.cell(row=r, column=2, value=item["part_id"])
            ws1.cell(row=r, column=3, value=item["name_cn"])
            ws1.cell(row=r, column=4, value=item["category"])
            ws1.cell(row=r, column=5, value=item["subsystem"])
            ws1.cell(row=r, column=6, value=item["material_code"])
            ws1.cell(row=r, column=7, value=item["credibility_level"])
            ws1.cell(row=r, column=8, value=int(item["quantity"]))
            ws1.cell(row=r, column=9, value=float(item["unit_mass_g"]))
            ws1.cell(row=r, column=10, value=f"=H{r}*I{r}")
            ws1.cell(row=r, column=11, value=float(item["unit_disp_cm3"]))
            ws1.cell(row=r, column=12, value=f"=H{r}*K{r}")
            ws1.cell(row=r, column=13, value=item["drawing_no"])
            ws1.cell(row=r, column=14, value=item["batch_plan"])

            for c_i in range(1, 15):
                cell = ws1.cell(row=r, column=c_i)
                cell.font = td_font
                cell.border = thin_border
                if idx % 2 == 0:
                    cell.fill = alt_fill
                if c_i in (1, 8):
                    cell.number_format = "#,##0"
                    cell.alignment = Alignment(horizontal="right", vertical="center")
                elif c_i in (9, 10, 11, 12):
                    cell.number_format = "#,##0.00"
                    cell.alignment = Alignment(horizontal="right", vertical="center")
                else:
                    cell.alignment = Alignment(horizontal="left", vertical="center")
            ws1.row_dimensions[r].height = 20

        last_data_row = 1 + len(bom_items)
        tot_r = last_data_row + 1
        ws1.cell(row=tot_r, column=1, value=len(bom_items) + 1)
        ws1.cell(row=tot_r, column=2, value="TOTAL")
        ws1.cell(row=tot_r, column=3, value="整机装机合计 (理论估算值)")
        ws1.cell(row=tot_r, column=4, value="SUMMARY")
        ws1.cell(row=tot_r, column=5, value="ALL")
        ws1.cell(row=tot_r, column=6, value="MULTI")
        ws1.cell(row=tot_r, column=7, value="B/C")
        ws1.cell(row=tot_r, column=8, value=f"=SUM(H2:H{last_data_row})")
        ws1.cell(row=tot_r, column=9, value=f"=AVERAGE(I2:I{last_data_row})")
        ws1.cell(row=tot_r, column=10, value=f"=SUM(J2:J{last_data_row})")
        ws1.cell(row=tot_r, column=11, value=f"=AVERAGE(K2:K{last_data_row})")
        ws1.cell(row=tot_r, column=12, value=f"=SUM(L2:L{last_data_row})")
        ws1.cell(row=tot_r, column=13, value="DRW-01~13")
        ws1.cell(row=tot_r, column=14, value="全艇配平后略正浮力 (+1.52 N)")

        for c_i in range(1, 15):
            cell = ws1.cell(row=tot_r, column=c_i)
            cell.font = bold_font
            cell.border = total_border
            if c_i in (1, 8):
                cell.number_format = "#,##0"
                cell.alignment = Alignment(horizontal="right", vertical="center")
            elif c_i in (9, 10, 11, 12):
                cell.number_format = "#,##0.00"
                cell.alignment = Alignment(horizontal="right", vertical="center")
            else:
                cell.alignment = Alignment(horizontal="left", vertical="center")
        ws1.row_dimensions[tot_r].height = 24

        # Sheet 2: 子系统质量与浮力分析 (Row 1 为标准表头)
        ws2 = wb.create_sheet(title="2_质量与浮力配平分析")
        ws2.views.sheetView[0].showGridLines = True
        ws2.freeze_panes = "A2"

        headers2 = ["子系统代号", "包含零件数", "空气质量 (g)", "排水体积 (cm³)", "浮力等效质量 (g)", "净浮力偏差 (g)"]
        for col_idx, h_text in enumerate(headers2, start=1):
            c = ws2.cell(row=1, column=col_idx, value=h_text)
            c.font = th_font
            c.fill = header_fill
            c.border = thin_border
            c.alignment = Alignment(horizontal="left", vertical="center")
        ws2.row_dimensions[1].height = 26

        sub_bd = self.mass_report["subsystem_breakdown"]
        sub_keys = sorted(sub_bd.keys())
        for idx, sk in enumerate(sub_keys, start=1):
            r = 1 + idx
            info = sub_bd[sk]
            ws2.cell(row=r, column=1, value=sk)
            ws2.cell(row=r, column=2, value=int(info["part_count"]))
            ws2.cell(row=r, column=3, value=float(info["mass_g"]))
            ws2.cell(row=r, column=4, value=float(info["displaced_volume_cm3"]))
            ws2.cell(row=r, column=5, value=f"=D{r}*0.9982")
            ws2.cell(row=r, column=6, value=f"=E{r}-C{r}")

            for c_i in range(1, 7):
                cell = ws2.cell(row=r, column=c_i)
                cell.font = td_font
                cell.border = thin_border
                if idx % 2 == 0:
                    cell.fill = alt_fill
                if c_i == 1:
                    cell.alignment = Alignment(horizontal="left", vertical="center")
                elif c_i == 2:
                    cell.number_format = "#,##0"
                    cell.alignment = Alignment(horizontal="right", vertical="center")
                else:
                    cell.number_format = "#,##0.00"
                    cell.alignment = Alignment(horizontal="right", vertical="center")
            ws2.row_dimensions[r].height = 20

        last_s_row = 1 + len(sub_keys)
        tot_s_row = last_s_row + 1
        ws2.cell(row=tot_s_row, column=1, value="整机合计 (Total)")
        ws2.cell(row=tot_s_row, column=2, value=f"=SUM(B2:B{last_s_row})")
        ws2.cell(row=tot_s_row, column=3, value=f"=SUM(C2:C{last_s_row})")
        ws2.cell(row=tot_s_row, column=4, value=f"=SUM(D2:D{last_s_row})")
        ws2.cell(row=tot_s_row, column=5, value=f"=SUM(E2:E{last_s_row})")
        ws2.cell(row=tot_s_row, column=6, value=f"=SUM(F2:F{last_s_row})")
        for c_i in range(1, 7):
            cell = ws2.cell(row=tot_s_row, column=c_i)
            cell.font = bold_font
            cell.border = total_border
            if c_i == 1:
                cell.alignment = Alignment(horizontal="left", vertical="center")
            elif c_i == 2:
                cell.number_format = "#,##0"
                cell.alignment = Alignment(horizontal="right", vertical="center")
            else:
                cell.number_format = "#,##0.00"
                cell.alignment = Alignment(horizontal="right", vertical="center")
        ws2.row_dimensions[tot_s_row].height = 24

        ws2.column_dimensions["G"].width = 4
        chart = BarChart()
        chart.type = "col"
        chart.style = 10
        chart.title = "各子系统空气质量 (g) 与浮力等效质量 (g) 对比"
        chart.y_axis.title = "质量 / 浮力等效 (g)"
        chart.x_axis.title = "子系统"
        chart.width = 16
        chart.height = 10
        data_ref = Reference(ws2, min_col=3, min_row=1, max_col=5, max_row=last_s_row)
        cats_ref = Reference(ws2, min_col=1, min_row=2, max_row=last_s_row)
        chart.add_data(data_ref, titles_from_data=True)
        chart.set_categories(cats_ref)
        ws2.add_chart(chart, "H2")

        # Sheet 3: 待确认参数与风险登记表 (Row 1 为标准表头)
        ws3 = wb.create_sheet(title="3_待确认参数与接口核查表")
        ws3.views.sheetView[0].showGridLines = True
        ws3.freeze_panes = "A2"

        headers3 = [
            "参数编号", "关联部件编号", "待确认参数名称", "当前设计占位值",
            "已确认官方事实依据", "可信度", "到货实物复核方法", "受影响工程图", "放行状态"
        ]
        for col_idx, h_text in enumerate(headers3, start=1):
            c = ws3.cell(row=1, column=col_idx, value=h_text)
            c.font = th_font
            c.fill = header_fill
            c.border = thin_border
            c.alignment = Alignment(horizontal="left", vertical="center")
        ws3.row_dimensions[1].height = 26

        for idx, u in enumerate(unc_items, start=1):
            r = 1 + idx
            ws3.cell(row=r, column=1, value=u["param_id"])
            ws3.cell(row=r, column=2, value=u["component_id"])
            ws3.cell(row=r, column=3, value=u["parameter_name"])
            ws3.cell(row=r, column=4, value=u["current_placeholder_value"])
            ws3.cell(row=r, column=5, value=u["known_official_facts"])
            ws3.cell(row=r, column=6, value=u["credibility_level"])
            ws3.cell(row=r, column=7, value=u["verification_method"])
            ws3.cell(row=r, column=8, value=", ".join(u["affected_drawings"]))
            ws3.cell(row=r, column=9, value=u["release_status"])

            for c_i in range(1, 10):
                cell = ws3.cell(row=r, column=c_i)
                cell.font = td_font
                cell.border = thin_border
                if idx % 2 == 0:
                    cell.fill = alt_fill
                cell.alignment = Alignment(horizontal="left", vertical="center")
            ws3.row_dimensions[r].height = 22

        for ws in (ws1, ws2, ws3):
            _autofit_sheet(ws)
            ws.page_setup.orientation = "landscape"
            ws.sheet_properties.pageSetUpPr.fitToPage = True

        wb.save(str(xlsx_path))
