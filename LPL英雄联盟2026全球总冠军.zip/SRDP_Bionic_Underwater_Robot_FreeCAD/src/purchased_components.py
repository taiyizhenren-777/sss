#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
采购件数字化模型库 (Purchased Components: T200 Thruster, Watertight Enclosures, Ballast Blocks, Fasteners)
严格执行三级可信度标记 (A/B/C级)，记录每个采购件的已知尺寸、待确认尺寸与替换接口。
"""
import math
from typing import Dict, Any, List
import numpy as np
from .component_library import (
    SolidPart, HoleFeature, make_box_mesh, make_cylinder_mesh, make_tube_mesh, combine_meshes
)


def build_t200_thruster_solid(thr_cfg: Dict[str, Any], transform_world: np.ndarray) -> SolidPart:
    """
    构建 Blue Robotics T200 中央垂向推进器数字模型 (B级：官方资料重建)。
    已知官方尺寸：
    - 总长 113.0 mm (沿局部 Z 轴，Z in [-56.5, +56.5] mm)
    - 导流罩外径 100.0 mm (半径 50.0 mm)
    - 螺旋桨直径 76.0 mm (半径 38.0 mm)
    - 安装座 4×M3 螺孔间距 19.0 mm + 1×M6 中心孔
    - 空气质量 344 g，水中表观质量 156 g (排水体积 188 cm³)
    """
    known = thr_cfg["known_dimensions_mm"]
    length = float(known["overall_length_mm"])           # 113.0 mm
    nozzle_od = float(known["nozzle_outer_diameter_mm"]) # 100.0 mm
    prop_dia = float(known["propeller_diameter_mm"])     # 76.0 mm
    hole_spc = float(known["mounting_hole_spacing_m3_mm"]) # 19.0 mm

    # 1. 导流罩圆筒 (长 78 mm, 外径 100 mm, 内径 80 mm)
    v_noz, f_noz, vol_noz = make_tube_mesh(nozzle_od / 2.0, 40.0, 78.0, axis="Z", center=(0.0, 0.0, 0.0), segments=28)
    # 2. 中央无刷外转子电机核心与前鼻锥 (总长 113 mm, 直径 42 mm)
    v_mot, f_mot, vol_mot = make_cylinder_mesh(21.0, length, axis="Z", center=(0.0, 0.0, 0.0), segments=20)
    # 3. 3片式 76mm 螺旋桨包络盘
    v_prop, f_prop, vol_prop = make_cylinder_mesh(prop_dia / 2.0, 18.0, axis="Z", center=(0.0, 0.0, 8.0), segments=24)
    # 4. 侧面安装凸台 (位于 X = +52 mm, 尺寸 12 x 32 x 36 mm)
    v_mnt, f_mnt, vol_mnt = make_box_mesh(12.0, 32.0, 36.0, center=(nozzle_od / 2.0 + 3.0, 0.0, 0.0))

    verts, faces, total_vol = combine_meshes([
        (v_noz, f_noz, vol_noz),
        (v_mot, f_mot, vol_mot),
        (v_prop, f_prop, vol_prop),
        (v_mnt, f_mnt, vol_mnt),
    ])

    hs = hole_spc / 2.0
    holes = [
        HoleFeature(-hs, -hs, 3.0, "BLIND_THREAD", "M3×0.5 深6mm (官方已知19mm孔距)", 6.0, False),
        HoleFeature(hs, -hs, 3.0, "BLIND_THREAD", "M3×0.5 深6mm (官方已知19mm孔距)", 6.0, False),
        HoleFeature(-hs, hs, 3.0, "BLIND_THREAD", "M3×0.5 深6mm (官方已知19mm孔距)", 6.0, False),
        HoleFeature(hs, hs, 3.0, "BLIND_THREAD", "M3×0.5 深6mm (官方已知19mm孔距)", 6.0, False),
        HoleFeature(0.0, 0.0, 6.0, "BLIND_THREAD", "M6×1.0 深8mm 中心孔 (官方已知)", 8.0, False),
    ]

    return SolidPart(
        part_id=thr_cfg["part_number"],
        instance_id="T200-CENTRAL-V",
        name_cn=thr_cfg["name"],
        name_en="Blue Robotics T200 Vertical Thruster",
        category="PURCHASED",
        subsystem="THRUSTER",
        material_code="POM_ACETAL",
        credibility_level=thr_cfg["credibility_level"],
        ver_version="2.0",
        vertices_local=verts,
        faces=faces,
        analytic_volume_mm3=total_vol,
        override_mass_g=float(known["mass_in_air_with_1m_cable_g"]),
        override_displaced_volume_cm3=float(known["displaced_volume_cm3"]),
        holes_2d=holes,
        dimensions_summary={
            "overall_length_mm_known": length,
            "nozzle_od_mm_known": nozzle_od,
            "propeller_dia_mm_known": prop_dia,
            "m3_hole_spacing_mm_known": hole_spc,
        },
        uncertain_flags=[],
        source_reference=thr_cfg["source_urls"][0],
        color_rgb=(0.12, 0.14, 0.16),
        transform_world=transform_world,
        freecad_recipe={"type": "T200_Thruster", "length": length, "nozzle_od": nozzle_od, "prop_dia": prop_dia}
    )


def build_watertight_enclosure_solid(enc_cfg: Dict[str, Any], instance_id: str,
                                     name_suffix: str, transform_world: np.ndarray) -> SolidPart:
    """
    构建成品圆柱锁定式水密电子舱 (4英寸系列级 C级/B级 参数化模型)。
    外径 Ø114 mm (内径 Ø102 mm)，含端盖总长 244 mm，沿机体 X 轴布置。
    后端盖含 8×Ø10 mm Cobalt/WetLink 穿舱器与泄压阀/Bar02 深度计接口。
    """
    dims = enc_cfg["dimensions_mm"]
    mb = enc_cfg["mass_and_buoyancy_per_unit"]
    od = float(dims["outer_diameter_mm"])                 # 114.0 mm
    tube_len = float(dims["tube_length_mm"])              # 220.0 mm
    total_len = float(dims["overall_length_with_endcaps_mm"])  # 244.0 mm

    # 主密封圆筒包络 (水密舱在水中按外包络全封闭计算排水体积)
    v_tube, f_tube, _ = make_cylinder_mesh(od / 2.0, tube_len, axis="X", center=(0.0, 0.0, 0.0), segments=32)
    # 前后端盖法兰 (两端各 12 mm 外露阶梯)
    v_cap_f, f_cap_f, _ = make_cylinder_mesh(od / 2.0 + 2.0, 12.0, axis="X", center=(tube_len / 2.0 + 6.0, 0.0, 0.0), segments=32)
    v_cap_r, f_cap_r, _ = make_cylinder_mesh(od / 2.0 + 2.0, 12.0, axis="X", center=(-tube_len / 2.0 - 6.0, 0.0, 0.0), segments=32)

    # 后端盖 6 个主要穿舱器外露接头圆柱 (X = -total_len/2 - 12 mm)
    pen_meshes = []
    for k in range(6):
        ang = k * (2.0 * math.pi / 6.0)
        py = 30.0 * math.cos(ang)
        pz = 30.0 * math.sin(ang)
        vp, fp, volp = make_cylinder_mesh(7.0, 22.0, axis="X", center=(-total_len / 2.0 - 11.0, py, pz), segments=12)
        pen_meshes.append((vp, fp, volp))

    verts, faces, _ = combine_meshes([
        (v_tube, f_tube, 0.0),
        (v_cap_f, f_cap_f, 0.0),
        (v_cap_r, f_cap_r, 0.0),
    ] + pen_meshes)

    outer_vol_mm3 = math.pi * ((od / 2.0) ** 2) * total_len
    holes = []
    for k in range(8):
        ang = k * (2.0 * math.pi / 8.0)
        holes.append(HoleFeature(
            32.0 * math.cos(ang), 32.0 * math.sin(ang), 10.0,
            "THROUGH", f"孔#{k+1}: Ø10.0 穿舱器/泄压阀/Bar02接口 (待实配核对)", 18.0, True
        ))

    return SolidPart(
        part_id=enc_cfg["part_number"],
        instance_id=instance_id,
        name_cn=f"{enc_cfg['name']} - {name_suffix}",
        name_en=f"Watertight Electronics Enclosure ({instance_id})",
        category="PURCHASED",
        subsystem="ENCLOSURE",
        material_code="ACRYLIC_PMMA",
        credibility_level=enc_cfg["credibility_level"],
        ver_version="2.0",
        vertices_local=verts,
        faces=faces,
        analytic_volume_mm3=outer_vol_mm3,
        override_mass_g=float(mb["total_unit_mass_g"]),
        override_displaced_volume_cm3=float(mb["outer_displaced_volume_cm3"]),
        holes_2d=holes,
        dimensions_summary={
            "inner_diameter_mm_known": float(dims["inner_diameter_mm"]),
            "outer_diameter_mm": od,
            "overall_length_mm_placeholder": total_len,
            "endcap_open_clearance_mm": float(dims["endcap_open_clearance_mm"]),
        },
        uncertain_flags=["UNC-004: 水密电子舱管长与穿舱孔排布须按真实板卡1:1纸板排布后冻结"],
        source_reference=enc_cfg["source_urls"][0],
        color_rgb=(0.72, 0.88, 0.96),
        transform_world=transform_world,
        freecad_recipe={"type": "Watertight_Enclosure_4in", "od": od, "length": total_len}
    )
