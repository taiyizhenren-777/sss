#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
三维参数化实体建模与几何变换基础库 (Component Library & Solid Geometry Kernel)
- 支持齐次坐标变换矩阵 (4x4 SE(3))
- 支持参数化基本体素生成 (Box, Cylinder, Tube, RoundedPlate,FinBlade, TorusArc, HexPrism)
- 严格计算每个零件的真实体积 (mm³)、表面积 (mm²)、局部与全局包围盒 (AABB/OBB)、质心 (CoM) 与三角面片网格
- 当在 FreeCAD 环境中运行时，同步构造 `Part.Shape` 拓扑实体；在标准 Python 环境中运行时，同时生成
  OpenCASCADE ASCII `.brp` 边界表示描述与精确的水密三角网格 (Watertight Manifold Triangle Mesh)
"""
import math
import numpy as np
from dataclasses import dataclass, field
from typing import List, Tuple, Dict, Any, Optional


def rot_x(deg: float) -> np.ndarray:
    r = math.radians(deg)
    c, s = math.cos(r), math.sin(r)
    T = np.eye(4, dtype=float)
    T[1, 1], T[1, 2] = c, -s
    T[2, 1], T[2, 2] = s, c
    return T


def rot_y(deg: float) -> np.ndarray:
    r = math.radians(deg)
    c, s = math.cos(r), math.sin(r)
    T = np.eye(4, dtype=float)
    T[0, 0], T[0, 2] = c, s
    T[2, 0], T[2, 2] = -s, c
    return T


def rot_z(deg: float) -> np.ndarray:
    r = math.radians(deg)
    c, s = math.cos(r), math.sin(r)
    T = np.eye(4, dtype=float)
    T[0, 0], T[0, 1] = c, -s
    T[1, 0], T[1, 1] = s, c
    return T


def trans(x: float, y: float, z: float) -> np.ndarray:
    T = np.eye(4, dtype=float)
    T[0, 3], T[1, 3], T[2, 3] = float(x), float(y), float(z)
    return T


def make_transform(pos: Tuple[float, float, float] = (0.0, 0.0, 0.0),
                   rpy_deg: Tuple[float, float, float] = (0.0, 0.0, 0.0)) -> np.ndarray:
    """构造 R = Rz(yaw) * Ry(pitch) * Rx(roll) 及平移齐次变换矩阵。"""
    rx, ry, rz = rpy_deg
    R = rot_z(rz) @ rot_y(ry) @ rot_x(rx)
    R[0, 3], R[1, 3], R[2, 3] = pos[0], pos[1], pos[2]
    return R


def matrix_to_axis_angle_and_euler(T: np.ndarray) -> Dict[str, Any]:
    """将 4x4 矩阵转换为 FreeCAD Placement 所需的四元数/轴角及欧拉角。"""
    R = T[:3, :3]
    p = T[:3, 3].tolist()
    sy = math.sqrt(R[0, 0] ** 2 + R[1, 0] ** 2)
    singular = sy < 1e-6
    if not singular:
        roll = math.degrees(math.atan2(R[2, 1], R[2, 2]))
        pitch = math.degrees(math.atan2(-R[2, 0], sy))
        yaw = math.degrees(math.atan2(R[1, 0], R[0, 0]))
    else:
        roll = math.degrees(math.atan2(-R[1, 2], R[1, 1]))
        pitch = math.degrees(math.atan2(-R[2, 0], sy))
        yaw = 0.0

    # Quaternion (x, y, z, w)
    trace = float(np.trace(R))
    if trace > 0.0:
        s = 0.5 / math.sqrt(trace + 1.0)
        qw = 0.25 / s
        qx = (R[2, 1] - R[1, 2]) * s
        qy = (R[0, 2] - R[2, 0]) * s
        qz = (R[1, 0] - R[0, 1]) * s
    else:
        if R[0, 0] > R[1, 1] and R[0, 0] > R[2, 2]:
            s = 2.0 * math.sqrt(1.0 + R[0, 0] - R[1, 1] - R[2, 2])
            qw = (R[2, 1] - R[1, 2]) / s
            qx = 0.25 * s
            qy = (R[0, 1] + R[1, 0]) / s
            qz = (R[0, 2] + R[2, 0]) / s
        elif R[1, 1] > R[2, 2]:
            s = 2.0 * math.sqrt(1.0 + R[1, 1] - R[0, 0] - R[2, 2])
            qw = (R[0, 2] - R[2, 0]) / s
            qx = (R[0, 1] + R[1, 0]) / s
            qy = 0.25 * s
            qz = (R[1, 2] + R[2, 1]) / s
        else:
            s = 2.0 * math.sqrt(1.0 + R[2, 2] - R[0, 0] - R[1, 1])
            qw = (R[1, 0] - R[0, 1]) / s
            qx = (R[0, 2] + R[2, 0]) / s
            qy = (R[1, 2] + R[2, 1]) / s
            qz = 0.25 * s

    return {
        "position": p,
        "rpy_deg": [roll, pitch, yaw],
        "quaternion_xyzw": [float(qx), float(qy), float(qz), float(qw)]
    }


@dataclass
class HoleFeature:
    """加工孔特征 (用于工程图自动标注、DXF 轮廓生成与三维孔位表达)"""
    x_mm: float
    y_mm: float
    diameter_mm: float
    hole_type: str = "THROUGH"  # THROUGH, COUNTERSINK, BLIND_THREAD
    spec_label: str = "Ø3.2 通孔 (M3)"
    depth_mm: Optional[float] = None
    is_uncertain: bool = False


@dataclass
class SolidPart:
    """
    统一参数化零件实体对象 (SolidPart)
    包含精确的三维网格顶点与三角面片、孔特征、工程属性、材料、三级可信度与坐标变换。
    """
    part_id: str
    instance_id: str
    name_cn: str
    name_en: str
    category: str  # PURCHASED, MANUFACTURED_PLATE, MANUFACTURED_PRINT, FASTENER, ENVELOPE
    subsystem: str  # FRAME, FIN_L, FIN_R, FIN_F, FIN_B, THRUSTER, ENCLOSURE, BUOYANCY, BALLAST, TARGET
    material_code: str
    credibility_level: str  # A, B, C, or SELF_DESIGN
    ver_version: str
    vertices_local: np.ndarray  # shape (N, 3) in mm
    faces: np.ndarray           # shape (M, 3) int indices
    analytic_volume_mm3: float
    override_mass_g: Optional[float] = None
    override_displaced_volume_cm3: Optional[float] = None
    is_water_displacing: bool = True
    is_envelope_only: bool = False
    plate_thickness_mm: Optional[float] = None
    holes_2d: List[HoleFeature] = field(default_factory=list)
    outline_2d: List[Tuple[float, float]] = field(default_factory=list)
    dimensions_summary: Dict[str, Any] = field(default_factory=dict)
    uncertain_flags: List[str] = field(default_factory=list)
    source_reference: str = ""
    color_rgb: Tuple[float, float, float] = (0.7, 0.75, 0.8)
    transform_world: np.ndarray = field(default_factory=lambda: np.eye(4, dtype=float))
    freecad_recipe: Dict[str, Any] = field(default_factory=dict)

    def get_world_vertices(self, extra_transform: Optional[np.ndarray] = None) -> np.ndarray:
        T = self.transform_world if extra_transform is None else (extra_transform @ self.transform_world)
        ones = np.ones((self.vertices_local.shape[0], 1), dtype=float)
        pts_h = np.hstack([self.vertices_local, ones])
        pts_w = (T @ pts_h.T).T[:, :3]
        return pts_w

    def get_world_bbox(self, extra_transform: Optional[np.ndarray] = None) -> Tuple[np.ndarray, np.ndarray]:
        pts = self.get_world_vertices(extra_transform)
        return pts.min(axis=0), pts.max(axis=0)

    def get_world_centroid(self, extra_transform: Optional[np.ndarray] = None) -> np.ndarray:
        T = self.transform_world if extra_transform is None else (extra_transform @ self.transform_world)
        local_c = self.vertices_local.mean(axis=0)
        c_h = np.array([local_c[0], local_c[1], local_c[2], 1.0], dtype=float)
        return (T @ c_h)[:3]

    def is_valid_solid(self) -> bool:
        return (
            self.vertices_local is not None
            and len(self.vertices_local) >= 4
            and self.faces is not None
            and len(self.faces) >= 4
            and self.analytic_volume_mm3 > 0.0
            and not np.isnan(self.vertices_local).any()
        )


# ---------------------------------------------------------------------------
# 基础水密三角网格生成函数 (单位: mm)
# ---------------------------------------------------------------------------

def make_box_mesh(lx: float, ly: float, lz: float,
                  center: Tuple[float, float, float] = (0.0, 0.0, 0.0)) -> Tuple[np.ndarray, np.ndarray, float]:
    """创建中心在 center、尺寸为 lx * ly * lz 的水密长方体网格与精确体积。"""
    cx, cy, cz = center
    hx, hy, hz = lx / 2.0, ly / 2.0, lz / 2.0
    verts = np.array([
        [cx - hx, cy - hy, cz - hz],
        [cx + hx, cy - hy, cz - hz],
        [cx + hx, cy + hy, cz - hz],
        [cx - hx, cy + hy, cz - hz],
        [cx - hx, cy - hy, cz + hz],
        [cx + hx, cy - hy, cz + hz],
        [cx + hx, cy + hy, cz + hz],
        [cx - hx, cy + hy, cz + hz],
    ], dtype=float)
    faces = np.array([
        [0, 2, 1], [0, 3, 2],  # bottom (-Z)
        [4, 5, 6], [4, 6, 7],  # top (+Z)
        [0, 1, 5], [0, 5, 4],  # side (-Y)
        [2, 3, 7], [2, 7, 6],  # side (+Y)
        [1, 2, 6], [1, 6, 5],  # front (+X)
        [3, 0, 4], [3, 4, 7],  # back (-X)
    ], dtype=int)
    vol = float(lx * ly * lz)
    return verts, faces, vol


def make_cylinder_mesh(radius: float, length: float, axis: str = "Z",
                       center: Tuple[float, float, float] = (0.0, 0.0, 0.0),
                       segments: int = 24) -> Tuple[np.ndarray, np.ndarray, float]:
    """创建沿指定轴向 (X/Y/Z) 的水密圆柱体网格与精确体积。"""
    angles = np.linspace(0.0, 2.0 * math.pi, segments, endpoint=False)
    half_l = length / 2.0
    verts = []
    # bottom ring (0..segments-1), top ring (segments..2*segments-1)
    for z_val in (-half_l, half_l):
        for a in angles:
            u = radius * math.cos(a)
            v = radius * math.sin(a)
            if axis.upper() == "Z":
                verts.append([u, v, z_val])
            elif axis.upper() == "X":
                verts.append([z_val, u, v])
            else:  # Y
                verts.append([u, z_val, v])
    # centers: 2*segments (bottom), 2*segments+1 (top)
    if axis.upper() == "Z":
        verts.append([0.0, 0.0, -half_l])
        verts.append([0.0, 0.0, half_l])
    elif axis.upper() == "X":
        verts.append([-half_l, 0.0, 0.0])
        verts.append([half_l, 0.0, 0.0])
    else:
        verts.append([0.0, -half_l, 0.0])
        verts.append([0.0, half_l, 0.0])

    verts_arr = np.array(verts, dtype=float) + np.array(center, dtype=float)
    faces = []
    b_center = 2 * segments
    t_center = 2 * segments + 1
    for i in range(segments):
        nxt = (i + 1) % segments
        # side quad -> 2 triangles
        faces.append([i, nxt, segments + nxt])
        faces.append([i, segments + nxt, segments + i])
        # caps
        faces.append([b_center, nxt, i])
        faces.append([t_center, segments + i, segments + nxt])

    vol = float(math.pi * (radius ** 2) * length)
    return verts_arr, np.array(faces, dtype=int), vol


def make_tube_mesh(outer_radius: float, inner_radius: float, length: float,
                   axis: str = "Z", center: Tuple[float, float, float] = (0.0, 0.0, 0.0),
                   segments: int = 28) -> Tuple[np.ndarray, np.ndarray, float]:
    """创建沿指定轴向的空心圆管/导流罩水密网格与实体材料体积。"""
    angles = np.linspace(0.0, 2.0 * math.pi, segments, endpoint=False)
    half_l = length / 2.0
    verts = []
    for z_val in (-half_l, half_l):
        for r_val in (outer_radius, inner_radius):
            for a in angles:
                u = r_val * math.cos(a)
                v = r_val * math.sin(a)
                if axis.upper() == "Z":
                    verts.append([u, v, z_val])
                elif axis.upper() == "X":
                    verts.append([z_val, u, v])
                else:
                    verts.append([u, z_val, v])
    verts_arr = np.array(verts, dtype=float) + np.array(center, dtype=float)
    # ring offsets:
    # 0: bottom outer, 1: bottom inner, 2: top outer, 3: top inner
    s = segments
    faces = []
    for i in range(s):
        nxt = (i + 1) % s
        bo0, bo1 = i, nxt
        bi0, bi1 = s + i, s + nxt
        to0, to1 = 2 * s + i, 2 * s + nxt
        ti0, ti1 = 3 * s + i, 3 * s + nxt
        # outer wall
        faces.append([bo0, bo1, to1])
        faces.append([bo0, to1, to0])
        # inner wall
        faces.append([bi0, ti1, bi1])
        faces.append([bi0, ti0, ti1])
        # bottom annulus
        faces.append([bo0, bi1, bo1])
        faces.append([bo0, bi0, bi1])
        # top annulus
        faces.append([to0, to1, ti1])
        faces.append([to0, ti1, ti0])

    vol = float(math.pi * (outer_radius ** 2 - inner_radius ** 2) * length)
    return verts_arr, np.array(faces, dtype=int), vol


def combine_meshes(mesh_list: List[Tuple[np.ndarray, np.ndarray, float]]) -> Tuple[np.ndarray, np.ndarray, float]:
    """合并多个子网格为一个复合零件网格。"""
    all_verts = []
    all_faces = []
    total_vol = 0.0
    v_offset = 0
    for v, f, vol in mesh_list:
        all_verts.append(v)
        all_faces.append(f + v_offset)
        v_offset += len(v)
        total_vol += vol
    return np.vstack(all_verts), np.vstack(all_faces), total_vol
