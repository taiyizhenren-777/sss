#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
下部可调配重导轨与锁定配重块系统生成器 (Adjustable Lower Ballast Rail & Weights System)
遵循任务要求第五部分 5.3 与实施总册第 12、18、19 页：
- 配重导轨布置于下部低处 (Z = +85 mm)，使重心下移，提高被动横滚/俯仰恢复刚度
- 导轨带间距 15 mm 的定位长槽孔，316 不锈钢配重块可沿 X/Y 独立移动并锁紧，严禁零散螺母在舱内滑动
"""
from typing import Dict, Any, List
import numpy as np
from .component_library import SolidPart, HoleFeature, make_box_mesh, trans


def build_ballast_system(frame_cfg: Dict[str, Any]) -> List[SolidPart]:
    parts: List[SolidPart] = []
    bal_cfg = frame_cfg["ballast_system"]
    rl_x = float(bal_cfg["rail_length_x_mm"])     # 300.0 mm
    rw_y = float(bal_cfg["rail_width_mm"])        # 24.0 mm
    rt_z = float(bal_cfg["rail_thickness_mm"])    # 5.0 mm
    b_dims = bal_cfg["single_block_dims_mm"]      # [50, 30, 12]

    # 1. 左右两条下部可调配重导轨 (MFG-BALLAST-RAIL)
    for idx, rpos in enumerate(bal_cfg["rail_positions_mm"], start=1):
        side = "LEFT" if rpos[1] < 0 else "RIGHT"
        vr, fr, volr = make_box_mesh(rl_x, rw_y, rt_z, center=(0.0, 0.0, 0.0))
        holes = [
            HoleFeature(-95.0, 0.0, 5.2, "THROUGH", "Ø5.2 导轨与下部横梁固定孔 (M5)", rt_z, False),
            HoleFeature(95.0, 0.0, 5.2, "THROUGH", "Ø5.2 导轨与下部横梁固定孔 (M5)", rt_z, False),
        ]
        # 每隔 30 mm 布置配重锁紧定位孔
        for x_slot in [-120.0, -60.0, -30.0, 0.0, 30.0, 60.0, 120.0]:
            holes.append(HoleFeature(x_slot, 0.0, 4.2, "THROUGH", "Ø4.2 配重块分度调节锁紧孔 (M4)", rt_z, False))

        parts.append(SolidPart(
            part_id=bal_cfg["rail_part_number"],
            instance_id=f"BALLAST-RAIL-{side}",
            name_cn=f"下部多孔可调配重导轨 ({side})",
            name_en=f"Lower Slotted Adjustable Ballast Rail ({side})",
            category="MANUFACTURED_PLATE",
            subsystem="BALLAST",
            material_code="AL_6061_T6",
            credibility_level="SELF_DESIGN",
            ver_version="2.0",
            vertices_local=vr,
            faces=fr,
            analytic_volume_mm3=volr * 0.88,
            plate_thickness_mm=rt_z,
            holes_2d=holes,
            outline_2d=[(-rl_x / 2.0, -rw_y / 2.0), (rl_x / 2.0, -rw_y / 2.0), (rl_x / 2.0, rw_y / 2.0), (-rl_x / 2.0, rw_y / 2.0)],
            dimensions_summary={
                "length_x_mm": rl_x,
                "width_y_mm": rw_y,
                "thickness_mm": rt_z,
                "slot_pitch_mm": float(bal_cfg["slot_pitch_mm"]),
                "adjustable_range_x_mm": "±120.0"
            },
            source_reference="实施总册 P12, P18, P19 (可调配重固定在低处并可独立移动锁紧)",
            color_rgb=(0.55, 0.58, 0.62),
            transform_world=trans(*rpos),
            freecad_recipe={"type": "Ballast_Rail", "dims": [rl_x, rw_y, rt_z]}
        ))

    # 2. 4块 316 不锈钢可移动锁紧配重块 (对称布置在左右导轨 X = ±55 mm, Z = +94 mm)
    weight_positions = [
        ("W1-FL", [55.0, -110.0, 94.0]),
        ("W2-RL", [-55.0, -110.0, 94.0]),
        ("W3-FR", [55.0, 110.0, 94.0]),
        ("W4-RR", [-55.0, 110.0, 94.0]),
    ]
    for w_code, wpos in weight_positions:
        vw, fw, volw = make_box_mesh(b_dims[0], b_dims[1], b_dims[2], center=(0.0, 0.0, 0.0))
        parts.append(SolidPart(
            part_id=bal_cfg["weight_part_number"],
            instance_id=f"BALLAST-WT-{w_code}",
            name_cn=f"316不锈钢可调锁定配重块 ({w_code})",
            name_en=f"SS316 Adjustable Ballast Weight Block ({w_code})",
            category="PURCHASED",
            subsystem="BALLAST",
            material_code="SS_316",
            credibility_level="B",
            ver_version="2.0",
            vertices_local=vw,
            faces=fw,
            analytic_volume_mm3=volw,
            override_mass_g=float(bal_cfg["single_block_mass_g"]),
            override_displaced_volume_cm3=round(volw / 1000.0, 2),
            plate_thickness_mm=b_dims[2],
            holes_2d=[
                HoleFeature(-15.0, 0.0, 4.2, "THROUGH", "2×Ø4.2 配重锁紧孔 (M4防松螺母)", b_dims[2], False),
                HoleFeature(15.0, 0.0, 4.2, "THROUGH", "2×Ø4.2 配重锁紧孔 (M4防松螺母)", b_dims[2], False),
            ],
            dimensions_summary={"dims_mm": b_dims, "unit_mass_g": float(bal_cfg["single_block_mass_g"])},
            uncertain_flags=["UNC-006: 配重块数量与纵向位置须由水中静配平试验最终确定"],
            source_reference="实施总册 P18 (逐步配平操作第1、4条)",
            color_rgb=(0.42, 0.44, 0.48),
            transform_world=trans(*wpos),
            freecad_recipe={"type": "Ballast_Block", "dims": b_dims}
        ))

    return parts
