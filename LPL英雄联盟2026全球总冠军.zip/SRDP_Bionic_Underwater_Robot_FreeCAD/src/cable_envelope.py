#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
整机主系缆应力释放固定夹与静态走线保护结构生成器 (Tether Strain Relief & Cable Management)
遵循任务要求第一部分 1.1 第 12 项与实施总册第 17、23、24 页：
- 每根线有两个应力释放点：伺服附近的固定位置与电子舱附近的固定位置
- 主系缆 (2×4mm² 动力 + RS485 双绞信号) 的拉力由框架专用理缆夹承受，绝不作用在穿舱密封件上
"""
from typing import List
import numpy as np
from .component_library import SolidPart, HoleFeature, make_box_mesh, trans


def build_cable_management_clamps() -> List[SolidPart]:
    parts: List[SolidPart] = []
    clamp_positions = [
        ("CBL-CLAMP-MAIN-TETHER", [-150.0, 0.0, -2.0], "5m主系缆尾部框架应力释放夹"),
        ("CBL-CLAMP-DIST-L", [-115.0, -110.0, -45.0], "左舱尾端穿舱线束固定理线架"),
        ("CBL-CLAMP-DIST-R", [-115.0, 110.0, -45.0], "右舱尾端穿舱线束固定理线架"),
    ]
    for cid, pos, cname in clamp_positions:
        vc, fc, volc = make_box_mesh(28.0, 42.0, 14.0, center=(0.0, 0.0, 0.0))
        parts.append(SolidPart(
            part_id="MFG-CABLE-CLAMP",
            instance_id=cid,
            name_cn=cname,
            name_en=f"Cable Strain Relief & Routing Clamp ({cid})",
            category="MANUFACTURED_PRINT",
            subsystem="FRAME",
            material_code="PETG_3D_PRINTED",
            credibility_level="SELF_DESIGN",
            ver_version="2.0",
            vertices_local=vc,
            faces=fc,
            analytic_volume_mm3=volc * 0.80,
            plate_thickness_mm=14.0,
            holes_2d=[
                HoleFeature(0.0, -14.0, 4.2, "THROUGH", "2×Ø4.2 理缆夹安装孔 (M4)", 14.0, False),
                HoleFeature(0.0, 14.0, 4.2, "THROUGH", "2×Ø4.2 理缆夹安装孔 (M4)", 14.0, False),
                HoleFeature(0.0, 0.0, 10.5, "THROUGH", "Ø10.5 电缆护套夹持槽孔 (圆角防割护套)", 28.0, False),
            ],
            dimensions_summary={"dims_mm": [28.0, 42.0, 14.0], "cable_slot_dia_mm": 10.5},
            source_reference="实施总册 P17, P23, P24 (穿舱外侧应力释放固定在骨架上)",
            color_rgb=(0.30, 0.68, 0.38),
            transform_world=trans(*pos),
            freecad_recipe={"type": "Cable_Clamp", "dims": [28.0, 42.0, 14.0]}
        ))
    return parts
