#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
整机开放式承力框架生成器 (Open Load-Bearing Frame Generator)
严格按照任务要求第三部分 3.1 与实施总册第 6, 8, 11, 13, 18, 19, 36 页建立：
包含：
1. 主承力中层框板 (MFG-FRM-MAIN-PLATE) - 带 Ø116 mm 中央 T200 开放水流通道与减轻孔
2. 前部连接梁 (MFG-FRM-BEAM-FRONT) - 2020 阳极氧化铝合金型材
3. 后部连接梁 (MFG-FRM-BEAM-REAR) - 2020 阳极氧化铝合金型材
4. 左侧连接梁 (MFG-FRM-BEAM-LEFT) - 2020 阳极氧化铝合金型材
5. 右侧连接梁 (MFG-FRM-BEAM-RIGHT) - 2020 阳极氧化铝合金型材
6. 上部连接横梁结构 (MFG-FRM-TOP-BRIDGE x2)
7. 下部连接横梁结构 (MFG-FRM-BOT-BRIDGE x2)
8. 标准 316 不锈钢六角隔柱与立柱 (PUR-STANDOFF-M5x65 x8)
9. 底部双侧防触地承重脚架 (MFG-SKID-LEFT / MFG-SKID-RIGHT) - 确保鳍片、连接器与螺旋桨绝不触地
10. 独立回收绳固定吊耳 (MFG-LUG-RECOVERY x4) - 将回收载荷直接传到主框架，不传到电连接器
11. 上视双 ID ArUco 视觉标靶刚性安装板 (MFG-TARGET-ARUCO) - 不遮挡中央垂推水流与四鳍
"""
import math
from typing import Dict, Any, List
import numpy as np
from .component_library import (
    SolidPart, HoleFeature, make_box_mesh, make_cylinder_mesh, make_tube_mesh,
    combine_meshes, trans
)


def build_frame_components(frame_cfg: Dict[str, Any], derived: Dict[str, Any]) -> List[SolidPart]:
    parts: List[SolidPart] = []
    f_struct = frame_cfg["frame_structure"]

    core_x = float(derived["frame_core_length_x_mm"])     # 440.0 mm
    core_y = float(derived["frame_core_width_y_mm"])      # 400.0 mm
    bore_d = float(derived["tunnel_bore_dia_mm"])         # 116.0 mm
    lever_a = float(derived["lever_arm_a_mm"])            # 220.0 mm
    lever_b = float(derived["lever_arm_b_mm"])            # 200.0 mm
    upper_z = float(f_struct["upper_deck_z_mm"])          # -65.0 mm
    lower_z = float(f_struct["lower_deck_z_mm"])          # +65.0 mm
    skid_z = float(derived["skid_bottom_z_mm"])           # +135.0 mm
    plate_thk = 5.0

    # 1. 主承力中层环形框板 (MFG-FRM-MAIN-PLATE) 在 Z = 0 平面
    # 由中央垂推外围环形圈 + 前后左右四条十字承力臂组成开放式平板，绝不遮挡水密舱与垂推流道
    v_ring, f_ring, vol_ring = make_tube_mesh(92.0, bore_d / 2.0, plate_thk, axis="Z", center=(0.0, 0.0, 0.0), segments=36)
    v_arm_f, f_arm_f, vol_af = make_box_mesh(lever_a - 75.0, 76.0, plate_thk, center=((lever_a + 75.0) / 2.0 - 10.0, 0.0, 0.0))
    v_arm_b, f_arm_b, vol_ab = make_box_mesh(lever_a - 75.0, 76.0, plate_thk, center=(-(lever_a + 75.0) / 2.0 + 10.0, 0.0, 0.0))
    v_arm_l, f_arm_l, vol_al = make_box_mesh(76.0, lever_b - 75.0, plate_thk, center=(0.0, -(lever_b + 75.0) / 2.0 + 10.0, 0.0))
    v_arm_r, f_arm_r, vol_ar = make_box_mesh(76.0, lever_b - 75.0, plate_thk, center=(0.0, (lever_b + 75.0) / 2.0 - 10.0, 0.0))

    v_main, f_main, vol_main = combine_meshes([
        (v_ring, f_ring, vol_ring),
        (v_arm_f, f_arm_f, vol_af),
        (v_arm_b, f_arm_b, vol_ab),
        (v_arm_l, f_arm_l, vol_al),
        (v_arm_r, f_arm_r, vol_ar),
    ])

    main_holes = [
        HoleFeature(0.0, 0.0, bore_d, "THROUGH", f"Ø{bore_d:.0f} 中央T200垂推开放流道主孔", plate_thk, False),
        # 四个鳍模块基座安装孔组 (F, B, L, R)
        HoleFeature(lever_a - 18.0, -28.0, 4.2, "THROUGH", "F前鳍基座 4×Ø4.2 (M4)", plate_thk, False),
        HoleFeature(lever_a - 18.0, 28.0, 4.2, "THROUGH", "F前鳍基座 4×Ø4.2 (M4)", plate_thk, False),
        HoleFeature(-(lever_a - 18.0), -28.0, 4.2, "THROUGH", "B后鳍基座 4×Ø4.2 (M4)", plate_thk, False),
        HoleFeature(-(lever_a - 18.0), 28.0, 4.2, "THROUGH", "B后鳍基座 4×Ø4.2 (M4)", plate_thk, False),
        HoleFeature(-28.0, -(lever_b - 18.0), 4.2, "THROUGH", "L左鳍基座 4×Ø4.2 (M4)", plate_thk, False),
        HoleFeature(28.0, -(lever_b - 18.0), 4.2, "THROUGH", "L左鳍基座 4×Ø4.2 (M4)", plate_thk, False),
        HoleFeature(-28.0, lever_b - 18.0, 4.2, "THROUGH", "R右鳍基座 4×Ø4.2 (M4)", plate_thk, False),
        HoleFeature(28.0, lever_b - 18.0, 4.2, "THROUGH", "R右鳍基座 4×Ø4.2 (M4)", plate_thk, False),
    ]
    main_outline = [
        (-lever_a + 10.0, -38.0), (-75.0, -38.0), (-38.0, -75.0), (-38.0, -lever_b + 10.0),
        (38.0, -lever_b + 10.0), (38.0, -75.0), (75.0, -38.0), (lever_a - 10.0, -38.0),
        (lever_a - 10.0, 38.0), (75.0, 38.0), (38.0, 75.0), (38.0, lever_b - 10.0),
        (-38.0, lever_b - 10.0), (-38.0, 75.0), (-75.0, 38.0), (-lever_a + 10.0, 38.0),
    ]

    parts.append(SolidPart(
        part_id="MFG-FRM-MAIN-PLATE",
        instance_id="FRM-MAIN-PLATE-01",
        name_cn="主承力开放式十字中层框板",
        name_en="Main Open Cross Load-Bearing Frame Plate",
        category="MANUFACTURED_PLATE",
        subsystem="FRAME",
        material_code="AL_6061_T6",
        credibility_level="SELF_DESIGN",
        ver_version="2.0",
        vertices_local=v_main,
        faces=f_main,
        analytic_volume_mm3=vol_main * 0.88,
        plate_thickness_mm=plate_thk,
        holes_2d=main_holes,
        outline_2d=main_outline,
        dimensions_summary={
            "span_x_mm": core_x - 20.0,
            "span_y_mm": core_y - 20.0,
            "thickness_mm": plate_thk,
            "central_tunnel_bore_mm": bore_d,
            "design_status": "DESIGN_PLACEHOLDER (随力臂 a, b 与 T200 直径自动更新)"
        },
        uncertain_flags=["UNC-006: 框架力臂 a=220mm, b=200mm 为初始设计值"],
        source_reference="实施总册 P6, P7, P11, P13",
        color_rgb=(0.74, 0.77, 0.81),
        transform_world=np.eye(4, dtype=float),
        freecad_recipe={"type": "Main_Cross_Frame_Plate", "span_x": core_x, "span_y": core_y, "bore_d": bore_d, "thk": plate_thk}
    ))

    # 2–5. 前、后、左、右四根 2020 工业铝合金连接梁
    beam_specs = [
        ("MFG-FRM-BEAM-FRONT", "FRM-BEAM-F", "前部横向连接梁 (2020铝型材)", 20.0, 260.0, 20.0, (150.0, 0.0, 12.0)),
        ("MFG-FRM-BEAM-REAR",  "FRM-BEAM-B", "后部横向连接梁 (2020铝型材)", 20.0, 260.0, 20.0, (-150.0, 0.0, 12.0)),
        ("MFG-FRM-BEAM-LEFT",  "FRM-BEAM-L", "左侧纵向连接梁 (2020铝型材)", 320.0, 20.0, 20.0, (0.0, -155.0, 12.0)),
        ("MFG-FRM-BEAM-RIGHT", "FRM-BEAM-R", "右侧纵向连接梁 (2020铝型材)", 320.0, 20.0, 20.0, (0.0, 155.0, 12.0)),
    ]
    for p_id, inst_id, cname, lx, ly, lz, pos in beam_specs:
        vb, fb, volb = make_box_mesh(lx, ly, lz, center=(0.0, 0.0, 0.0))
        parts.append(SolidPart(
            part_id=p_id,
            instance_id=inst_id,
            name_cn=cname,
            name_en=f"2020 Aluminum Extrusion Beam ({inst_id})",
            category="MANUFACTURED_PLATE",
            subsystem="FRAME",
            material_code="AL_6063_T5",
            credibility_level="SELF_DESIGN",
            ver_version="2.0",
            vertices_local=vb,
            faces=fb,
            analytic_volume_mm3=volb * 0.58,  # 2020 型材空心截面填充率约 58%
            plate_thickness_mm=20.0,
            holes_2d=[HoleFeature(0.0, 0.0, 5.2, "THROUGH", "2020中心M5螺纹孔/T型槽", max(lx, ly), False)],
            outline_2d=[(-lx / 2.0, -ly / 2.0), (lx / 2.0, -ly / 2.0), (lx / 2.0, ly / 2.0), (-lx / 2.0, ly / 2.0)],
            dimensions_summary={"length_mm": max(lx, ly), "section_mm": "20x20"},
            source_reference="实施总册 P11, P13, P28 (B26 骨架与配平)",
            color_rgb=(0.68, 0.72, 0.76),
            transform_world=trans(*pos),
            freecad_recipe={"type": "Extrusion_2020", "dims": [lx, ly, lz]}
        ))

    # 6–7. 上部连接结构 (2根) 与下部连接结构 (2根)
    for idx, x_pos in enumerate([95.0, -95.0], start=1):
        # 上部横梁 (避开中央 [-60, +60] 垂推通道，放置在 X = ±95 mm, Z = upper_z)
        vt, ft, volt = make_box_mesh(24.0, 260.0, 5.0, center=(0.0, 0.0, 0.0))
        parts.append(SolidPart(
            part_id="MFG-FRM-UPPER-BRIDGE",
            instance_id=f"FRM-UPPER-BRG-{idx:02d}",
            name_cn=f"上部横向承力连接桥板 #{idx}",
            name_en=f"Upper Transverse Structural Bridge #{idx}",
            category="MANUFACTURED_PLATE",
            subsystem="FRAME",
            material_code="AL_6061_T6",
            credibility_level="SELF_DESIGN",
            ver_version="2.0",
            vertices_local=vt,
            faces=ft,
            analytic_volume_mm3=volt,
            plate_thickness_mm=5.0,
            holes_2d=[
                HoleFeature(0.0, -110.0, 5.2, "THROUGH", "Ø5.2 浮材与立柱连接孔", 5.0, False),
                HoleFeature(0.0, 110.0, 5.2, "THROUGH", "Ø5.2 浮材与立柱连接孔", 5.0, False),
            ],
            outline_2d=[(-12.0, -130.0), (12.0, -130.0), (12.0, 130.0), (-12.0, 130.0)],
            dimensions_summary={"length_y_mm": 260.0, "width_x_mm": 24.0, "thickness_mm": 5.0},
            source_reference="实施总册 P18 (不遮挡中央垂推上沿进水口)",
            color_rgb=(0.74, 0.77, 0.81),
            transform_world=trans(x_pos, 0.0, upper_z),
            freecad_recipe={"type": "Bridge_Plate", "dims": [24.0, 260.0, 5.0]}
        ))

        # 下部横梁 (放置在 X = ±95 mm, Z = lower_z)
        vb, fb, volb = make_box_mesh(24.0, 280.0, 5.0, center=(0.0, 0.0, 0.0))
        parts.append(SolidPart(
            part_id="MFG-FRM-LOWER-BRIDGE",
            instance_id=f"FRM-LOWER-BRG-{idx:02d}",
            name_cn=f"下部横向承力连接桥板 #{idx}",
            name_en=f"Lower Transverse Structural Bridge #{idx}",
            category="MANUFACTURED_PLATE",
            subsystem="FRAME",
            material_code="AL_6061_T6",
            credibility_level="SELF_DESIGN",
            ver_version="2.0",
            vertices_local=vb,
            faces=fb,
            analytic_volume_mm3=volb,
            plate_thickness_mm=5.0,
            holes_2d=[
                HoleFeature(0.0, -110.0, 5.2, "THROUGH", "Ø5.2 配重导轨安装孔", 5.0, False),
                HoleFeature(0.0, 110.0, 5.2, "THROUGH", "Ø5.2 配重导轨安装孔", 5.0, False),
                HoleFeature(0.0, -135.0, 5.2, "THROUGH", "Ø5.2 底部脚架安装孔", 5.0, False),
                HoleFeature(0.0, 135.0, 5.2, "THROUGH", "Ø5.2 底部脚架安装孔", 5.0, False),
            ],
            outline_2d=[(-12.0, -140.0), (12.0, -140.0), (12.0, 140.0), (-12.0, 140.0)],
            dimensions_summary={"length_y_mm": 280.0, "width_x_mm": 24.0, "thickness_mm": 5.0},
            source_reference="实施总册 P18, P19 (低位承重框架连接舱夹、配重导轨与脚架)",
            color_rgb=(0.74, 0.77, 0.81),
            transform_world=trans(x_pos, 0.0, lower_z),
            freecad_recipe={"type": "Bridge_Plate", "dims": [24.0, 280.0, 5.0]}
        ))

    # 8. 8根 M5×65 不锈钢支撑隔柱 (连接中层框板与上下层桥板)
    standoff_coords = [
        (95.0, -125.0, upper_z / 2.0), (95.0, 125.0, upper_z / 2.0),
        (-95.0, -125.0, upper_z / 2.0), (-95.0, 125.0, upper_z / 2.0),
        (95.0, -125.0, lower_z / 2.0), (95.0, 125.0, lower_z / 2.0),
        (-95.0, -125.0, lower_z / 2.0), (-95.0, 125.0, lower_z / 2.0),
    ]
    for s_idx, spos in enumerate(standoff_coords, start=1):
        vs, fs, vols = make_cylinder_mesh(4.5, 65.0, axis="Z", center=(0.0, 0.0, 0.0), segments=6)
        parts.append(SolidPart(
            part_id="PUR-STANDOFF-M5x65",
            instance_id=f"STANDOFF-{s_idx:02d}",
            name_cn=f"316不锈钢六角隔柱 M5×65 (#{s_idx})",
            name_en=f"SS316 Hex Standoff M5x65 (#{s_idx})",
            category="FASTENER",
            subsystem="FRAME",
            material_code="SS_316",
            credibility_level="A",
            ver_version="2.0",
            vertices_local=vs,
            faces=fs,
            analytic_volume_mm3=vols,
            dimensions_summary={"thread": "M5", "length_mm": 65.0, "hex_across_flats_mm": 8.0},
            source_reference="GB/T 316 不锈钢标准隔柱",
            color_rgb=(0.82, 0.84, 0.86),
            transform_world=trans(*spos),
            freecad_recipe={"type": "Hex_Standoff", "radius": 4.5, "length": 65.0}
        ))

    # 9. 底部双侧防触地脚架 (MFG-SKID-ASSY x2, 位于 Y = ±135 mm, Z 从 +65 到 +135 mm)
    skid_span_x = float(frame_cfg["landing_skids"]["span_x_mm"])  # 360.0 mm
    leg_h = skid_z - lower_z  # 70.0 mm
    for side_label, y_val in [("LEFT", -135.0), ("RIGHT", 135.0)]:
        # 底部滑撬长条 (360 x 14 x 8 mm) + 前后两根立柱 (20 x 14 x leg_h)
        v_runner, f_runner, vol_run = make_box_mesh(skid_span_x, 14.0, 8.0, center=(0.0, 0.0, leg_h - 4.0))
        v_leg1, f_leg1, vol_l1 = make_box_mesh(22.0, 14.0, leg_h, center=(95.0, 0.0, leg_h / 2.0))
        v_leg2, f_leg2, vol_l2 = make_box_mesh(22.0, 14.0, leg_h, center=(-95.0, 0.0, leg_h / 2.0))
        v_skid, f_skid, vol_skid = combine_meshes([
            (v_runner, f_runner, vol_run),
            (v_leg1, f_leg1, vol_l1),
            (v_leg2, f_leg2, vol_l2),
        ])
        parts.append(SolidPart(
            part_id="MFG-SKID-ASSY",
            instance_id=f"SKID-{side_label}",
            name_cn=f"底部承重防触地脚架 ({side_label})",
            name_en=f"Bottom Protective Landing Skid ({side_label})",
            category="MANUFACTURED_PLATE",
            subsystem="FRAME",
            material_code="AL_6061_T6",
            credibility_level="SELF_DESIGN",
            ver_version="2.0",
            vertices_local=v_skid,
            faces=f_skid,
            analytic_volume_mm3=vol_skid,
            plate_thickness_mm=14.0,
            holes_2d=[
                HoleFeature(95.0, 0.0, 5.2, "THROUGH", "Ø5.2 脚架立柱安装孔 (M5)", 14.0, False),
                HoleFeature(-95.0, 0.0, 5.2, "THROUGH", "Ø5.2 脚架立柱安装孔 (M5)", 14.0, False),
            ],
            outline_2d=[(-skid_span_x / 2.0, 0.0), (skid_span_x / 2.0, 0.0), (skid_span_x / 2.0, leg_h), (-skid_span_x / 2.0, leg_h)],
            dimensions_summary={
                "span_x_mm": skid_span_x,
                "height_mm": leg_h,
                "bottom_z_mm": skid_z,
                "ground_clearance_under_fins_mm": float(frame_cfg["landing_skids"]["ground_clearance_under_fins_mm"]),
            },
            source_reference="实施总册 P13, P19 (脚架落地时鳍、接插件和螺旋桨均不能触地)",
            color_rgb=(0.28, 0.32, 0.36),
            transform_world=trans(0.0, y_val, lower_z),
            freecad_recipe={"type": "Landing_Skid", "span_x": skid_span_x, "height": leg_h}
        ))

    # 10. 独立安全回收绳固定吊耳 (4个，固定在主框架上部四角，绝不拉扯电缆接头)
    lug_coords = [
        (95.0, -135.0, upper_z - 10.0),
        (95.0, 135.0, upper_z - 10.0),
        (-95.0, -135.0, upper_z - 10.0),
        (-95.0, 135.0, upper_z - 10.0),
    ]
    for l_idx, lpos in enumerate(lug_coords, start=1):
        vl, fl, voll = make_box_mesh(20.0, 6.0, 22.0, center=(0.0, 0.0, 0.0))
        parts.append(SolidPart(
            part_id="MFG-LUG-RECOVERY",
            instance_id=f"RECOVERY-LUG-{l_idx:02d}",
            name_cn=f"独立回收绳与系缆拉力固定吊耳 #{l_idx}",
            name_en=f"Recovery Rope & Tether Strain Relief Lug #{l_idx}",
            category="MANUFACTURED_PLATE",
            subsystem="FRAME",
            material_code="SS_316",
            credibility_level="SELF_DESIGN",
            ver_version="2.0",
            vertices_local=vl,
            faces=fl,
            analytic_volume_mm3=voll * 0.75,
            plate_thickness_mm=6.0,
            holes_2d=[HoleFeature(0.0, 0.0, 8.0, "THROUGH", "Ø8.0 安全回收绳卸扣孔 (R2倒圆防割绳)", 6.0, False)],
            dimensions_summary={"hole_dia_mm": 8.0, "thickness_mm": 6.0},
            source_reference="实施总册 P12, P17, P32 (回收载荷直接传到主框架，绝不传到穿舱件或电连接器)",
            color_rgb=(0.90, 0.25, 0.20),
            transform_world=trans(*lpos),
            freecad_recipe={"type": "Recovery_Lug", "dims": [20.0, 6.0, 22.0]}
        ))

    # 11. 上视双 ID ArUco 视觉标靶刚性安装板 (位于前部上方 X=+125mm, Y=0, Z=-78mm，完全避开中央垂推流道)
    tgt_cfg = f_struct["aruco_target_board"]
    tlx = float(tgt_cfg["length_x_mm"])     # 180.0 mm (沿 X 轴放置前后两个 ID)
    twy = float(tgt_cfg["width_y_mm"])      # 90.0 mm
    tthk = float(tgt_cfg["thickness_mm"])   # 3.0 mm
    tpos = tgt_cfg["mount_pos_mm"]          # [125.0, 0.0, -78.0]
    vtg, ftg, voltg = make_box_mesh(tlx, twy, tthk, center=(0.0, 0.0, 0.0))
    parts.append(SolidPart(
        part_id=tgt_cfg["part_number"],
        instance_id="ARUCO-TARGET-TOP",
        name_cn="朝上刚性双ID ArUco视觉定位标靶板",
        name_en="Upward Dual-ID ArUco Visual Target Board",
        category="MANUFACTURED_PLATE",
        subsystem="TARGET",
        material_code="PETG_3D_PRINTED",
        credibility_level="SELF_DESIGN",
        ver_version="2.0",
        vertices_local=vtg,
        faces=ftg,
        analytic_volume_mm3=voltg,
        plate_thickness_mm=tthk,
        holes_2d=[
            HoleFeature(-50.0, -35.0, 3.2, "COUNTERSINK", "4×M3 沉头安装孔 (保持标靶上表面平整哑光)", tthk, False),
            HoleFeature(-50.0, 35.0, 3.2, "COUNTERSINK", "4×M3 沉头安装孔 (保持标靶上表面平整哑光)", tthk, False),
            HoleFeature(50.0, -35.0, 3.2, "COUNTERSINK", "4×M3 沉头安装孔 (保持标靶上表面平整哑光)", tthk, False),
            HoleFeature(50.0, 35.0, 3.2, "COUNTERSINK", "4×M3 沉头安装孔 (保持标靶上表面平整哑光)", tthk, False),
        ],
        outline_2d=[(-tlx / 2.0, -twy / 2.0), (tlx / 2.0, -twy / 2.0), (tlx / 2.0, twy / 2.0), (-tlx / 2.0, twy / 2.0)],
        dimensions_summary={
            "length_x_mm": tlx,
            "width_y_mm": twy,
            "thickness_mm": tthk,
            "aruco_marker_spacing_mm": float(tgt_cfg["marker_center_spacing_mm"]),
            "marker_size_mm": float(tgt_cfg["marker_size_mm"]),
        },
        source_reference="实施总册 P8, P36 (两标记中心连线平行机体x轴，置于垂推与鳍叶不遮挡且不挡垂推流道的位置)",
        color_rgb=(0.95, 0.95, 0.95),
        transform_world=trans(*tpos),
        freecad_recipe={"type": "ArUco_Target_Board", "dims": [tlx, twy, tthk]}
    ))

    return parts
