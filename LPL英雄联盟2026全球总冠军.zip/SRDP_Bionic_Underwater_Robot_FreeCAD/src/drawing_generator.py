#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
工程图与制造交付生成器 (Engineering Drawing & 3D Preview Generator)
严格按照任务要求第七部分生成全部 13 张带完整尺寸标注、公差、孔位基准、通孔/沉孔说明、表面处理建议、
紧固件规格与待确认参数标识 (`[PENDING]`) 的工程图纸：
1. DRW-01_Full_Robot_Assembly.pdf (整机总装图)
2. DRW-02_Full_Robot_Three_Views.pdf (整机三视图)
3. DRW-03_Full_Robot_Isometric.pdf (整机等轴测与扫掠包络图)
4. DRW-04_Single_Fin_Module_Assembly.pdf (单鳍模块双自由度串联装配图)
5. DRW-05_Single_Fin_Exploded_View.pdf (单鳍模块爆炸装配关系图)
6. DRW-06_Frame_Main_Plate_Drawing.pdf (框架主承力十字框板零件图)
7. DRW-07_Servo_Mount_Bracket_Drawing.pdf (S轴伺服安装座零件图)
8. DRW-08_Short_Yoke_Drawing.pdf (串联短转架零件图)
9. DRW-09_Fin_Clamp_and_Blades_Drawing.pdf (鳍片根部双夹板与 F-S/F-M/F-L 三种鳍片孔位零件图)
10. DRW-10_T200_Mount_Bracket_Drawing.pdf (中央 T200 安装座零件图)
11. DRW-11_Enclosure_Mount_Cradle_Drawing.pdf (水密电子舱安装结构与开盖维护空间图)
12. DRW-12_Ballast_Rail_Drawing.pdf (下部多孔可调配重导轨零件图)
13. DRW-13_Landing_Skid_Drawing.pdf (底部防触地脚架零件图)
以及合并版《SRDP_Complete_Engineering_Drawings_Book_V2.pdf》与高清 PNG 预览图。
"""
import os
import math
from pathlib import Path
from typing import List, Dict, Any, Tuple
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.collections import PolyCollection
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import matplotlib.font_manager as fm
from matplotlib.backends.backend_pdf import PdfPages
from .component_library import SolidPart


def _configure_cjk_font():
    cjk_candidates = [
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc",
        "C:/Windows/Fonts/msyh.ttc",
        "C:/Windows/Fonts/simhei.ttf",
    ]
    for fp in cjk_candidates:
        if os.path.isfile(fp):
            fm.fontManager.addfont(fp)
            prop = fm.FontProperties(fname=fp)
            plt.rcParams["font.sans-serif"] = [prop.get_name(), "DejaVu Sans"]
            break
    else:
        plt.rcParams["font.sans-serif"] = ["Droid Sans Fallback", "DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False


_configure_cjk_font()


def _draw_standard_border_and_title_block(fig, meta: Dict[str, str]):
    """在 A3 横向图幅上绘制国标/机械工程图外框、基准坐标提示与右下角工程标题栏 + 左下角技术要求。"""
    ax_bg = fig.add_axes([0.0, 0.0, 1.0, 1.0], frameon=False)
    ax_bg.set_xlim(0, 420)
    ax_bg.set_ylim(0, 297)
    ax_bg.axis("off")

    # 外图框 (留边 10mm) 与内图框 (粗实线)
    ax_bg.add_patch(patches.Rectangle((8, 8), 404, 281, fill=False, edgecolor="#1B365D", linewidth=0.8))
    ax_bg.add_patch(patches.Rectangle((12, 12), 396, 273, fill=False, edgecolor="#0F172A", linewidth=1.8))

    # 顶部横幅标识
    ax_bg.add_patch(patches.Rectangle((12, 271), 396, 14, facecolor="#1B365D", edgecolor="#0F172A", linewidth=1.2))
    ax_bg.text(
        18, 278,
        f"SRDP 四鳍仿生水下机器人工程图 V2.0  |  {meta['drw_no']} : {meta['title_cn']}",
        color="white", fontsize=10.5, fontweight="bold", va="center"
    )
    ax_bg.text(
        402, 278,
        f"右手系:+X前+Y右+Z下 | 状态:{meta['credibility']}",
        color="#FCD34D", fontsize=8.8, fontweight="bold", va="center", ha="right"
    )

    # 左下角技术要求与工艺规范区 (X: 14..232, Y: 14..64)
    ax_bg.add_patch(patches.Rectangle((14, 14), 218, 50, facecolor="#F8FAFC", edgecolor="#64748B", linewidth=1.0))
    ax_bg.text(18, 58, "【技术要求与制造工艺规范 (Technical & Manufacturing Notes)】", fontsize=9, fontweight="bold", color="#1E293B")
    notes = meta.get("tech_notes", [])
    for idx, line in enumerate(notes[:5]):
        color = "#B91C1C" if ("待确认" in line or "PENDING" in line or "严禁" in line) else "#334155"
        ax_bg.text(18, 49 - idx * 8.2, f"{idx+1}. {line}", fontsize=8.0, color=color)

    # 右下角标准机械工程图标题栏 (X: 236..406, Y: 14..64)
    ax_bg.add_patch(patches.Rectangle((236, 14), 170, 50, facecolor="#F1F5F9", edgecolor="#0F172A", linewidth=1.4))
    # 分割横线
    for y_line in (24, 34, 44, 54):
        ax_bg.plot([236, 406], [y_line, y_line], color="#334155", linewidth=0.8)
    # 分割竖线
    ax_bg.plot([272, 272], [14, 64], color="#334155", linewidth=0.8)
    ax_bg.plot([332, 332], [14, 54], color="#334155", linewidth=0.8)
    ax_bg.plot([362, 362], [14, 54], color="#334155", linewidth=0.8)

    rows_tb = [
        (59, "图样名称", meta["title_cn"], "", ""),
        (49, "零件编号", meta["part_id"], "图样编号", meta["drw_no"]),
        (39, "材料牌号", meta["material"], "板厚/规格", meta["thickness"]),
        (29, "未注公差", meta["tolerance"], "表面处理", meta["finish"]),
        (19, "紧固件规格", meta["fasteners"], "版本/比例", f"{meta['version']} / {meta['scale']}"),
    ]
    for y_c, k1, v1, k2, v2 in rows_tb:
        ax_bg.text(254, y_c, k1, fontsize=7.2, fontweight="bold", ha="center", va="center", color="#1E293B")
        if k2:
            ax_bg.text(302, y_c, v1, fontsize=6.6, ha="center", va="center", color="#0F172A")
            ax_bg.text(347, y_c, k2, fontsize=7.2, fontweight="bold", ha="center", va="center", color="#1E293B")
            ax_bg.text(384, y_c, v2, fontsize=6.6, ha="center", va="center", color="#B91C1C" if "PENDING" in v2 else "#0F172A")
        else:
            ax_bg.text(339, y_c, v1, fontsize=8.5, fontweight="bold", ha="center", va="center", color="#1B365D")


def _draw_dim_arrow(ax, p1: Tuple[float, float], p2: Tuple[float, float], text: str,
                    offset: Tuple[float, float] = (0.0, 0.0), color: str = "#0F172A", fontsize: float = 8.0):
    """在 2D 工程视图上绘制带双向尺寸箭头与引出线的标准尺寸标注。"""
    x1, y1 = p1[0] + offset[0], p1[1] + offset[1]
    x2, y2 = p2[0] + offset[0], p2[1] + offset[1]
    # 尺寸引出线
    if abs(offset[0]) > 1e-3 or abs(offset[1]) > 1e-3:
        ax.plot([p1[0], x1], [p1[1], y1], color=color, linewidth=0.6, linestyle=":")
        ax.plot([p2[0], x2], [p2[1], y2], color=color, linewidth=0.6, linestyle=":")
    ax.annotate(
        "", xy=(x1, y1), xytext=(x2, y2),
        arrowprops=dict(arrowstyle="<->", color=color, lw=0.9, shrinkA=0, shrinkB=0)
    )
    mx, my = 0.5 * (x1 + x2), 0.5 * (y1 + y2)
    ax.text(
        mx, my, text, color=color, fontsize=fontsize, fontweight="bold",
        ha="center", va="center",
        bbox=dict(boxstyle="round,pad=0.18", facecolor="white", edgecolor=color, lw=0.5, alpha=0.92)
    )


def _plot_parts_ortho_2d(ax, parts: List[SolidPart], plane: str = "XY", title: str = "",
                         show_sweep_circles: bool = False):
    """将三维零件组投影到指定正交平面 (XY=俯视图, XZ=前/侧视图, YZ=左/右视图)，显式设置完整视口边界。"""
    idx_map = {"XY": (0, 1), "XZ": (0, 2), "YZ": (1, 2)}
    axis_labels = {
        "XY": ("X 机体向前 (mm)", "Y 机体向右 (mm)"),
        "XZ": ("X 机体向前 (mm)", "Z 机体向下 (mm)"),
        "YZ": ("Y 机体向右 (mm)", "Z 机体向下 (mm)"),
    }
    ix, iy = idx_map[plane]
    min_u, min_v = 1e9, 1e9
    max_u, max_v = -1e9, -1e9

    for p in parts:
        vw = p.get_world_vertices()
        bmin, bmax = vw.min(axis=0), vw.max(axis=0)
        x0, y0 = float(bmin[ix]), float(bmin[iy])
        x1, y1 = float(bmax[ix]), float(bmax[iy])
        min_u, min_v = min(min_u, x0), min(min_v, y0)
        max_u, max_v = max(max_u, x1), max(max_v, y1)
        w = max(1.0, x1 - x0)
        h = max(1.0, y1 - y0)
        ls = "--" if p.is_envelope_only else "-"
        alpha = 0.28 if p.is_envelope_only else 0.78
        rect = patches.Rectangle((x0, y0), w, h, facecolor=p.color_rgb, edgecolor="#0F172A",
                                 linewidth=0.75, linestyle=ls, alpha=alpha)
        ax.add_patch(rect)

    # 坐标轴十字基准线
    ax.axhline(0, color="#DC2626", lw=0.7, ls="-.")
    ax.axvline(0, color="#DC2626", lw=0.7, ls="-.")

    if show_sweep_circles and plane == "XY":
        c_t200 = patches.Circle((0, 0), 50.0, fill=False, edgecolor="#0284C7", lw=1.5, ls="--")
        ax.add_patch(c_t200)
        for cx, cy in [(220, 0), (-220, 0), (0, -200), (0, 200)]:
            sw = patches.Circle((cx, cy), 145.0, fill=False, edgecolor="#EA580C", lw=1.0, ls=":")
            ax.add_patch(sw)
        min_u, max_u = min(min_u, -400.0), max(max_u, 400.0)
        min_v, max_v = min(min_v, -380.0), max(max_v, 380.0)

    pad_u = max((max_u - min_u) * 0.22, 35.0)
    pad_v = max((max_v - min_v) * 0.25, 35.0)
    ax.set_xlim(min_u - pad_u, max_u + pad_u)
    ax.set_ylim(min_v - pad_v, max_v + pad_v)
    ax.set_aspect("equal")
    ax.grid(True, linestyle=":", linewidth=0.5, color="#CBD5E1")
    ax.set_xlabel(axis_labels[plane][0], fontsize=7.8)
    ax.set_ylabel(axis_labels[plane][1], fontsize=7.8)
    ax.tick_params(labelsize=7.5)
    ax.set_title(title, fontsize=9.2, fontweight="bold", color="#0F172A", pad=5)


def _plot_parts_3d_iso(ax3d, parts: List[SolidPart], title: str = "", elev: float = 26.0, azim: float = -42.0):
    """在 3D 轴上绘制整机或单模块的三维实体三角面片网格。"""
    for p in parts:
        vw = p.get_world_vertices()
        # 在保持 Z 向下坐标系的同时，渲染时将 Z 取反以使艇顶(-Z)在视觉上方、脚架(+Z)在视觉下方
        vw_plot = vw.copy()
        vw_plot[:, 2] = -vw_plot[:, 2]
        tris = [vw_plot[f] for f in p.faces]
        alpha = 0.28 if p.is_envelope_only else (0.55 if p.material_code == "ACRYLIC_PMMA" else 0.88)
        poly = Poly3DCollection(tris, facecolors=p.color_rgb, edgecolors="#1E293B", linewidths=0.25, alpha=alpha)
        ax3d.add_collection3d(poly)

    all_v = np.vstack([p.get_world_vertices() for p in parts])
    bmin, bmax = all_v.min(axis=0), all_v.max(axis=0)
    span = max(float(np.max(bmax - bmin)) * 0.55, 80.0)
    mid = 0.5 * (bmin + bmax)
    ax3d.set_xlim(mid[0] - span, mid[0] + span)
    ax3d.set_ylim(mid[1] - span, mid[1] + span)
    ax3d.set_zlim(-mid[2] - span * 0.65, -mid[2] + span * 0.65)
    ax3d.view_init(elev=elev, azim=azim)
    ax3d.set_xlabel("X 前 (+mm)", fontsize=8)
    ax3d.set_ylabel("Y 右 (+mm)", fontsize=8)
    ax3d.set_zlabel("-Z 高度 (mm)", fontsize=8)
    ax3d.set_title(title, fontsize=9.5, fontweight="bold", color="#0F172A")


def _plot_2d_part_detail_with_dimensions(ax, part: SolidPart, title: str):
    """绘制单个加工零件的 2D 轮廓、基准线、所有通孔/沉孔/盲孔圆及精确尺寸与孔距标注。"""
    outline = part.outline_2d
    if not outline:
        bmin, bmax = part.vertices_local.min(axis=0), part.vertices_local.max(axis=0)
        outline = [(bmin[0], bmin[1]), (bmax[0], bmin[1]), (bmax[0], bmax[1]), (bmin[0], bmax[1])]

    poly_pts = np.array(outline, dtype=float)
    patch = patches.Polygon(poly_pts, closed=True, facecolor="#E2E8F0", edgecolor="#0F172A", linewidth=1.8, alpha=0.85)
    ax.add_patch(patch)

    # 基准线 A / B
    ax.axhline(0, color="#DC2626", lw=0.8, ls="-.")
    ax.axvline(0, color="#DC2626", lw=0.8, ls="-.")

    # 绘制孔位与引出说明
    for idx, h in enumerate(part.holes_2d):
        clr = "#D97706" if h.is_uncertain else "#0284C7"
        ls = "--" if h.is_uncertain else "-"
        c = patches.Circle((h.x_mm, h.y_mm), h.diameter_mm / 2.0, facecolor="white", edgecolor=clr, lw=1.3, linestyle=ls)
        ax.add_patch(c)
        # 十字孔心
        r_cross = max(h.diameter_mm * 0.75, 2.5)
        ax.plot([h.x_mm - r_cross, h.x_mm + r_cross], [h.y_mm, h.y_mm], color=clr, lw=0.6)
        ax.plot([h.x_mm, h.x_mm], [h.y_mm - r_cross, h.y_mm + r_cross], color=clr, lw=0.6)

        if idx == 0 or (idx < 4 and h.diameter_mm >= 4.0):
            tag = f"{h.spec_label}" + (" [待确认]" if h.is_uncertain else "")
            ax.annotate(
                tag,
                xy=(h.x_mm, h.y_mm),
                xytext=(h.x_mm + 4.0, h.y_mm + 11.0 + (idx % 3) * 8.0),
                fontsize=7.5,
                color="#B91C1C" if h.is_uncertain else "#0F172A",
                fontweight="bold",
                arrowprops=dict(arrowstyle="->", color=clr, lw=0.8),
                bbox=dict(boxstyle="round,pad=0.2", facecolor="#FFFBEB" if h.is_uncertain else "#F0F9FF", edgecolor=clr, lw=0.6)
            )

    # 自动标注总长与总宽
    xmin, ymin = poly_pts.min(axis=0)
    xmax, ymax = poly_pts.max(axis=0)
    w_span = xmax - xmin
    h_span = ymax - ymin
    margin_x = max(w_span * 0.28, 22.0)
    margin_y = max(h_span * 0.32, 22.0)

    _draw_dim_arrow(ax, (xmin, ymin), (xmax, ymin), f"{w_span:.1f} ±0.2 mm", offset=(0.0, -margin_y * 0.45), color="#1E293B")
    _draw_dim_arrow(ax, (xmax, ymin), (xmax, ymax), f"{h_span:.1f} ±0.2 mm", offset=(margin_x * 0.45, 0.0), color="#1E293B")

    # 若有对称孔位，标注孔中心距
    if len(part.holes_2d) >= 2:
        h0, h1 = part.holes_2d[0], part.holes_2d[1]
        dx = abs(h1.x_mm - h0.x_mm)
        dy = abs(h1.y_mm - h0.y_mm)
        if dx > 2.0:
            lbl = f"孔距 {dx:.1f} mm" + (" [PENDING]" if h0.is_uncertain else " (±0.1)")
            _draw_dim_arrow(ax, (h0.x_mm, ymax), (h1.x_mm, ymax), lbl, offset=(0.0, margin_y * 0.35),
                            color="#B91C1C" if h0.is_uncertain else "#0369A1")
        elif dy > 2.0:
            lbl = f"孔距 {dy:.1f} mm" + (" [PENDING]" if h0.is_uncertain else " (±0.1)")
            _draw_dim_arrow(ax, (xmin, h0.y_mm), (xmin, h1.y_mm), lbl, offset=(-margin_x * 0.38, 0.0),
                            color="#B91C1C" if h0.is_uncertain else "#0369A1")

    ax.set_xlim(xmin - margin_x, xmax + margin_x)
    ax.set_ylim(ymin - margin_y, ymax + margin_y)
    ax.set_aspect("equal")
    ax.grid(True, linestyle=":", linewidth=0.5, color="#CBD5E1")
    ax.set_title(title, fontsize=9.5, fontweight="bold", color="#0F172A", pad=6)
    ax.set_xlabel("X 基准坐标 (mm)", fontsize=8)
    ax.set_ylabel("Y 基准坐标 (mm)", fontsize=8)


class DrawingGenerator:
    """自动生成全部 13 张机械工程图 PDF + 预览 PNG + 合并工程图册。"""

    def __init__(self, asm, mass_report: Dict[str, Any], collision_report: Dict[str, Any]):
        self.asm = asm
        self.pm = asm.pm
        self.mass_report = mass_report
        self.collision_report = collision_report
        self.root = self.pm.project_root
        self.drw_dir = self.root / "output" / "drawings"
        self.prev_dir = self.root / "output" / "previews"
        self.drw_dir.mkdir(parents=True, exist_ok=True)
        self.prev_dir.mkdir(parents=True, exist_ok=True)

    def generate_all_13_drawings(self, full_parts: List[SolidPart],
                                 single_fin_parts: List[SolidPart],
                                 fin_variants: Dict[str, SolidPart]) -> Dict[str, Any]:
        part_by_id: Dict[str, SolidPart] = {}
        for p in full_parts:
            if p.part_id not in part_by_id:
                part_by_id[p.part_id] = p
        for vc, vp in fin_variants.items():
            part_by_id[vp.part_id] = vp

        drawing_specs = [
            {
                "drw_no": "DRW-01",
                "filename": "DRW-01_Full_Robot_Assembly.pdf",
                "title_cn": "四鳍仿生水下机器人整机总装图",
                "title_en": "Full Robot General Assembly Drawing",
                "part_id": "ASSY-SRDP-FULL-V2",
                "material": "6061-T6铝合金 + PETG + 钛合金/316SS",
                "thickness": "整机展开 748×708×240 mm",
                "tolerance": "GB/T 1804-m (装配线性 ±0.5mm)",
                "finish": "铝件硬质阳极氧化 / 不锈钢钝化",
                "fasteners": "M3/M4/M5 A4-80(316SS) 内六角螺栓+防松螺母",
                "credibility": "B/C级混合 [部分接口PENDING]",
                "version": "V2.0",
                "scale": "1:5",
                "mode": "ASSEMBLY_OVERVIEW",
                "tech_notes": [
                    "统一机体坐标系：原点 O 位于中央垂推轴线与中层框板交点，+X 向前，+Y 向右，+Z 向下 (右手系)。",
                    "水平推进完全由 L(左)、R(右)、F(前)、B(后) 四套双自由度串联仿生鳍产生；唯一螺旋桨 T200 严格竖直布置。",
                    "左右双水密电子舱对称布置于 Y=±110mm，中央 Ø116mm 垂推进出水通道及上视双ID标靶视线严禁遮挡。",
                    "所有外部 Cobalt 3针连接器必须干燥清洁插合锁紧，主系缆与回收绳拉力固定在框架吊耳，严禁拉扯穿舱件。",
                    "[PENDING] 伺服安装孔距(UNC-001)与水密舱实际管长(UNC-004)属设计占位参数，须到货实测复核后冻结。",
                ],
            },
            {
                "drw_no": "DRW-02",
                "filename": "DRW-02_Full_Robot_Three_Views.pdf",
                "title_cn": "整机标准正交三视图 (俯视/主视/左视)",
                "title_en": "Full Robot Standard Orthographic 3-View Drawing",
                "part_id": "ASSY-SRDP-3VIEW",
                "material": "多材料总成 (见整机BOM)",
                "thickness": "核心框架 440×400×240 mm",
                "tolerance": "对称度 ≤0.5mm, 垂直度 ≤0.3°",
                "finish": "全浸水防腐绝缘处理",
                "fasteners": "全艇 316 不锈钢紧固件",
                "credibility": "B/C级设计样机 [PENDING]",
                "version": "V2.0",
                "scale": "1:5",
                "mode": "THREE_VIEWS",
                "tech_notes": [
                    "框架核心力臂初始设计值：前后鳍力臂 a = 220.0 mm (间距 2a=440mm)，左右鳍力臂 b = 200.0 mm (间距 2b=400mm)。",
                    "底部防触地脚架接地平面 Z = +135.0 mm，确保鳍片竖直向下(P=-45°)及 T200 导流罩离地净空均 ≥45.0 mm。",
                    "上部闭孔聚氨酯浮材中心 Z = -90.0 mm，下部配重块中心 Z = +94.0 mm，浮心高于重心 BG_z > 32 mm。",
                    "[PENDING] 有效水动力作用点力臂 a, b 须在整机下水后按开环响应校正 (实施总册 P7/P40)。",
                ],
            },
            {
                "drw_no": "DRW-03",
                "filename": "DRW-03_Full_Robot_Isometric.pdf",
                "title_cn": "整机三维等轴测与运动扫掠包络图",
                "title_en": "Full Robot Isometric & Kinematic Sweep Envelope Drawing",
                "part_id": "ASSY-SRDP-ISO",
                "material": "多材料总成 + 运动包络体",
                "thickness": "最大展开跨度 860×820×270 mm",
                "tolerance": "静态/动态最小安全间隙 ≥15mm",
                "finish": "按各子零件规定",
                "fasteners": "见子装配图",
                "credibility": "运动学已验证 PASS",
                "version": "V2.0",
                "scale": "NTS",
                "mode": "ISOMETRIC_AND_GAIT",
                "tech_notes": [
                    "四段平滑插值周期：A工作划水(S:-A→+A, P=-45°) → B原位羽化(P:-45°→+45°) → C低阻回程 → D原位恢复。",
                    "插值轨迹采用 s(τ)=3τ²−2τ³，段首段尾角速度严格为零，严禁阶跃跳角导致电流冲击与机构碰撞。",
                    "起步调试参数：S轴半幅 A=10°~15°，周期 T=4~6s，羽化过渡 0.7~1.0s，必须从 F-S 小鳍(80×40×0.5)开始。",
                    "四鳍扫掠扇区、P轴活动线缆环与中央垂推进出水通道互不相交 (全角度检查 9 PASS / 1 WARNING)。",
                ],
            },
            {
                "drw_no": "DRW-04",
                "filename": "DRW-04_Single_Fin_Module_Assembly.pdf",
                "title_cn": "双自由度串联仿生鳍单模块装配图",
                "title_en": "2-DOF Serial Bionic Fin Module Assembly Drawing",
                "part_id": "ASSY-FIN-MOD-2DOF",
                "material": "SER-2010×2 + SER-0011×2 + PETG支架/鳍片",
                "thickness": "单模块径向伸出 154 mm (配F-S鳍)",
                "tolerance": "S轴与P轴正交度 ≤0.2°",
                "finish": "钛毂与铝件接触处须阳极氧化或加绝缘垫",
                "fasteners": "8×M3×45 穿透螺栓 + 2×M3×16 鳍夹螺栓",
                "credibility": "B级重建 + 待实测孔位 [PENDING]",
                "version": "V2.0",
                "scale": "1:2",
                "mode": "SINGLE_FIN_ASSEMBLY",
                "tech_notes": [
                    "严格采用串联机构：S轴机壳固定于框架，S轴输出端带动短转架，P轴机壳固定于短转架，P轴输出端带动鳍片。",
                    "严禁将两台伺服同时固定在框架上！严禁在 SER-2010 聚甲醛密封壳体上擅自钻孔或攻丝！",
                    "P轴机械零偏布置为：指令 -45° 时鳍面竖直(工作推水)，指令 +45° 时鳍面水平(低阻回程)，距 ±70° 限位各留 25°。",
                    "P轴随动电缆在 Cobalt 插头后必须保留 R≥35mm 受控弯曲环并固定远端应力释放点，禁止绕轴缠圈。",
                    "[PENDING] 首批先采购 2 台 SER-2010 与 2 个 SER-0011 完成单鳍台架测力门控(M1/M2/M3)后再复制其余 3 套。",
                ],
            },
            {
                "drw_no": "DRW-05",
                "filename": "DRW-05_Single_Fin_Exploded_View.pdf",
                "title_cn": "单鳍双自由度模块爆炸图与装配序列图",
                "title_en": "Single Fin Module Exploded View & Assembly Sequence",
                "part_id": "ASSY-FIN-EXPLODED",
                "material": "见单鳍BOM明细",
                "thickness": "共 9 个层级组件",
                "tolerance": "按装配检查单工序执行",
                "finish": "螺纹紧固画见证线",
                "fasteners": "M3/M4 316SS 穿透螺栓 + 尼龙防松螺母 + 大垫圈",
                "credibility": "装配拓扑已冻结",
                "version": "V2.0",
                "scale": "1:2.5",
                "mode": "SINGLE_FIN_EXPLODED",
                "tech_notes": [
                    "总装顺序(总册P19)：①固定S机壳 → ②装S毂、短转架与P机壳 → ③装P毂与空夹板校验零位 → ④最后装最小试鳍 F-S。",
                    "轴毂见证线：所有 SER-0011 钛合金输出毂与 6mm D型轴锁紧后必须用记号笔画对位见证线，每次出水检查是否滑移。",
                    "断电状态下严禁强行反向拧动伺服输出轴齿轮；初次上电必须在拆掉鳍叶状态下用小幅指令检查正反方向。",
                ],
            },
            {
                "drw_no": "DRW-06",
                "filename": "DRW-06_Frame_Main_Plate_Drawing.pdf",
                "title_cn": "主承力开放式十字框板与连接桥板零件图",
                "title_en": "Open Cross Main Frame Plate & Bridge Part Drawing",
                "part_id": "MFG-FRM-MAIN-PLATE",
                "material": "6061-T6 铝合金板 (或高密度 HDPE 板)",
                "thickness": "板厚 5.0 ±0.1 mm",
                "tolerance": "GB/T 1804-m, 孔位 ±0.15 mm",
                "finish": "喷砂本色/黑色硬质阳极氧化 (绝缘层≥25μm)",
                "fasteners": "16×M4×16 (四鳍座) + 8×M5×16 (隔柱)",
                "credibility": "自制件 (孔位随力臂参数联动)",
                "version": "V2.0",
                "scale": "1:3",
                "mode": "PART_DETAIL",
                "target_part_id": "MFG-FRM-MAIN-PLATE",
                "tech_notes": [
                    "中央 Ø116.0 mm 大通孔为 T200 垂向推进器专用开放水流通道，加工后内外切边全部倒钝 C0.5 去毛刺。",
                    "若采用 6061-T6 铝板，必须做完整阳极氧化绝缘处理并处理切边，严禁未处理裸铝接触钛合金毂引发电偶腐蚀(总册P11)。",
                    "四端鳍模块基座安装孔组距中心基准 O 分别为 X=±202.0 mm、Y=±182.0 mm (对应输出轴力臂 a=220, b=200 mm)。",
                    "[PENDING] 在首批单鳍运动包络与成品水密舱实装排布确认前，请先做激光切割亚克力/木板样件核对。",
                ],
            },
            {
                "drw_no": "DRW-07",
                "filename": "DRW-07_Servo_Mount_Bracket_Drawing.pdf",
                "title_cn": "S轴水下伺服框架固定座零件图",
                "title_en": "S-Axis Underwater Servo Mount Bracket Drawing",
                "part_id": "MFG-BRK-S-MOUNT",
                "material": "PETG 工程打印件 (首样) / 6061-T6 (外协)",
                "thickness": "主承力壁厚 6.0 mm",
                "tolerance": "GB/T 1804-m, 两夹耳内距 32.2 +0.2/-0 mm",
                "finish": "0.2mm层高, ≥5道外壁, 孔座局部100%实心",
                "fasteners": "4×M3×45 侧面穿透螺栓 + 4×M4×16 框架螺栓",
                "credibility": "侧面孔径已知Ø3.2 / 孔距[PENDING]",
                "version": "V2.0",
                "scale": "1:1",
                "mode": "PART_DETAIL",
                "target_part_id": "MFG-BRK-S-MOUNT",
                "tech_notes": [
                    "利用 SER-2010 侧面既有 4×Ø3.2mm 通孔，采用长度 >32mm 的 M3×45 不锈钢螺栓配大垫圈与防松螺母穿透夹固。",
                    "PETG 打印工艺要求(总册P11)：0.2mm层高、至少5道外壁、螺栓孔座局部实心、带三角加强筋；层向与主受拉弯曲方向平行。",
                    "严禁仅靠 3D 打印塑料螺纹承受水下往复交变载荷！首次受载后若发现层间开裂或孔座压溃，立即改外协板件。",
                    "[PENDING] UNC-001: 侧面 4×Ø3.2mm 孔的精确纵向/垂向间距须按 Blue Trail 官方 STEP 与到货卡尺实测复核后钻孔。",
                ],
            },
            {
                "drw_no": "DRW-08",
                "filename": "DRW-08_Short_Yoke_Drawing.pdf",
                "title_cn": "双自由度串联短转架零件图",
                "title_en": "2-DOF Serial Short Rigid Yoke Part Drawing",
                "part_id": "MFG-YOKE-SHORT",
                "material": "PETG 工程打印件 (首样) / 两片铝板+隔柱",
                "thickness": "主承力板厚 6.0 mm",
                "tolerance": "S轴端面与P轴安装槽垂直度 ≤0.15 mm",
                "finish": "去支撑毛刺，边缘 R1.0 圆滑过渡",
                "fasteners": "4×M3×10 (接S毂) + 4×M3×45 (夹紧P伺服)",
                "credibility": "含待实测接口 [PENDING UNC-001/002]",
                "version": "V2.0",
                "scale": "1:1",
                "mode": "PART_DETAIL",
                "target_part_id": "MFG-YOKE-SHORT",
                "tech_notes": [
                    "转架设计遵循“短而宽、刚度合理”原则(总册P9)：总悬臂中心距控制在 38mm，最大限度减小 S 轴承受的悬臂弯矩。",
                    "若需增加额外外支撑轴承，必须保证与 S 轴严格同轴；严禁随手增加偏轴轴承造成两个中心争夺同一根轴！",
                    "[PENDING] UNC-002: 根部连接 SER-0011 钛合金输出毂的 4×Ø3.2 孔分布圆直径(暂定PCD 16mm)须到货实测确认。",
                    "[PENDING] UNC-001: 两侧翼夹持 P 轴伺服的 4×Ø3.2 通孔间距须与 SER-2010 实物卡尺测量交叉核对。",
                ],
            },
            {
                "drw_no": "DRW-09",
                "filename": "DRW-09_Fin_Clamp_and_Blades_Drawing.pdf",
                "title_cn": "可拆卸鳍片根部双夹板与三种试验鳍片孔位图",
                "title_en": "Removable Fin Root Clamp & F-S/F-M/F-L Fin Blades Drawing",
                "part_id": "MFG-FIN-CLAMP & F-S/M/L",
                "material": "夹板: PETG打印件 | 鳍片: VIVAK PETG 实心片材",
                "thickness": "夹板 2×4.0 mm | 鳍片 0.5 mm (0.508mm可用)",
                "tolerance": "根部夹持区 20×40 mm, 孔位 ±0.1 mm",
                "finish": "夹板内缘 R1.0 倒钝 | 鳍片四角 R5 圆角细磨去毛刺",
                "fasteners": "2×M3×14 穿透螺栓+大垫圈+防松螺母 (夹鳍根)",
                "credibility": "根部夹持孔位已明确 / 鳍面积为试验起点 [PENDING]",
                "version": "V2.0",
                "scale": "1:1",
                "mode": "FIN_AND_CLAMP_DETAIL",
                "target_part_id": "MFG-FIN-CLAMP",
                "tech_notes": [
                    "两片圆角夹板完整覆盖鳍片根部 20×40 mm 区域，用两颗 M3 穿透螺栓均匀夹持；严禁螺钉单点直接压在柔性鳍边上(总册P10)。",
                    "鳍片根部安装孔确定参数：2×Ø3.2 mm 通孔，孔中心距根部端边 10.0 mm，距两侧边各 10.0 mm (两孔中心距 20.0 mm)。",
                    "夹板与鳍片接触的前缘必须倒钝 R1.0，防止硬直角在往复划水时反复切割鳍根造成白化或疲劳断裂。",
                    "[PENDING] 三种试片 F-S(80×40×0.5)、F-M(110×40×0.5)、F-L(140×40×0.5) 均为设计试验起点，必须先用 F-S 小片下水！",
                ],
            },
            {
                "drw_no": "DRW-10",
                "filename": "DRW-10_T200_Mount_Bracket_Drawing.pdf",
                "title_cn": "中央 T200 垂向推进器安装座与护网环零件图",
                "title_en": "Central T200 Vertical Thruster Mount Bracket Drawing",
                "part_id": "MFG-T200-BRACKET",
                "material": "6061-T6 铝合金 (硬质阳极氧化)",
                "thickness": "板厚 6.0 ±0.1 mm",
                "tolerance": "4×M3 孔距 19.0 ±0.1 mm (官方已知确定值)",
                "finish": "硬质阳极氧化 + 边缘去毛刺",
                "fasteners": "4×M3×10 (拧紧扭矩 0.5-1.3 N·m) + 1×M6×12",
                "credibility": "B级 (官方安装接口尺寸已确认)",
                "version": "V2.0",
                "scale": "1.5:1",
                "mode": "PART_DETAIL",
                "target_part_id": "MFG-T200-BRACKET",
                "tech_notes": [
                    "安装孔严格依據 Blue Robotics T200 官方规格：4×Ø3.2 通孔 (匹配 T200 底座 M3×0.5 深6mm 螺孔，间距 19.0×19.0 mm)。",
                    "中心 Ø6.4 mm 通孔匹配 T200 底座 M6×1.0 (深8mm) 中心紧固孔；螺钉旋入深度严禁超过 6mm(M3) / 8mm(M6) 以免顶坏定子。",
                    "T200 推进器严禁在空气中干转超过 10 s；装上进出口防护环后，必须在水中重新标定低输出 PWM—推力死区曲线(总册P18/P32)。",
                ],
            },
            {
                "drw_no": "DRW-11",
                "filename": "DRW-11_Enclosure_Mount_Cradle_Drawing.pdf",
                "title_cn": "成品水密电子舱抱箍安装座与维护空间布置图",
                "title_en": "Watertight Enclosure Clamp Cradle & Maintenance Space Drawing",
                "part_id": "MFG-ENC-CRADLE",
                "material": "PETG 工程打印件 + 2mm EPDM 橡胶防滑内衬",
                "thickness": "抱箍宽度 24.0 mm, 壁厚 8.0 mm",
                "tolerance": "内孔 Ø114.0 +0.5/-0 mm (配橡胶垫抱紧)",
                "finish": "去毛刺，螺栓孔座实心加强",
                "fasteners": "4×M4×30 抱箍锁紧螺栓 + 4×M4×16 框架固定螺栓",
                "credibility": "C级参数化占位 [PENDING UNC-004]",
                "version": "V2.0",
                "scale": "1:1.5",
                "mode": "PART_DETAIL",
                "target_part_id": "MFG-ENC-CRADLE",
                "tech_notes": [
                    "必须优先采用有深度额定值、标准端口、O圈及泄压组件的商用成品水密舱，严禁把自制普通打印盒冒充水下承压舱(总册P17)！",
                    "未经结构设计与厂家允许，严禁在亚克力/铝合金承压管体或端盖上自行钻削穿舱孔；严禁用酒精擦拭亚克力舱管。",
                    "框架前后已预留 ≥58 mm 端盖开启空间与 Cobalt/WetLink 线缆插拔弯曲空间。",
                    "[PENDING] UNC-004: 选舱前必须先将 STM32、4路6V DC/DC、12V DC/DC、K1接触器按 1:1 纸板排布确认尺寸后再锁定抱箍内径。",
                ],
            },
            {
                "drw_no": "DRW-12",
                "filename": "DRW-12_Ballast_Rail_Drawing.pdf",
                "title_cn": "下部多孔可调配重导轨与配重块零件图",
                "title_en": "Lower Slotted Adjustable Ballast Rail & Weight Drawing",
                "part_id": "MFG-BALLAST-RAIL",
                "material": "导轨: 6061-T6铝合金 | 配重块: 316不锈钢",
                "thickness": "导轨板厚 5.0 mm (长 300×宽 24 mm)",
                "tolerance": "调节孔距 30.0 ±0.15 mm",
                "finish": "阳极氧化防腐处理",
                "fasteners": "4×M5×16 (固定导轨) + 8×M4×20 (锁紧配重块)",
                "credibility": "自制可调结构 (配重位置待水试配平)",
                "version": "V2.0",
                "scale": "1:1.5",
                "mode": "PART_DETAIL",
                "target_part_id": "MFG-BALLAST-RAIL",
                "tech_notes": [
                    "配重导轨对称安装于下部横梁低处(Z=+85mm, Y=±110mm)，提供 X∈[-120, +120] mm 分度调节孔位。",
                    "配重块必须通过双 M4 防松螺栓可靠锁紧在导轨上，严禁在电子舱内或框架上放置未固定的零散螺母/铅块(总册P18)。",
                    "[PENDING] UNC-006: 按总册 P18 逐步配平流程，在全浸没断电状态下每次只移动一个位置或一份质量，达成略正浮力与水平姿态。",
                ],
            },
            {
                "drw_no": "DRW-13",
                "filename": "DRW-13_Landing_Skid_Drawing.pdf",
                "title_cn": "底部防触地承重脚架零件图",
                "title_en": "Bottom Protective Landing Skid Part Drawing",
                "part_id": "MFG-SKID-ASSY",
                "material": "6061-T6 铝合金板 + 底部 EVA 防滑护垫",
                "thickness": "截面宽 14.0 mm, 立柱高 70.0 mm",
                "tolerance": "跨度 360.0 ±0.5 mm, 接地平面平行度 ≤0.3 mm",
                "finish": "阳极氧化 + 底部圆角 R5 防刮池底",
                "fasteners": "4×M5×20 316SS 内六角螺栓 + 防松螺母",
                "credibility": "自制防护件 (净空验证 PASS)",
                "version": "V2.0",
                "scale": "1:2",
                "mode": "PART_DETAIL",
                "target_part_id": "MFG-SKID-ASSY",
                "tech_notes": [
                    "脚架落地时(Z=+135.0mm)，四套仿生鳍片、全部水下接插件及中央 T200 螺旋桨均处于悬空受保护状态(最小离地净空 69.0 mm)。",
                    "岸上放置与运输时建议配合带泡棉的承托架，由底部脚架承力，严禁把整机重量压在鳍片或 Cobalt 连接器上(总册P13)。",
                ],
            },
        ]

        generated_pdfs: List[Path] = []
        generated_pngs: List[Path] = []
        book_pdf = self.drw_dir / "SRDP_Complete_Engineering_Drawings_Book_V2.pdf"
        book_pages = PdfPages(str(book_pdf))

        for spec in drawing_specs:
            fig = plt.figure(figsize=(16.53, 11.69), dpi=180)  # 标准 A3 横向 (420×297 mm 比例)
            _draw_standard_border_and_title_block(fig, spec)
            mode = spec["mode"]

            if mode == "ASSEMBLY_OVERVIEW":
                ax1 = fig.add_axes([0.05, 0.27, 0.44, 0.60])
                _plot_parts_ortho_2d(ax1, full_parts, plane="XY",
                                     title="整机俯视图 (Top View XY: 四鳍正交布局 + 双水密舱 + 中央垂推)",
                                     show_sweep_circles=True)
                _draw_dim_arrow(ax1, (-220, -250), (220, -250), "前后鳍基座间距 2a = 440.0 mm [PENDING]", color="#1B365D")
                _draw_dim_arrow(ax1, (-260, -200), (-260, 200), "左右鳍基座间距 2b = 400.0 mm [PENDING]", color="#1B365D")

                ax2 = fig.add_axes([0.52, 0.25, 0.44, 0.64], projection="3d")
                _plot_parts_3d_iso(ax2, full_parts, title="整机三维数字样机等轴测视图 (Isometric 3D Digital Mockup)")

            elif mode == "THREE_VIEWS":
                ax_top = fig.add_axes([0.05, 0.56, 0.42, 0.33])
                _plot_parts_ortho_2d(ax_top, full_parts, plane="XY", title="俯视图 (Top View: X-Y 平面)", show_sweep_circles=True)
                _draw_dim_arrow(ax_top, (-374, -280), (374, -280), "F-S鳍总展开长 748.0 mm", color="#0F172A")

                ax_front = fig.add_axes([0.05, 0.24, 0.42, 0.26])
                _plot_parts_ortho_2d(ax_front, full_parts, plane="XZ", title="主视图/侧视图 (Front/Side View: X-Z 平面, +Z向下)")
                ax_front.invert_yaxis()
                _draw_dim_arrow(ax_front, (-220, 135), (220, 135), "核心机架长 440.0 mm", offset=(0, 22), color="#0F172A")
                _draw_dim_arrow(ax_front, (260, -109), (260, 135), "总高 244.0 mm", color="#0369A1")

                ax_side = fig.add_axes([0.53, 0.26, 0.42, 0.62])
                _plot_parts_ortho_2d(ax_side, full_parts, plane="YZ", title="左/右向视图 (End View: Y-Z 平面, 双舱与中央垂推通道)")
                ax_side.invert_yaxis()
                _draw_dim_arrow(ax_side, (-110, -5), (110, -5), "双水密舱中心距 220.0 mm", offset=(0, -85), color="#1B365D")
                _draw_dim_arrow(ax_side, (-135, 135), (135, 135), "底部脚架横向跨距 270.0 mm", offset=(0, 25), color="#0F172A")

            elif mode == "ISOMETRIC_AND_GAIT":
                ax_iso1 = fig.add_axes([0.04, 0.26, 0.45, 0.62], projection="3d")
                _plot_parts_3d_iso(ax_iso1, full_parts, title="工作划水姿态 (Phase A: P=-45° 鳍面竖直迎水)", elev=28, azim=-38)

                # 生成四段周期 A/B/C/D 平滑角度与角速度曲线图
                ax_gait = fig.add_axes([0.54, 0.61, 0.41, 0.26])
                t_arr = np.linspace(0, 5.0, 200)
                s_arr, p_arr = [], []
                for tv in t_arr:
                    g = self.asm.kin.evaluate_four_phase_gait(tv)
                    s_arr.append(g["cmd_s_deg"])
                    p_arr.append(g["cmd_p_deg"])
                ax_gait.plot(t_arr, s_arr, color="#0284C7", lw=2.2, label="S轴 划桨角 (±15°)")
                ax_gait.plot(t_arr, p_arr, color="#EA580C", lw=2.2, ls="--", label="P轴 羽化角 (-45°工作/+45°回程)")
                for x_sep, ph_lbl in [(0.0, "A:工作划水"), (1.65, "B:羽化"), (2.50, "C:低阻回程"), (4.15, "D:复位")]:
                    ax_gait.axvline(x_sep, color="#64748B", lw=0.8, ls=":")
                    ax_gait.text(x_sep + 0.08, 52, ph_lbl, fontsize=7.8, fontweight="bold", color="#1E293B")
                ax_gait.set_ylim(-60, 68)
                ax_gait.set_xlabel("周期时间 t (s) [T = 5.0 s]", fontsize=8)
                ax_gait.set_ylabel("关节指令角 (deg)", fontsize=8)
                ax_gait.set_title("四段平滑插值周期轨迹 s(τ)=3τ²−2τ³ (段首段尾零速度)", fontsize=9, fontweight="bold")
                ax_gait.grid(True, ls=":", alpha=0.6)
                ax_gait.legend(loc="lower right", fontsize=7.5)

                # 渲染回程水平羽化姿态 3D 视图
                parts_rec = self.asm.build_full_robot_assembly(
                    joint_angles={"L": (15.0, 45.0), "R": (15.0, 45.0), "F": (15.0, 45.0), "B": (15.0, 45.0)},
                    fin_variant="F-L"
                )
                ax_iso2 = fig.add_axes([0.53, 0.23, 0.43, 0.29], projection="3d")
                _plot_parts_3d_iso(ax_iso2, parts_rec, title="低阻回程姿态 (Phase C: P=+45° 鳍面水平 + F-L大鳍)", elev=22, azim=35)

            elif mode == "SINGLE_FIN_ASSEMBLY":
                ax_s1 = fig.add_axes([0.05, 0.56, 0.43, 0.33])
                _plot_parts_ortho_2d(ax_s1, single_fin_parts, plane="XY", title="单鳍模块俯视图 (Top View XY: S轴 -> 短转架 -> P轴 -> 鳍片)")
                _draw_dim_arrow(ax_s1, (-40, -42), (160, -42), "单模块总长 200.0 mm (含F-S鳍片)", color="#1B365D")
                _draw_dim_arrow(ax_s1, (0, 32), (70, 32), "S轴至P轴肩部 70.0 mm", color="#0369A1")

                ax_s2 = fig.add_axes([0.05, 0.24, 0.43, 0.26])
                _plot_parts_ortho_2d(ax_s2, single_fin_parts, plane="XZ", title="单鳍模块主视图 (Side View XZ: 串联双伺服高刚度短悬臂)")
                ax_s2.invert_yaxis()

                ax_s3 = fig.add_axes([0.52, 0.25, 0.44, 0.63], projection="3d")
                _plot_parts_3d_iso(ax_s3, single_fin_parts, title="单鳍双自由度串联模块三维装配图 (含P轴动态电缆弯曲环)", elev=24, azim=-48)

            elif mode == "SINGLE_FIN_EXPLODED":
                # 构造沿径向 X 与竖直 Z 展开的单鳍爆炸视图零件列表
                from dataclasses import replace
                from .component_library import trans
                exploded_parts = []
                offsets = [
                    (-55.0, 0.0, -35.0),  # 1. S轴安装座
                    (-20.0, 0.0, 25.0),   # 2. S轴伺服
                    (0.0, 0.0, -15.0),    # 3. S轴输出毂
                    (35.0, 0.0, -5.0),    # 4. 短转架
                    (85.0, 0.0, 20.0),    # 5. P轴伺服
                    (135.0, 0.0, 0.0),    # 6. P轴输出毂
                    (175.0, 0.0, 0.0),    # 7. 鳍片双夹板
                    (230.0, 0.0, 0.0),    # 8. F-S 鳍片
                    (35.0, 0.0, -45.0),   # 9. 动态线缆环
                ]
                for idx, (sp, off) in enumerate(zip(single_fin_parts, offsets)):
                    exploded_parts.append(replace(sp, transform_world=trans(*off) @ sp.transform_world))

                ax_ex1 = fig.add_axes([0.05, 0.26, 0.46, 0.62])
                _plot_parts_ortho_2d(ax_ex1, exploded_parts, plane="XZ", title="单鳍模块爆炸装配序列侧视图 (Exploded Sequence XZ)")
                ax_ex1.invert_yaxis()
                for idx, sp in enumerate(exploded_parts, start=1):
                    c = sp.get_world_centroid()
                    ax_ex1.annotate(
                        f"({idx}) {sp.instance_id}",
                        xy=(c[0], c[2]), xytext=(c[0] - 10, c[2] - 28 if idx % 2 == 0 else c[2] + 28),
                        fontsize=7.5, fontweight="bold", color="#1B365D",
                        arrowprops=dict(arrowstyle="->", color="#DC2626", lw=0.8),
                        bbox=dict(boxstyle="round,pad=0.15", facecolor="#FEF3C7", edgecolor="#D97706", lw=0.6)
                    )

                ax_ex2 = fig.add_axes([0.53, 0.26, 0.43, 0.62], projection="3d")
                _plot_parts_3d_iso(ax_ex2, exploded_parts, title="单鳍模块三维爆炸轴测图 (3D Exploded Isometric View)", elev=25, azim=-52)

            elif mode == "FIN_AND_CLAMP_DETAIL":
                # 左半幅画鳍片双夹板 MFG-FIN-CLAMP，右半幅同时对比展示 F-S (80mm), F-M (110mm), F-L (140mm) 三种可换鳍片孔位图
                clamp_part = part_by_id["MFG-FIN-CLAMP"]
                ax_c = fig.add_axes([0.05, 0.27, 0.38, 0.60])
                _plot_2d_part_detail_with_dimensions(ax_c, clamp_part, "零件1: 可拆卸鳍片根部双夹板 (MFG-FIN-CLAMP, 2片对夹)")

                ax_f = fig.add_axes([0.53, 0.27, 0.42, 0.60])
                y_shifts = [("F-S", 55.0, "#0284C7"), ("F-M", 0.0, "#059669"), ("F-L", -55.0, "#D97706")]
                for v_code, y_sh, clr in y_shifts:
                    fp = fin_variants[v_code]
                    pts = np.array(fp.outline_2d, dtype=float)
                    pts[:, 1] += y_sh
                    ax_f.add_patch(patches.Polygon(pts, closed=True, facecolor=clr, edgecolor="#0F172A", lw=1.3, alpha=0.30))
                    # 画出 20x40 根部夹持区虚线框
                    ax_f.add_patch(patches.Rectangle((6.0, y_sh - 20.0), 20.0, 40.0, fill=False, edgecolor="#DC2626", lw=1.0, ls="--"))
                    for h in fp.holes_2d:
                        ax_f.add_patch(patches.Circle((h.x_mm, h.y_mm + y_sh), h.diameter_mm / 2.0, facecolor="white", edgecolor="#DC2626", lw=1.2))
                    tot_l = fp.dimensions_summary["total_length_mm"]
                    exp_l = fp.dimensions_summary["exposed_effective_length_mm"]
                    ax_f.text(6.0 + tot_l / 2.0, y_sh, f"{v_code}: 总长 {tot_l:.0f}×宽40×厚0.5mm (夹持20 / 外露{exp_l:.0f}mm) [试验起点]",
                              fontsize=8.0, fontweight="bold", ha="center", va="center", color="#0F172A",
                              bbox=dict(boxstyle="round,pad=0.15", facecolor="white", alpha=0.88))

                _draw_dim_arrow(ax_f, (6.0, 75.0), (26.0, 75.0), "夹持20mm", offset=(0, 7), color="#DC2626", fontsize=7.2)
                _draw_dim_arrow(ax_f, (26.0, 75.0), (86.0, 75.0), "F-S外露60mm", offset=(0, 16), color="#0284C7", fontsize=7.2)
                _draw_dim_arrow(ax_f, (6.0, -75.0), (146.0, -75.0), "F-L总长 140.0 mm [上限候选]", offset=(0, -10), color="#D97706")
                ax_f.set_xlim(-15, 168)
                ax_f.set_ylim(-95, 95)
                ax_f.set_aspect("equal")
                ax_f.grid(True, ls=":", lw=0.5, color="#CBD5E1")
                ax_f.set_title("零件2: 三种可替换 VIVAK PETG 鳍片试片孔位图 (四角R5圆角, 2×Ø3.2通孔)", fontsize=9.5, fontweight="bold")

            else:
                # 通用单零件精密二维加工图 + 右侧三维零件轴测图
                t_pid = spec["target_part_id"]
                target_p = part_by_id[t_pid]
                from dataclasses import replace
                local_p = replace(target_p, transform_world=np.eye(4, dtype=float))

                ax_2d = fig.add_axes([0.05, 0.27, 0.48, 0.60])
                _plot_2d_part_detail_with_dimensions(ax_2d, local_p, f"{spec['title_cn']} — 1:1 孔位与轮廓基准视图 (单位: mm)")

                ax_3d = fig.add_axes([0.56, 0.27, 0.39, 0.60], projection="3d")
                _plot_parts_3d_iso(ax_3d, [local_p], title=f"{t_pid} 三维零件实体预览 (3D Part Solid View)")

            pdf_out = self.drw_dir / spec["filename"]
            png_out = self.prev_dir / spec["filename"].replace(".pdf", ".png")
            fig.savefig(str(pdf_out), format="pdf")
            book_pages.savefig(fig)
            fig.savefig(str(png_out), format="png", dpi=160)
            plt.close(fig)

            generated_pdfs.append(pdf_out)
            generated_pngs.append(png_out)

        book_pages.close()

        # 生成额外的高清整机 4 视角总览图 output/previews/SRDP_Full_Robot_4View_Showcase.png
        showcase_png = self.prev_dir / "SRDP_Full_Robot_4View_Showcase.png"
        self._render_4view_showcase(full_parts, single_fin_parts, showcase_png)
        generated_pngs.append(showcase_png)

        return {
            "drawing_pdfs": generated_pdfs,
            "combined_book_pdf": book_pdf,
            "preview_pngs": generated_pngs,
        }

    def _render_4view_showcase(self, full_parts: List[SolidPart], single_fin_parts: List[SolidPart], out_png: Path):
        fig = plt.figure(figsize=(16, 11), dpi=180)
        fig.suptitle("SRDP 四鳍双自由度仿生水下机器人 V2.0 — 完整数字样机四视图总览 (坐标系: +X前 +Y右 +Z下)",
                     fontsize=14, fontweight="bold", color="#1B365D", y=0.97)

        ax1 = fig.add_subplot(2, 2, 1, projection="3d")
        _plot_parts_3d_iso(ax1, full_parts, "1. 整机三维等轴测图 (含四鳍、双水密舱、中央T200、浮材、配重、脚架、视觉靶)", elev=26, azim=-42)

        ax2 = fig.add_subplot(2, 2, 2)
        _plot_parts_ortho_2d(ax2, full_parts, plane="XY", title="2. 整机俯视总布置与运动包络图 (Top View XY)", show_sweep_circles=True)

        ax3 = fig.add_subplot(2, 2, 3)
        _plot_parts_ortho_2d(ax3, full_parts, plane="XZ", title="3. 整机主视高度配平图 (Side View XZ: 上浮材 / 下配重 / 脚架保护净空)")
        ax3.invert_yaxis()

        ax4 = fig.add_subplot(2, 2, 4, projection="3d")
        _plot_parts_3d_iso(ax4, single_fin_parts, "4. 双自由度串联仿生鳍模块特写 (S轴竖直划桨 + 短转架 + P轴径向羽化 + F-S鳍片)", elev=24, azim=-48)

        plt.tight_layout(rect=[0.01, 0.01, 0.99, 0.94])
        fig.savefig(str(out_png), format="png", dpi=180)
        plt.close(fig)
