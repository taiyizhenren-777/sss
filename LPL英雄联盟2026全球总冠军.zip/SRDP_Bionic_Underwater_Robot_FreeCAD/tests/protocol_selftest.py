#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Offline protocol/allocation self-check from SRDP Implementation Handbook (Pages 58-60). Never opens hardware or a serial port."""
import math
import struct

HEADER = struct.Struct('<BBHII')


def crc16_modbus(data: bytes) -> int:
    crc = 0xFFFF
    for byte in data:
        crc ^= byte
        for _ in range(8):
            crc = (crc >> 1) ^ (0xA001 if crc & 1 else 0)
    return crc


def encode_frame(msg_type: int, seq: int, session: int, payload: bytes = b'') -> bytes:
    if len(payload) > 128:
        raise ValueError('payload too long')
    body = HEADER.pack(1, msg_type, len(payload), seq, session) + payload
    return b'\xAA\x55' + body + struct.pack('<H', crc16_modbus(body))


def decode_complete_frame(frame: bytes):
    if len(frame) < 16 or frame[:2] != b'\xAA\x55':
        raise ValueError('bad sync or short frame')
    version, msg_type, size, seq, session = HEADER.unpack_from(frame, 2)
    if version != 1 or size > 128 or len(frame) != 16 + size:
        raise ValueError('bad version or length')
    actual_crc, = struct.unpack_from('<H', frame, len(frame) - 2)
    if crc16_modbus(frame[2:-2]) != actual_crc:
        raise ValueError('bad crc')
    return msg_type, seq, session, frame[14:-2]


def sequence_is_new(seq: int, previous: int) -> bool:
    delta = (seq - previous) & 0xFFFFFFFF
    return 0 < delta <= 10000


def allocate(fx: float, fy: float, mz: float, a: float = 0.25, b: float = 0.25, limit: float = 1.0):
    if a <= 0 or b <= 0 or limit <= 0:
        raise ValueError('positive arms and limit required')
    f = [fx / 2 + mz / (4 * b), fx / 2 - mz / (4 * b),
         fy / 2 + mz / (4 * a), fy / 2 - mz / (4 * a)]
    scale = min(1.0, limit / max(max(map(abs, f)), limit))
    return [v * scale for v in f], scale


def run_protocol_selftest() -> bool:
    assert crc16_modbus(b'123456789') == 0x4B37
    assert struct.calcsize('<HHHBBhhhh') == 16
    assert struct.calcsize('<IHHii hH') == 20
    assert struct.calcsize('<IIBBHIi6h4H5h2H') == 54
    packet = encode_frame(1, 1, 0x12345678, struct.pack('<II', 1, 0))
    assert decode_complete_frame(packet) == (1, 1, 0x12345678, struct.pack('<II', 1, 0))
    bad = bytearray(packet)
    bad[15] ^= 1
    try:
        decode_complete_frame(bad)
        raise AssertionError('corrupt packet accepted')
    except ValueError:
        pass
    assert sequence_is_new(0, 0xFFFFFFFF)
    assert not sequence_is_new(100, 100)
    assert not sequence_is_new(99, 100)
    for fx, fy, mz in [(0, 0, 0), (1, 0, 0), (0, 1, 0), (0, 0, 0.5), (2, 2, 1), (-2, -2, -1)]:
        f, s = allocate(fx, fy, mz)
        actual = (f[0] + f[1], f[2] + f[3], 0.25 * (f[0] - f[1] + f[2] - f[3]))
        assert all(math.isclose(v, t * s, abs_tol=1e-12) for v, t in zip(actual, (fx, fy, mz)))
        assert max(map(abs, f)) <= 1.0 + 1e-12
    print('CRC=4B37; CONTROL=16; VISION=20; STATUS=54')
    print('HELLO=' + packet.hex(' ').upper())
    print('PASS: roundtrip, CRC corruption, sequence wrap/duplicate/old, six allocation cases')
    return True


if __name__ == '__main__':
    run_protocol_selftest()
