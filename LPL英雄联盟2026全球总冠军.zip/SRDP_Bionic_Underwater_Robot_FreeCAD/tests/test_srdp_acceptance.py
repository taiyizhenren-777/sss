#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SRDP 仿生水下机器人 20 项自动化验收单元测试套件 (unittest)
"""
import sys
import json
import unittest
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.parameter_manager import ParameterManager
from src.assembly_manager import AssemblyManager
from src.collision_checker import CollisionChecker
from src.mass_properties import MassPropertiesCalculator
from src.export_manager import verify_fcstd_file, verify_step_file, verify_binary_stl, verify_dxf_file
from tests.protocol_selftest import run_protocol_selftest


class TestSRDPAcceptance(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pm = ParameterManager(PROJECT_ROOT)
        cls.asm = AssemblyManager(cls.pm)
        cls.full_parts = cls.asm.build_full_robot_assembly(fin_variant="F-S")
        cls.single_fin = cls.asm.build_single_fin_module_parts("F", at_origin=True)
        cls.fin_variants = cls.asm.build_standalone_fin_variants()

    def test_01_parameter_completeness_and_units(self):
        ok, msgs = self.pm.validate_completeness_and_units()
        self.assertTrue(ok, f"参数完整性或单位校验失败: {msgs}")

    def test_02_solid_validity(self):
        for p in self.full_parts:
            self.assertTrue(p.is_valid_solid(), f"无效零件实体: {p.instance_id}")

    def test_03_component_counts(self):
        servos = [p for p in self.full_parts if p.part_id == "PUR-SER-2010"]
        t200s = [p for p in self.full_parts if p.part_id == "PUR-BR-T200"]
        enclosures = [p for p in self.full_parts if p.part_id == "PUR-WTE-4IN-220"]
        fin_subs = {p.subsystem for p in self.full_parts if p.subsystem.startswith("FIN_")}
        self.assertEqual(len(servos), 8, "必须包含 8 台 SER-2010 水下伺服")
        self.assertEqual(len(t200s), 1, "必须包含且仅包含 1 台中央 T200 垂向推进器")
        self.assertGreaterEqual(len(enclosures), 1, "必须包含成品水密电子舱")
        self.assertEqual(fin_subs, {"FIN_L", "FIN_R", "FIN_F", "FIN_B"}, "必须包含 L/R/F/B 四个正交鳍模块")

    def test_04_kinematics_and_four_phase_gait(self):
        for t in [0.0, 0.8, 1.65, 2.0, 2.5, 3.3, 4.15, 4.6, 5.0]:
            g = self.asm.kin.evaluate_four_phase_gait(t)
            self.assertLessEqual(abs(g["cmd_s_deg"]), 15.0 + 1e-6)
            self.assertLessEqual(abs(g["cmd_p_deg"]), 45.0 + 1e-6)
        # 验证段首段尾速度为 0
        g_start = self.asm.kin.evaluate_four_phase_gait(0.0)
        self.assertAlmostEqual(g_start["vel_s_deg_s"], 0.0, places=5)
        self.assertAlmostEqual(g_start["vel_p_deg_s"], 0.0, places=5)

    def test_05_collision_checks(self):
        checker = CollisionChecker(self.asm)
        rep = checker.run_all_checks()
        self.assertEqual(rep["summary"]["fail_count"], 0, "碰撞检测不应存在 FAIL 项")
        self.assertEqual(rep["summary"]["total_checks"], 10, "必须执行全部 10 项碰撞检查")

    def test_06_mass_and_buoyancy(self):
        calc = MassPropertiesCalculator(self.pm)
        mrep = calc.analyze_full_assembly(self.full_parts)
        self.assertGreater(mrep["summary"]["net_buoyancy_N"], 0.1, "必须保持轻微正浮力")
        self.assertGreater(mrep["summary"]["BG_vertical_separation_mm"], 15.0, "浮心必须高于重心以保证横滚/俯仰恢复")

    def test_07_exported_files_reopen(self):
        fcstd_file = PROJECT_ROOT / "output" / "native_cad" / "SRDP_Full_Robot_Assembly.FCStd"
        step_file = PROJECT_ROOT / "output" / "step" / "SRDP_Full_Robot_Assembly.step"
        stl_file = PROJECT_ROOT / "output" / "stl" / "SRDP_Full_Robot_Assembly.stl"
        dxf_file = PROJECT_ROOT / "output" / "dxf" / "MFG-FRM-MAIN-PLATE.dxf"
        if fcstd_file.exists():
            ok_fc, cnt_fc = verify_fcstd_file(fcstd_file)
            self.assertTrue(ok_fc and cnt_fc > 40)
            ok_st, _ = verify_step_file(step_file)
            self.assertTrue(ok_st)
            ok_stl, _ = verify_binary_stl(stl_file)
            self.assertTrue(ok_stl)
            ok_dxf, _ = verify_dxf_file(dxf_file)
            self.assertTrue(ok_dxf)

    def test_08_handbook_protocol_and_allocator_selftest(self):
        self.assertTrue(run_protocol_selftest())


if __name__ == "__main__":
    unittest.main(verbosity=2)
