# SRDP 仿生水下机器人：FreeCAD 全自动机械结构设计与工程交付系统 V2.0

本项目依据**《SRDP 仿生水下机器人｜实施总册终稿.pdf》（2026-10-24）**开发，提供四鳍正交双自由度仿生划水/羽化水下机器人（8台 `Blue Trail Engineering SER-2010` 水下伺服 + 1台中央 `Blue Robotics T200` 垂向推进器 + 对称成品水密电子舱 + 开放式承力框架 + 可调浮材/配重 + 上视双ID ArUco视觉靶）的全参数化 CAD 数字样机、运动学与碰撞检查、质量浮力配平核算、13张制造工程图、BOM 清单与 20 项自动化验收测试系统。

## 1. 不可改变的核心技术构型与统一坐标系

* **推进与总体构型**：
  * **水平推进**：完全由正交分布的四个双自由度仿生鳍模块产生——左鳍 `L (F1)`、右鳍 `R (F2)` 主要提供前后（`±X`）平均推力；前鳍 `F (F3)`、后鳍 `B (F4)` 主要提供左右横移（`±Y`）平均推力；四鳍差动提供偏航力矩（`Mz`）。**严禁增加水平螺旋桨作为隐藏替代方案。**
  * **单鳍双自由度串联机构**：每套鳍含两台 `SER-2010` 水下伺服。`S 轴`（竖直轴）机壳固定在主框架基座上，输出端通过 `SER-0011` 钛合金毂带动短而宽的刚性转架；`P 轴`（径向轴）机壳固定在转架上随 `S 轴` 摆动，其输出端带动圆角夹板与透明 `VIVAK PETG` 鳍片做 ±45°（相差 90°）羽化翻转。
  * **垂向运动**：唯一一台 `Blue Robotics T200` 螺旋桨推进器位于机体中心 `O(0,0,0)`，推力轴线严格竖直（`+Z`），左右对称布置双成品水密电子干舱（左逻辑/传感舱 + 右动力/K1安全接触器舱），保证中央垂推上下进出水流道 100% 无遮挡。
* **统一机体坐标系（贯穿 CAD 零件、装配变换、运动学、固件与工程图）**：
  * **原点 `O(0,0,0)`**：中央垂向推进器轴线与主承力中层框板基准面交点。
  * **`+X`**：机体向前（前鳍 `F` 位于 `(+a, 0, 0)`，后鳍 `B` 位于 `(-a, 0, 0)`）。
  * **`+Y`**：机体向右（左鳍 `L` 位于 `(0, -b, 0)`，右鳍 `R` 位于 `(0, +b, 0)`）。
  * **`+Z`**：机体向下（右手系，俯视从 `+X` 朝 `+Y` 顺时针为 `+ψ` 正偏航；上部浮材位于 `-Z`，下部配重导轨与防触地脚架位于 `+Z`）。

## 2. 安装 FreeCAD 与配置开发环境（支持 VS Code 与 PyCharm）

1. **安装 FreeCAD（Windows 推荐 0.21 或 1.0 正式版）**：
   * 从 [FreeCAD 官网](https://www.freecad.org/) 下载并安装至默认路径（如 `C:\Program Files\FreeCAD 1.0\`）。
   * 若安装在自定义目录，可在 `config/freecad_path.txt` 中写入 `FreeCAD.exe` 的完整路径，或设置系统环境变量 `FREECAD_BIN`。
2. **双引擎独立运行支持（VS Code / PyCharm 直接开发调试）**：
   * 本工程区分 **FreeCAD 内置 Python 环境**、**FreeCAD GUI 宏环境** 与 **普通外部 Python 环境**。
   * 在 VS Code 或 PyCharm 中直接打开本项目根目录 `SRDP_Bionic_Underwater_Robot_FreeCAD/`（已内置 `.vscode/settings.json`、`launch.json` 与 `.idea/` 配置），安装基础科学计算依赖：
     ```powershell
     py -m venv .venv
     .\.venv\Scripts\python.exe -m pip install -r requirements.txt
     ```

## 3. 如何打开工程、运行主程序与一键生成完整机器人

* **方式一：Windows 一键批处理脚本（最便捷）**
  * 双击 `scripts/一键生成完整机器人.bat`：自动检测 FreeCAD 或启动内置几何引擎，生成完整机器人三维装配、13张工程图、BOM 表与验收报告。
  * 双击 `scripts/打开FreeCAD工程.bat`：自动启动 FreeCAD GUI 并加载 `output/native_cad/SRDP_Full_Robot_Assembly.FCStd`。
  * 双击 `scripts/一键检查模型.bat`：运行 20 项自动化验收测试与实施总册内置协议/分配器自检。
  * 双击 `scripts/一键导出工程文件.bat`：重新导出全部 `FCStd / STEP / STL / DXF / PDF / CSV / XLSX` 文件。
* **方式二：在 FreeCAD 图形界面中运行宏**
  * 打开 FreeCAD → 菜单栏 `宏 (Macro)` → `宏...` → 选择本项目 `macros/Generate_Full_SRDP.FCMacro` → 点击 `执行 (Execute)`。
* **方式三：命令行或 IDE 直接调试运行**
  ```powershell
  python src/main.py --mode full
  python -m unittest discover -s tests -p "test_*.py" -v
  ```

## 4. 如何修改参数并自动联动更新整机

所有机械与运动参数集中存放在 `config/` 目录下的 9 个 JSON 配置文件中，**严禁在代码内部硬编码关键尺寸**：
* `config/robot_parameters.json`：整机坐标系、四鳍力臂 `a, b` 与总体展开包络。
* `config/servo_parameters.json`：`SER-2010` 水下伺服、`SER-0011` 钛合金输出毂、`Cobalt 3-Pin` 连接器参数及三级可信度标记。
* `config/fin_parameters.json`：串联短转架、根部圆角双夹板（20×40 mm 夹持区）及 `F-S (80×40×0.5)`、`F-M (110×40×0.5)`、`F-L (140×40×0.5)` 三种可替换 PETG 试片参数。
* `config/frame_parameters.json`：开放式承力框架、上部 `R-3318` 闭孔浮材、下部可调配重导轨、底部防触地脚架与上视双 ID ArUco 标靶板参数。
* `config/thruster_parameters.json` & `config/enclosure_parameters.json`：中央 `T200` 垂推与成品水密电子舱参数。
* `config/motion_parameters.json`：四段平滑插值周期（A工作划水、B羽化、C低阻回程、D恢复工作姿态）及各模块镜像符号。
* **修改方法**：用编辑器修改任意 JSON 参数后，重新双击 `scripts/一键生成完整机器人.bat`，所有关联零件、装配坐标、工程图与 BOM 表自动重新计算更新。

## 5. 如何替换真实采购件 STEP 模型（A/B/C 三级可信度机制）

1. 当您从厂家资源页（如 [Blue Trail Engineering Resources](https://www.bluetrailengineering.com/resources) 或 [Blue Robotics](https://bluerobotics.com/)）下载到官方 STEP 原件并完成首批实物到货卡尺复核后，将官方 STEP 文件放入 `assets/official_models/` 目录：
   * `PUR-SER-2010.step`、`PUR-SER-0011.step`、`PUR-COBALT-3P.step`、`PUR-BR-T200.step`、`PUR-WTE-4IN-220.step`。
2. 根据到货卡尺实测值更新 `config/servo_parameters.json` 与 `config/enclosure_parameters.json` 中的待确认孔距，将 `credibility_level` 改为 `"A"`。
3. 重新运行主程序，即可在不改变整机框架拓扑的前提下完成精确孔位升级并解除加工冻结（`BLOCKED_FOR_FINAL_CNC` → `PASS`）。

## 6. 如何查看工程图、碰撞报告与待确认参数

* **13 张制造工程图与合并总图册**：位于 `output/drawings/`（含 `SRDP_Complete_Engineering_Drawings_Book_V2.pdf` 及 `DRW-01` 至 `DRW-13` 独立图纸）。
* **1:1 激光切割/CNC 加工 DXF 文件**：位于 `output/dxf/`（含三种鳍片、夹板、短转架、主框板、T200座、配重导轨、脚架）。
* **3D 打印与三维交换文件**：位于 `output/stl/`、`output/step/`、`output/native_cad/`。
* **BOM 与待确认参数表**：位于 `output/bom/SRDP_Robot_BOM_and_Parameters.xlsx`（含整机 BOM、子系统质量浮力图表、待确认参数表 3 个工作表）及同名 CSV。
* **碰撞、质量浮力与 20 项测试报告**：位于 `output/reports/`。
